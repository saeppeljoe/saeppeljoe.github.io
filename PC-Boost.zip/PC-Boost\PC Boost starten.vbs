' ============================================================
'  PC Boost - Starter
'  Startet das Backend nur wenn noetig und oeffnet die App
'  im App-Modus: ohne Adressleiste, ohne Tabs, ohne Browser-Rahmen.
' ============================================================

Option Explicit

Dim sh, fso, dir, url, i, browser
Set sh  = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

dir = fso.GetParentFolderName(WScript.ScriptFullName)
url = "http://localhost:8777"

' --- 1. Backend sicherstellen ---
' Drei Faelle: nichts laeuft / die aktuelle Fassung laeuft / eine alte haengt.
If Erreichbar(url) Then
    If Not IstAktuell(url) Then
        ' Eine aeltere Instanz belegt den Port. Erst hoeflich bitten
        ' aufzuhoeren - das klappt bei allen Fassungen ab v5.0.
        Beenden url
        For i = 1 To 20
            WScript.Sleep 400
            If Not Erreichbar(url) Then Exit For
        Next
        If Erreichbar(url) Then
            MsgBox "Auf Port 8777 laeuft noch eine aeltere PC-Boost-Instanz," & vbCrLf & _
                   "die sich nicht selbst beenden kann." & vbCrLf & vbCrLf & _
                   "So wirst du sie los:" & vbCrLf & _
                   "  1. Task-Manager oeffnen (Strg + Umschalt + Esc)" & vbCrLf & _
                   "  2. Reiter ""Details""" & vbCrLf & _
                   "  3. powershell.exe auswaehlen und beenden" & vbCrLf & _
                   "     (ggf. Task-Manager als Administrator starten)" & vbCrLf & vbCrLf & _
                   "Ein Neustart des PCs tut es genauso." & vbCrLf & vbCrLf & _
                   "Es wird jetzt die alte Fassung geoeffnet.", 48, "PC Boost"
        End If
    End If
End If

If Not Erreichbar(url) Then

    If fso.FileExists(dir & "\pc-boost.ps1") Then
        sh.Run "powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File """ & _
               dir & "\pc-boost.ps1""", 0, False
    ElseIf fso.FileExists(dir & "\PC-Boost.exe") Then
        ' Nur Rueckfallebene - eingefrorener aelterer Stand
        sh.Run """" & dir & "\PC-Boost.exe""", 0, False
    Else
        MsgBox "Weder pc-boost.ps1 noch PC-Boost.exe gefunden." & vbCrLf & vbCrLf & _
               "Erwartet in:" & vbCrLf & dir, 16, "PC Boost"
        WScript.Quit 1
    End If

    For i = 1 To 40
        WScript.Sleep 500
        If Erreichbar(url) Then Exit For
    Next

    If Not Erreichbar(url) Then
        MsgBox "Das Backend konnte nicht gestartet werden." & vbCrLf & vbCrLf & _
               "Pruefe, ob pc-boost.ps1 im selben Ordner liegt," & vbCrLf & _
               "und versuche es erneut.", 48, "PC Boost"
        WScript.Quit 1
    End If

End If

' --- 2. Oberflaeche im App-Modus oeffnen ---
browser = BrowserPfad()

If browser <> "" Then
    ' --app blendet Adressleiste, Tableiste und Lesezeichen komplett aus
    sh.Run """" & browser & """ --app=" & url & _
           " --window-size=1280,880" & _
           " --disable-features=Translate,AutofillServerCommunication" & _
           " --no-default-browser-check" & _
           " --no-first-run", 1, False
Else
    ' Kein Chromium gefunden - normaler Browser als Rueckfallebene
    sh.Run url, 1, False
End If


' ------------------------------------------------------------
'  Ersten verfuegbaren Chromium-Browser finden
' ------------------------------------------------------------
Function BrowserPfad()
    Dim kandidaten, p, lokal
    lokal = sh.ExpandEnvironmentStrings("%LOCALAPPDATA%")

    kandidaten = Array( _
        "C:\Program Files\Google\Chrome\Application\chrome.exe", _
        "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe", _
        lokal & "\Google\Chrome\Application\chrome.exe", _
        "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe", _
        "C:\Program Files\Microsoft\Edge\Application\msedge.exe", _
        "C:\Program Files\BraveSoftware\Brave-Browser\Application\brave.exe" _
    )

    BrowserPfad = ""
    For Each p In kandidaten
        If fso.FileExists(p) Then
            BrowserPfad = p
            Exit Function
        End If
    Next
End Function


' ------------------------------------------------------------
'  Antwortet die aktuelle Fassung? Aeltere liefern auf /api/version
'  die HTML-Seite statt JSON - daran erkennen wir sie.
' ------------------------------------------------------------
Function IstAktuell(adresse)
    Dim http
    IstAktuell = False
    On Error Resume Next
    Set http = CreateObject("MSXML2.XMLHTTP")
    http.Open "GET", adresse & "/api/version", False
    http.Send
    If Err.Number = 0 Then
        If http.Status = 200 Then
            If InStr(http.responseText, """backend"":""pc-boost""") > 0 Then IstAktuell = True
        End If
    End If
    Err.Clear
    On Error GoTo 0
End Function

' ------------------------------------------------------------
'  Laufende Instanz bitten, sich zu beenden
' ------------------------------------------------------------
Sub Beenden(adresse)
    Dim http
    On Error Resume Next
    Set http = CreateObject("MSXML2.XMLHTTP")
    http.Open "GET", adresse & "/api/quit", False
    http.Send
    Err.Clear
    On Error GoTo 0
End Sub

' ------------------------------------------------------------
Function Erreichbar(adresse)
    Dim http
    Erreichbar = False
    On Error Resume Next
    Set http = CreateObject("MSXML2.XMLHTTP")
    http.Open "GET", adresse & "/", False
    http.Send
    If Err.Number = 0 Then
        If http.Status = 200 Then Erreichbar = True
    End If
    Err.Clear
    On Error GoTo 0
End Function
