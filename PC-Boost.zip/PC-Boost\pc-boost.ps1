# ============================================================
#  PC BOOST  -  Live System Monitor & Werkzeugkasten  (v2.0)
#  Laeuft mit dem Windows-eigenen PowerShell. Keine Installation.
#  Dashboard im Browser unter  http://localhost:8777
#  CPU-Temperatur via LibreHardwareMonitor (Ordner "lib") - dafuer
#  werden einmalig Adminrechte abgefragt (UAC).
# ============================================================

$ErrorActionPreference = 'SilentlyContinue'
$port   = 8777
$prefix = "http://localhost:$port/"
$env:PCBOOST_PORT = "$port"  # fuer Hintergrund-Aktionen (z.B. Gaming-Overlay)
# Funktioniert als .ps1 UND als kompilierte .exe (PS2EXE).
# Bei der .exe ist $PSCommandPath leer -> Pfad ueber den Prozess ermitteln.
$selfExe      = [System.Diagnostics.Process]::GetCurrentProcess().MainModule.FileName
$runningAsExe = [string]::IsNullOrEmpty($PSCommandPath)
$scriptDir = if ($runningAsExe) { Split-Path -Parent $selfExe } else { Split-Path -Parent $PSCommandPath }
$libDir    = Join-Path $scriptDir 'lib'

# Konsolenfenster verstecken (falls vorhanden) - PC Boost laeuft als App-Fenster.
try {
    Add-Type -Name PCBWin -Namespace PCB -MemberDefinition '[DllImport("kernel32.dll")] public static extern System.IntPtr GetConsoleWindow(); [DllImport("user32.dll")] public static extern bool ShowWindow(System.IntPtr h, int c);' -ErrorAction SilentlyContinue
    $cw = [PCB.PCBWin]::GetConsoleWindow()
    if ($cw -ne [System.IntPtr]::Zero) { [void][PCB.PCBWin]::ShowWindow($cw, 0) }  # 0 = SW_HIDE
} catch {}

# --- Fuer die CPU-Temperatur (Ryzen) sind Adminrechte noetig. ---
# Einmal per UAC nachfragen und als Admin neu starten. Lehnt der Nutzer
# ab, laeuft alles weiter - nur die CPU-Temp bleibt dann "n/a".
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    try {
        if ($runningAsExe) {
            Start-Process -FilePath $selfExe -Verb RunAs -WindowStyle Hidden -ErrorAction Stop
        } else {
            $argLine = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
            Start-Process -FilePath 'powershell.exe' -Verb RunAs -WindowStyle Hidden -ArgumentList $argLine -ErrorAction Stop
        }
        exit   # die elevierte Instanz uebernimmt
    } catch {
        Write-Host "  Ohne Adminrechte gestartet - CPU-Temperatur bleibt 'n/a'." -ForegroundColor Yellow
    }
}

# --- Zustand fuer Netzwerk-Rate (zwischen zwei Messungen) ---
$script:prevRx   = $null
$script:prevTx   = $null
$script:prevTime = $null

# --- Windows-Input-Helfer (fuer Auto-Klicker / Tasten-Wiederholer) ---
# Einmal kompilieren; steht dann in allen Runspaces zur Verfuegung.
try {
Add-Type @"
using System;
using System.Runtime.InteropServices;
using System.Text;
public static class PCBoostInput {
  [DllImport("user32.dll")] public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, IntPtr dwExtraInfo);
  [DllImport("user32.dll")] public static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, IntPtr dwExtraInfo);
  [DllImport("user32.dll")] public static extern short GetAsyncKeyState(int vKey);
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  public static void LeftClick(){ mouse_event(0x02,0,0,0,IntPtr.Zero); mouse_event(0x04,0,0,0,IntPtr.Zero); }
  public static void RightClick(){ mouse_event(0x08,0,0,0,IntPtr.Zero); mouse_event(0x10,0,0,0,IntPtr.Zero); }
  public static void MiddleClick(){ mouse_event(0x20,0,0,0,IntPtr.Zero); mouse_event(0x40,0,0,0,IntPtr.Zero); }
  public static void MoveTo(int x, int y){ SetCursorPos(x,y); }
  public static void KeyPress(byte vk){ keybd_event(vk,0,0,IntPtr.Zero); keybd_event(vk,0,2,IntPtr.Zero); }
  public static bool IsDown(int vk){ return (GetAsyncKeyState(vk) & 0x8000) != 0; }

  // ---- Fenster-Manager ----
  public delegate bool EnumProc(IntPtr h, IntPtr l);
  [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr l);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
  [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
  [DllImport("user32.dll")] public static extern int GetWindowTextLength(IntPtr h);
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int c);
  [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr h, IntPtr after, int x, int y, int cx, int cy, uint flags);
  [DllImport("user32.dll")] public static extern IntPtr PostMessage(IntPtr h, uint msg, IntPtr w, IntPtr l);
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
  public static string ListWindows(){
    StringBuilder sb = new StringBuilder();
    EnumWindows(delegate(IntPtr h, IntPtr l){
      if(!IsWindowVisible(h)) return true;
      int len = GetWindowTextLength(h);
      if(len==0) return true;
      StringBuilder t = new StringBuilder(len+2);
      GetWindowText(h, t, t.Capacity);
      string title = t.ToString();
      if(title.Length==0) return true;
      uint pid; GetWindowThreadProcessId(h, out pid);
      sb.Append((long)h); sb.Append('|'); sb.Append(pid); sb.Append('|'); sb.Append(title); sb.Append('\n');
      return true;
    }, IntPtr.Zero);
    return sb.ToString();
  }
  public static void FocusWindow(long h){ IntPtr p=(IntPtr)h; ShowWindow(p,9); SetForegroundWindow(p); }
  public static void CloseWindow(long h){ PostMessage((IntPtr)h, 0x0010, IntPtr.Zero, IntPtr.Zero); }
  public static void SetTop(long h, bool on){ IntPtr t = on ? new IntPtr(-1) : new IntPtr(-2); SetWindowPos((IntPtr)h, t, 0,0,0,0, 0x0003); }

  // ---- Farbe unter Cursor ----
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X; public int Y; }
  [DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT p);
  [DllImport("user32.dll")] public static extern IntPtr GetDC(IntPtr h);
  [DllImport("user32.dll")] public static extern int ReleaseDC(IntPtr h, IntPtr dc);
  [DllImport("gdi32.dll")] public static extern uint GetPixel(IntPtr dc, int x, int y);
  public static string PickColor(){
    POINT p; GetCursorPos(out p);
    IntPtr dc = GetDC(IntPtr.Zero);
    uint c = GetPixel(dc, p.X, p.Y);
    ReleaseDC(IntPtr.Zero, dc);
    int r=(int)(c & 0xFF); int g=(int)((c>>8)&0xFF); int b=(int)((c>>16)&0xFF);
    return r+","+g+","+b+","+p.X+","+p.Y;
  }

  // ---- Bildschirm-Aktualisierungsrate (Hz) ----
  [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Ansi)]
  public struct DEVMODE {
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst=32)] public string dmDeviceName;
    public short dmSpecVersion; public short dmDriverVersion; public short dmSize; public short dmDriverExtra;
    public int dmFields;
    public int dmPositionX; public int dmPositionY; public int dmDisplayOrientation; public int dmDisplayFixedOutput;
    public short dmColor; public short dmDuplex; public short dmYResolution; public short dmTTOption; public short dmCollate;
    [MarshalAs(UnmanagedType.ByValTStr, SizeConst=32)] public string dmFormName;
    public short dmLogPixels; public int dmBitsPerPel; public int dmPelsWidth; public int dmPelsHeight;
    public int dmDisplayFlags; public int dmDisplayFrequency;
    public int dmICMMethod; public int dmICMIntent; public int dmMediaType; public int dmDitherType;
    public int dmReserved1; public int dmReserved2; public int dmPanningWidth; public int dmPanningHeight;
  }
  [DllImport("user32.dll", CharSet=CharSet.Ansi)] public static extern int EnumDisplaySettings(string dev, int mode, ref DEVMODE dm);
  [DllImport("user32.dll", CharSet=CharSet.Ansi)] public static extern int ChangeDisplaySettings(ref DEVMODE dm, int flags);
  public static string GetRefresh(){
    DEVMODE dm=new DEVMODE(); dm.dmSize=(short)Marshal.SizeOf(typeof(DEVMODE));
    if(EnumDisplaySettings(null,-1,ref dm)==0) return "0|0|0|0";
    int cur=dm.dmDisplayFrequency; int w=dm.dmPelsWidth,h=dm.dmPelsHeight; int max=cur;
    int i=0; DEVMODE m=new DEVMODE(); m.dmSize=(short)Marshal.SizeOf(typeof(DEVMODE));
    while(EnumDisplaySettings(null,i,ref m)!=0){ if(m.dmPelsWidth==w && m.dmPelsHeight==h && m.dmDisplayFrequency>max) max=m.dmDisplayFrequency; i++; }
    return cur+"|"+max+"|"+w+"|"+h;
  }
  public static int SetRefresh(int hz){
    DEVMODE dm=new DEVMODE(); dm.dmSize=(short)Marshal.SizeOf(typeof(DEVMODE));
    if(EnumDisplaySettings(null,-1,ref dm)==0) return -99;
    dm.dmDisplayFrequency=hz; dm.dmFields=0x400000;
    return ChangeDisplaySettings(ref dm, 1);
  }
}
"@
} catch {}

# --- Login/Zugangsschutz (lokales Passwort, als SHA256-Hash gespeichert) ---
$authFile = Join-Path $scriptDir 'pcboost-auth.json'
function Get-AuthStatus {
    $set = $false
    if (Test-Path $authFile) { try { $set = [bool]((Get-Content $authFile -Raw | ConvertFrom-Json).hash) } catch {} }
    return @{ set = $set }
}
function Test-Password($h) {
    if (-not $h) { return $false }
    if (-not (Test-Path $authFile)) { return $false }
    try { $stored = (Get-Content $authFile -Raw | ConvertFrom-Json).hash } catch { return $false }
    return ($stored -and $stored.ToLower() -eq ("$h").ToLower())
}
function Set-Password($h) {
    if ($h -notmatch '^[0-9a-fA-F]{64}$') { return $false }
    if ((Get-AuthStatus).set) { return $false }   # nur beim ersten Mal setzen
    try { (@{ hash = $h.ToLower() } | ConvertTo-Json) | Set-Content -Path $authFile -Encoding UTF8; return $true } catch { return $false }
}

# --- E-Mail-Verifizierung (SMTP) ---
$mailFile = Join-Path $scriptDir 'pcboost-mail.txt'
function Get-MailConfig {
    if (-not (Test-Path $mailFile)) { return $null }
    $cfg = @{}
    foreach ($line in (Get-Content $mailFile)) {
        $l = $line.Trim()
        if ($l -and -not $l.StartsWith('#') -and $l.Contains('=')) {
            $kv = $l.Split('=', 2); $cfg[$kv[0].Trim()] = $kv[1].Trim()
        }
    }
    # App-Passwort: Leerzeichen entfernen (Google zeigt es als "abcd efgh ijkl mnop").
    if ($cfg['app_password']) { $cfg['app_password'] = ($cfg['app_password'] -replace '\s', '') }
    if (-not $cfg['app_password'] -or $cfg['app_password'] -match 'HIER-DEIN|APP-PASSWORT') { return $null }
    if (-not $cfg['smtp_host'] -or -not $cfg['from_email']) { return $null }
    return $cfg
}
function Send-CodeMail($email, $code) {
    $cfg = Get-MailConfig
    if (-not $cfg) { return @{ ok = $false; msg = 'E-Mail-Versand ist nicht eingerichtet (pcboost-mail.txt ausfuellen).' } }
    try {
        $port = 587; [void][int]::TryParse($cfg['smtp_port'], [ref]$port)
        $fromName = if ($cfg['from_name']) { $cfg['from_name'] } else { 'PC Boost' }
        $msg = New-Object System.Net.Mail.MailMessage
        $msg.From = New-Object System.Net.Mail.MailAddress($cfg['from_email'], $fromName)
        $msg.To.Add($email)
        $msg.Subject = 'Dein PC Boost Bestaetigungscode'
        $msg.Body = "Hallo,`r`n`r`ndein Bestaetigungscode fuer PC Boost lautet:`r`n`r`n    $code`r`n`r`nDer Code ist 10 Minuten gueltig.`r`nWenn du das nicht warst, ignoriere diese E-Mail."
        $smtp = New-Object System.Net.Mail.SmtpClient($cfg['smtp_host'], $port)
        $smtp.EnableSsl = $true
        $smtp.Timeout = 12000
        $smtp.Credentials = New-Object System.Net.NetworkCredential($cfg['from_email'], $cfg['app_password'])
        $smtp.Send($msg)
        $msg.Dispose(); $smtp.Dispose()
        return @{ ok = $true; msg = 'Code gesendet - schau in dein Postfach (auch Spam).' }
    } catch {
        return @{ ok = $false; msg = ('Versand fehlgeschlagen: ' + $_.Exception.Message) }
    }
}

# --- Benutzerkonten (Registrieren / Anmelden) ---
$usersFile = Join-Path $scriptDir 'pcboost-users.json'
function Get-Users {
    if (Test-Path $usersFile) {
        try { $o = @{}; (Get-Content $usersFile -Raw | ConvertFrom-Json).PSObject.Properties | ForEach-Object { $o[$_.Name] = $_.Value }; return $o } catch {}
    }
    return @{}
}
function Save-Users($users) {
    try { ($users | ConvertTo-Json -Depth 5) | Set-Content -Path $usersFile -Encoding UTF8; return $true } catch { return $false }
}
function Test-UserLogin($email, $h) {
    if (-not $email -or -not $h) { return $false }
    $u = Get-Users; $e = $email.ToLower()
    if (-not $u.ContainsKey($e)) { return $false }
    return ($u[$e].hash -and ("$($u[$e].hash)").ToLower() -eq ("$h").ToLower())
}
function Save-User($email, $h) {
    if ($h -notmatch '^[0-9a-fA-F]{64}$') { return $false }
    $u = Get-Users; $u[$email.ToLower()] = @{ hash = $h.ToLower() }
    return (Save-Users $u)
}
function Register-Local($name, $h) {
    if (-not (Get-Access).allowRegister) { return @{ ok = $false; msg = 'Neue Registrierungen sind derzeit deaktiviert (vom Admin).' } }
    $n = "$name".Trim()
    if ($n.Length -lt 3 -or $n -notmatch '^[A-Za-z0-9_.\- ]{3,24}$') { return @{ ok = $false; msg = 'Name: 3-24 Zeichen, nur Buchstaben/Zahlen/_ . -' } }
    if ($h -notmatch '^[0-9a-fA-F]{64}$') { return @{ ok = $false; msg = 'Bitte ein Passwort eingeben (min. 4 Zeichen).' } }
    if ((Get-Users).ContainsKey($n.ToLower())) { return @{ ok = $false; msg = 'Diesen Namen gibt es schon - bitte anmelden.' } }
    if (Save-User $n $h) { return @{ ok = $true; msg = 'Konto erstellt.' } }
    return @{ ok = $false; msg = 'Konnte Konto nicht speichern.' }
}
function Start-Register($email, $h) {
    if ($email -notmatch '^[^@\s]+@[^@\s]+\.[^@\s]+$') { return @{ ok = $false; msg = 'Bitte eine gueltige E-Mail-Adresse eingeben.' } }
    if ($h -notmatch '^[0-9a-fA-F]{64}$') { return @{ ok = $false; msg = 'Bitte ein Passwort eingeben (min. 3 Zeichen).' } }
    if ((Get-Users).ContainsKey($email.ToLower())) { return @{ ok = $false; msg = 'Dieses Konto gibt es schon - bitte anmelden.' } }
    $cfg = Get-MailConfig
    if (-not $cfg) {
        # E-Mail-Bestaetigung ist Pflicht -> ohne eingerichteten Versand keine Registrierung.
        return @{ ok = $false; msg = 'Registrierung braucht E-Mail-Bestaetigung. Trage zuerst dein App-Passwort in der Datei pcboost-mail.txt ein.' }
    }
    if ($cfg['allowed']) {
        $list = @($cfg['allowed'].Split(',') | ForEach-Object { $_.Trim().ToLower() } | Where-Object { $_ })
        if ($list.Count -gt 0 -and ($list -notcontains $email.ToLower())) { return @{ ok = $false; msg = 'Diese Adresse ist nicht zur Registrierung freigeschaltet.' } }
    }
    $code = (Get-Random -Minimum 100000 -Maximum 1000000).ToString('000000')
    $shared.pending[$email.ToLower()] = @{ hash = $h.ToLower(); code = $code; exp = (Get-Date).AddMinutes(10) }
    $send = Send-CodeMail $email $code
    if ($send.ok) { return @{ ok = $true; needsCode = $true; msg = $send.msg } }
    return @{ ok = $false; msg = $send.msg }
}
function Verify-Register($email, $code) {
    if (-not $email -or -not $code) { return $false }
    $e = $email.ToLower(); $p = $shared.pending[$e]
    if (-not $p) { return $false }
    if ((Get-Date) -gt $p.exp) { $shared.pending.Remove($e); return $false }
    if ($p.code -ne ("$code").Trim()) { return $false }
    Save-User $email $p.hash | Out-Null
    $shared.pending.Remove($e)
    return $true
}

# --- Anmelden mit Discord (OAuth2) ---
$discordFile = Join-Path $scriptDir 'pcboost-discord.txt'
function Get-DiscordConfig {
    $cfg = @{}
    if (Test-Path $discordFile) {
        foreach ($line in (Get-Content $discordFile)) {
            $l = $line.Trim()
            if ($l -and -not $l.StartsWith('#') -and $l.Contains('=')) { $kv = $l.Split('=', 2); $cfg[$kv[0].Trim()] = $kv[1].Trim() }
        }
    }
    # Eingebaute Standard-Zugangsdaten: damit die EXE auch OHNE pcboost-discord.txt
    # funktioniert (z.B. wenn du nur die .exe an Freunde schickst). Die Textdatei
    # ueberschreibt diese Werte, falls jemand eine eigene Discord-App nutzen will.
    if (-not $cfg['client_id'] -or $cfg['client_id'] -match 'HIER-') { $cfg['client_id'] = '1529170287151550694' }
    if (-not $cfg['client_secret'] -or $cfg['client_secret'] -match 'HIER-') { $cfg['client_secret'] = 'B2N2bg_BaPT0QofyfDYyE9COPJ6gvARA' }
    if (-not $cfg['client_id'] -or -not $cfg['client_secret']) { return $null }
    return $cfg
}

# --- Admin-Panel: Zugang & Login-Verlauf (alles LOKAL auf diesem PC) ---
$accessFile   = Join-Path $scriptDir 'pcboost-access.json'
$loginLogFile = Join-Path $scriptDir 'pcboost-loginlog.json'
function Get-Access {
    $a = @{ allowed = @(); admins = @(); blocked = @(); allowRegister = $true }
    if (Test-Path $accessFile) {
        try { $o = Get-Content $accessFile -Raw | ConvertFrom-Json; $a.allowed = @($o.allowed | Where-Object { $_ }); $a.admins = @($o.admins | Where-Object { $_ }); $a.blocked = @($o.blocked | Where-Object { $_ }); if ($null -ne $o.allowRegister) { $a.allowRegister = [bool]$o.allowRegister } } catch {}
    }
    return $a
}
function Save-Access($a) { try { (@{ allowed=@($a.allowed); admins=@($a.admins); blocked=@($a.blocked); allowRegister=[bool]$a.allowRegister } | ConvertTo-Json -Depth 5) | Set-Content -Path $accessFile -Encoding UTF8; return $true } catch { return $false } }
function Remove-LocalUser($name) {
    $u = Get-Users; $k = "$name".ToLower()
    if ($u.ContainsKey($k)) { $u.Remove($k); if (Save-Users $u) { return "Konto '$name' geloescht." } else { return 'Fehler beim Speichern.' } }
    return 'Konto nicht gefunden.'
}
function Test-IsAdmin($id) { $a = Get-Access; if ($a.admins.Count -eq 0) { return $true }; return ($a.admins -contains "$id") }
# --- Zentrale Anmelde-Meldung per Discord-Webhook -----------------------
# Das Tool laeuft rein lokal - ohne zentrale Stelle kann kein PC die Logins
# eines anderen sehen. Ein Discord-Webhook (eine URL, die man in seinem
# eigenen Kanal erstellt) schliesst diese Luecke: jede Anmeldung, egal auf
# welchem PC, wird an diesen Kanal gemeldet. Nur der Kanal-Besitzer sieht es.
$webhookFile = Join-Path $scriptDir 'pcboost-webhook.txt'
function Get-Webhook {
    if (Test-Path $webhookFile) {
        try {
            foreach ($line in (Get-Content $webhookFile)) {
                $l = $line.Trim()
                if ($l -and -not $l.StartsWith('#') -and $l -match '^https://(discord|discordapp)\.com/api/webhooks/') { return $l }
            }
        } catch {}
    }
    return $null
}
function Set-Webhook($url) {
    $u = "$url".Trim()
    if ($u -eq '') {
        try { Remove-Item $webhookFile -Force -ErrorAction SilentlyContinue } catch {}
        return @{ ok = $true; msg = 'Webhook entfernt. Es werden keine Anmeldungen mehr gemeldet.' }
    }
    if ($u -notmatch '^https://(discord|discordapp)\.com/api/webhooks/\d+/[\w-]+$') {
        return @{ ok = $false; msg = 'Das sieht nicht nach einer Discord-Webhook-URL aus. In Discord: Kanal bearbeiten > Integrationen > Webhooks > Webhook-URL kopieren.' }
    }
    try {
        Set-Content -Path $webhookFile -Value "# PC Boost - Discord-Webhook fuer Anmelde-Meldungen`r`n$u" -Encoding UTF8
        return @{ ok = $true; msg = 'Webhook gespeichert. Ab jetzt wird jede Anmeldung gemeldet.' }
    } catch { return @{ ok = $false; msg = 'Konnte die Webhook-Datei nicht speichern.' } }
}
function Send-Webhook($titel, $zeilen, $farbe) {
    $url = Get-Webhook
    if (-not $url) { return $false }
    $felder = @()
    foreach ($z in $zeilen) { $felder += @{ name = "$($z.k)"; value = "$($z.v)"; inline = [bool]$z.inline } }
    $payload = @{
        username = 'PC Boost'
        embeds = @(@{
            title  = "$titel"
            color  = $farbe
            fields = $felder
            footer = @{ text = "PC Boost - $env:COMPUTERNAME" }
            timestamp = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
        })
    }
    try {
        $json = $payload | ConvertTo-Json -Depth 6
        Invoke-RestMethod -Uri $url -Method Post -ContentType 'application/json; charset=utf-8' -Body ([System.Text.Encoding]::UTF8.GetBytes($json)) -TimeoutSec 5 -ErrorAction Stop | Out-Null
        return $true
    } catch { return $false }
}

function Add-LoginLog($id, $name, $method) {
    if (-not $method) { $method = 'lokal' }
    $mx = New-Object System.Threading.Mutex($false, 'PCBoostLoginLogMutex')
    [void]$mx.WaitOne(2000)
    try {
        $log = @()
        if (Test-Path $loginLogFile) { try { $log = @(Get-Content $loginLogFile -Raw | ConvertFrom-Json) } catch {} }
        $entry = [ordered]@{
            id = "$id"; name = "$name"; time = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
            method = "$method"; pc = "$env:COMPUTERNAME"; winuser = "$env:USERNAME"
        }
        $log = @(@($entry) + @($log)) | Select-Object -First 200
        try { ($log | ConvertTo-Json -Depth 5) | Set-Content -Path $loginLogFile -Encoding UTF8 } catch {}
    } finally { try { $mx.ReleaseMutex() } catch {}; $mx.Dispose() }
    # Zentral melden (blockiert die Anmeldung nicht nennenswert: 5s Timeout, Fehler egal)
    try {
        Send-Webhook 'Neue Anmeldung' @(
            @{ k='Benutzer'; v="$name"; inline=$true },
            @{ k='Methode'; v="$method"; inline=$true },
            @{ k='PC'; v="$env:COMPUTERNAME"; inline=$true },
            @{ k='Windows-Konto'; v="$env:USERNAME"; inline=$true },
            @{ k='Zeit'; v=(Get-Date).ToString('dd.MM.yyyy HH:mm:ss'); inline=$true }
        ) 3447003 | Out-Null
    } catch {}
}
function Get-LoginLog {
    if (Test-Path $loginLogFile) {
        try { return @((Get-Content $loginLogFile -Raw | ConvertFrom-Json) | ForEach-Object {
            [ordered]@{ id = "$($_.id)"; name = "$($_.name)"; time = "$($_.time)"; method = "$($_.method)"; pc = "$($_.pc)"; winuser = "$($_.winuser)" }
        }) } catch {}
    }
    return @()
}
# Aggregat je Benutzer: erste/letzte Anmeldung, Anzahl, benutzte PCs
function Get-LoginSummary {
    $log = @(Get-LoginLog)
    $map = [ordered]@{}
    foreach ($e in $log) {
        $k = "$($e.id)"
        if (-not $map.Contains($k)) {
            $map[$k] = [ordered]@{ id=$k; name="$($e.name)"; anzahl=0; zuletzt="$($e.time)"; zuerst="$($e.time)"; pcs=@() }
        }
        $m = $map[$k]
        $m.anzahl++
        if ("$($e.time)" -gt "$($m.zuletzt)") { $m.zuletzt = "$($e.time)" }
        if ("$($e.time)" -lt "$($m.zuerst)") { $m.zuerst = "$($e.time)" }
        if ($e.pc -and ($m.pcs -notcontains "$($e.pc)")) { $m.pcs += "$($e.pc)" }
    }
    return @($map.Values | Sort-Object { $_.zuletzt } -Descending)
}
function Access-Op($op, $id) {
    $id = "$id".Trim(); if (-not $id) { return 'Keine ID.' }
    $a = Get-Access
    switch ($op) {
        'allow'    { if ($a.allowed -notcontains $id) { $a.allowed = @($a.allowed) + $id }; $a.blocked = @($a.blocked | Where-Object { $_ -ne $id }) }
        'unallow'  { $a.allowed = @($a.allowed | Where-Object { $_ -ne $id }) }
        'block'    { if ($a.blocked -notcontains $id) { $a.blocked = @($a.blocked) + $id } }
        'unblock'  { $a.blocked = @($a.blocked | Where-Object { $_ -ne $id }) }
        'admin'    { if ($a.admins -notcontains $id) { $a.admins = @($a.admins) + $id } }
        'unadmin'  { $a.admins = @($a.admins | Where-Object { $_ -ne $id }) }
        'setreg'   { $a.allowRegister = ($id -eq '1') }
        default    { return 'Unbekannt.' }
    }
    if (Save-Access $a) { return 'OK' } else { return 'Speichern fehlgeschlagen.' }
}

# ------------------------------------------------------------
#  Live-Werte einsammeln (schnell, alle ~2s)
# ------------------------------------------------------------
function Get-Stats {
    # ---------- CPU ----------
    # Schnelle, sprachunabhaengige Quelle (PercentProcessorTime, ~300ms)
    # statt Win32_Processor.LoadPercentage (~1s). Liefert auch pro Kern.
    $perf = Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor
    $cpuLoad = [int]($perf | Where-Object { $_.Name -eq '_Total' } | Select-Object -First 1).PercentProcessorTime
    $coresArr = @($perf | Where-Object { $_.Name -ne '_Total' } | Sort-Object { [int]$_.Name } | ForEach-Object { [int]$_.PercentProcessorTime })
    # Statische CPU-Infos nur EINMAL holen und merken (spart pro Runde ~1s).
    if (-not $global:cpuStatic) {
        $ci = Get-CimInstance Win32_Processor | Select-Object -First 1
        $global:cpuStatic = @{ name=("$($ci.Name)").Trim(); cores=$ci.NumberOfCores; threads=$ci.NumberOfLogicalProcessors }
    }
    $cpuName = $global:cpuStatic.name
    $cores   = $global:cpuStatic.cores
    $threads = $global:cpuStatic.threads

    # ---------- RAM ----------
    $os        = Get-CimInstance Win32_OperatingSystem
    $totalKB   = [double]$os.TotalVisibleMemorySize
    $freeKB    = [double]$os.FreePhysicalMemory
    $usedKB    = $totalKB - $freeKB
    $ramPct    = if ($totalKB -gt 0) { [math]::Round(($usedKB / $totalKB) * 100, 1) } else { 0 }
    $ramUsedGB = [math]::Round($usedKB  / 1MB, 1)
    $ramTotalGB= [math]::Round($totalKB / 1MB, 1)

    # ---------- Laufzeit ----------
    $boot   = $os.LastBootUpTime
    $up     = (Get-Date) - $boot
    $upTxt  = "{0}d {1}h" -f $up.Days, $up.Hours

    # ---------- Festplatten ----------
    $disks = @()
    Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" | ForEach-Object {
        if ($_.Size -gt 0) {
            $disks += [ordered]@{
                drive   = $_.DeviceID
                freeGB  = [math]::Round($_.FreeSpace / 1GB, 1)
                totalGB = [math]::Round($_.Size     / 1GB, 1)
                usedPct = [math]::Round((($_.Size - $_.FreeSpace) / $_.Size) * 100, 0)
            }
        }
    }

    # ---------- GPU (NVIDIA via nvidia-smi) ----------
    $gpuName = ''; $gpuLoad = $null; $gpuTemp = $null; $gpuMemUsed = $null; $gpuMemTot = $null
    $gpuClock = $null; $gpuPower = $null; $gpuFan = $null; $gpuMemClock = $null
    try {
        $q = $null
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = 'nvidia-smi'
        $psi.Arguments = '--query-gpu=name,utilization.gpu,temperature.gpu,memory.used,memory.total,clocks.gr,power.draw,fan.speed,clocks.mem --format=csv,noheader,nounits'
        $psi.UseShellExecute = $false
        $psi.RedirectStandardOutput = $true
        $psi.RedirectStandardError = $true
        $psi.CreateNoWindow = $true
        $proc = [System.Diagnostics.Process]::Start($psi)
        if ($proc.WaitForExit(2500)) { $q = $proc.StandardOutput.ReadToEnd() }
        else { try { $proc.Kill() } catch {} }
        if ($q) {
            $p = ($q | Select-Object -First 1).Split(',')
            $gpuName    = $p[0].Trim()
            $gpuLoad    = [int]$p[1].Trim()
            $gpuTemp    = [int]$p[2].Trim()
            $gpuMemUsed = [math]::Round([double]$p[3].Trim() / 1024, 1)
            $gpuMemTot  = [math]::Round([double]$p[4].Trim() / 1024, 1)
            if ($p.Count -gt 5 -and $p[5].Trim() -match '^\d') { $gpuClock = [int]$p[5].Trim() }
            if ($p.Count -gt 6 -and $p[6].Trim() -match '^\d') { $gpuPower = [math]::Round([double]$p[6].Trim(), 0) }
            if ($p.Count -gt 7 -and $p[7].Trim() -match '^\d') { $gpuFan   = [int]$p[7].Trim() }
            if ($p.Count -gt 8 -and $p[8].Trim() -match '^\d') { $gpuMemClock = [int]$p[8].Trim() }
        }
    } catch {}
    if ($null -eq $gpuName -or $gpuName -eq '') {
        $g = Get-CimInstance Win32_VideoController | Select-Object -First 1
        if ($g) { $gpuName = $g.Name }
    }
    if ($null -eq $gpuTemp -and $null -ne $global:gpuTempLHM) { $gpuTemp = $global:gpuTempLHM }

    # ---------- CPU-Temperatur ----------
    $cpuTemp = $null
    if ($null -ne $global:cpuTempLHM -and $global:cpuTempLHM -gt 0) {
        $cpuTemp = $global:cpuTempLHM
    } else {
        try {
            $t = Get-CimInstance -Namespace root/wmi -ClassName MSAcpi_ThermalZoneTemperature -ErrorAction SilentlyContinue |
                 Select-Object -First 1
            if ($t) { $cpuTemp = [math]::Round(($t.CurrentTemperature / 10) - 273.15, 0) }
        } catch {}
    }

    # ---------- Netzwerk-Rate ----------
    $rxRate = 0; $txRate = 0
    $ni = Get-CimInstance Win32_PerfRawData_Tcpip_NetworkInterface -ErrorAction SilentlyContinue |
          Where-Object { $_.Name -notmatch 'Loopback|isatap|Teredo' }
    $rxTot = ($ni | Measure-Object -Property BytesReceivedPersec -Sum).Sum
    $txTot = ($ni | Measure-Object -Property BytesSentPersec     -Sum).Sum
    $now   = Get-Date
    if ($null -ne $script:prevRx -and $null -ne $script:prevTime) {
        $dt = ($now - $script:prevTime).TotalSeconds
        if ($dt -gt 0) {
            $rxRate = [math]::Round((($rxTot - $script:prevRx) * 8) / $dt / 1MB, 1)
            $txRate = [math]::Round((($txTot - $script:prevTx) * 8) / $dt / 1MB, 1)
            if ($rxRate -lt 0) { $rxRate = 0 }
            if ($txRate -lt 0) { $txRate = 0 }
        }
    }
    $script:prevRx = $rxTot; $script:prevTx = $txTot; $script:prevTime = $now

    # ---------- Vibe-Score ----------
    $vibe = 100
    $vibe -= [math]::Round($cpuLoad * 0.25)
    if ($gpuLoad) { $vibe -= [math]::Round($gpuLoad * 0.20) }
    if ($gpuTemp -and $gpuTemp -gt 75) { $vibe -= ($gpuTemp - 75) }
    $vibe -= [math]::Round(($ramPct - 50) * 0.20)
    if ($vibe -gt 100) { $vibe = 100 }
    if ($vibe -lt 0)   { $vibe = 0 }
    $mood = if ($vibe -ge 85) { 'CHILL' } elseif ($vibe -ge 60) { 'OK' } elseif ($vibe -ge 35) { 'WARM' } else { 'HOT' }

    return [ordered]@{
        time       = (Get-Date).ToString('HH:mm:ss')
        cpuLoad    = $cpuLoad; cpuName = $cpuName; cores = $cores; threads = $threads; cpuTemp = $cpuTemp; coresArr = $coresArr
        ramPct     = $ramPct; ramUsedGB = $ramUsedGB; ramTotalGB = $ramTotalGB
        gpuName    = $gpuName; gpuLoad = $gpuLoad; gpuTemp = $gpuTemp; gpuMemUsed = $gpuMemUsed; gpuMemTot = $gpuMemTot
        gpuClock   = $gpuClock; gpuPower = $gpuPower; gpuFan = $gpuFan; gpuMemClock = $gpuMemClock; gpuHotspot = $global:gpuHotspotLHM
        rxRate     = $rxRate; txRate = $txRate; uptime = $upTxt; disks = $disks; vibe = $vibe; mood = $mood
    }
}

# ------------------------------------------------------------
#  Hardware-Details (statisch, einmal einsammeln)
# ------------------------------------------------------------
function Get-HardwareInfo {
    $os  = Get-CimInstance Win32_OperatingSystem
    $cs  = Get-CimInstance Win32_ComputerSystem
    $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
    $bb  = Get-CimInstance Win32_BaseBoard
    $mem = @(Get-CimInstance Win32_PhysicalMemory)
    $memMods = @($mem | ForEach-Object { [ordered]@{ cap=[math]::Round($_.Capacity/1GB,0); speed=$_.Speed; slot=$_.DeviceLocator; mfr=("$($_.Manufacturer)").Trim() } })
    $ramTotal = if ($mem.Count) { [math]::Round((($mem | Measure-Object Capacity -Sum).Sum)/1GB,0) } else { 0 }

    $vc = @(Get-CimInstance Win32_VideoController | Where-Object { $_.Name -notmatch 'Basic|Remote|Meta|Parsec|Virtual' })
    $gpuList = @()
    foreach ($g in $vc) {
        $gpuList += [ordered]@{
            name   = ("$($g.Name)").Trim()
            driver = $g.DriverVersion
            res    = if ($g.CurrentHorizontalResolution) { "{0}x{1}" -f $g.CurrentHorizontalResolution, $g.CurrentVerticalResolution } else { '' }
            hz     = $g.CurrentRefreshRate
            vramGB = if ($g.AdapterRAM) { [math]::Round($g.AdapterRAM/1GB,1) } else { $null }
        }
    }
    # nvidia-smi liefert die KORREKTE VRAM-Groesse (Win32 deckelt bei 4 GB).
    try {
        $q=$null; $psi=New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName='nvidia-smi'; $psi.Arguments='--query-gpu=name,driver_version,memory.total --format=csv,noheader,nounits'
        $psi.UseShellExecute=$false;$psi.RedirectStandardOutput=$true;$psi.RedirectStandardError=$true;$psi.CreateNoWindow=$true
        $pr=[System.Diagnostics.Process]::Start($psi); if($pr.WaitForExit(2500)){$q=$pr.StandardOutput.ReadToEnd()}else{try{$pr.Kill()}catch{}}
        if ($q -and $gpuList.Count -gt 0) {
            $pp=($q|Select-Object -First 1).Split(',')
            $gpuList[0].vramGB = [math]::Round([double]$pp[2].Trim()/1024,1)
            if ($pp[1]) { $gpuList[0].driver = $pp[1].Trim() }
        }
    } catch {}

    $drives = @(Get-CimInstance Win32_DiskDrive | Where-Object { $_.Size -gt 0 -and $_.MediaType -notmatch 'Removable' } |
        ForEach-Object { [ordered]@{ model=("$($_.Model)").Trim(); sizeGB=[math]::Round($_.Size/1GB,0) } })
    $volumes = @(Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" | Where-Object { $_.Size -gt 0 } | ForEach-Object {
        $tot=[math]::Round($_.Size/1GB,0); $free=[math]::Round($_.FreeSpace/1GB,0)
        $pct=0; if ($_.Size -gt 0) { $pct=[math]::Round((($_.Size-$_.FreeSpace)/$_.Size)*100,0) }
        [ordered]@{ letter="$($_.DeviceID)"; label=("$($_.VolumeName)").Trim(); totalGB=$tot; freeGB=$free; usedGB=($tot-$free); pct=$pct }
    })

    $install = $null; $daysInst = $null
    try { if ($os.InstallDate -and $os.InstallDate.Year -gt 2000) { $install = $os.InstallDate.ToString('dd.MM.yyyy'); $daysInst = [int]((Get-Date) - $os.InstallDate).TotalDays } } catch {}

    return [ordered]@{
        osName    = $os.Caption
        osBuild   = $os.BuildNumber
        osInstall = $install
        osDays    = $daysInst
        pc        = ("{0} {1}" -f $cs.Manufacturer, $cs.Model).Trim()
        board     = ("{0} {1}" -f $bb.Manufacturer, $bb.Product).Trim()
        cpuName   = ("$($cpu.Name)").Trim()
        cpuCores  = $cpu.NumberOfCores
        cpuThreads= $cpu.NumberOfLogicalProcessors
        cpuClock  = [math]::Round($cpu.MaxClockSpeed/1000,1)
        cpuSocket = $cpu.SocketDesignation
        ramTotal  = $ramTotal
        ramMods   = $memMods
        gpus      = $gpuList
        drives    = $drives
        volumes   = $volumes
    }
}

# ------------------------------------------------------------
#  Netzwerk-Adapter-Infos (schnell)
# ------------------------------------------------------------
function Get-NetworkInfo {
    $a = Get-CimInstance Win32_NetworkAdapterConfiguration | Where-Object { $_.IPEnabled } | Select-Object -First 1
    $adapterName = ''; $speed = $null
    if ($a) {
        $na = Get-CimInstance Win32_NetworkAdapter -Filter "Index=$($a.Index)"
        if ($na) { $adapterName = $na.NetConnectionID; if ($na.Speed) { $speed = [math]::Round($na.Speed/1e6,0) } }
    }
    return [ordered]@{
        adapter = $adapterName
        desc    = if ($a) { $a.Description } else { '' }
        ipv4    = if ($a) { (($a.IPAddress | Where-Object { $_ -match '^\d+\.\d+\.\d+\.\d+$' }) -join ', ') } else { '' }
        gateway = if ($a) { (($a.DefaultIPGateway) -join ', ') } else { '' }
        dns     = if ($a) { (($a.DNSServerSearchOrder) -join ', ') } else { '' }
        mac     = if ($a) { $a.MACAddress } else { '' }
        speed   = $speed
    }
}

# ------------------------------------------------------------
#  Prozessliste (Top nach RAM)
# ------------------------------------------------------------
function Get-ProcessList {
    $list = @()
    Get-Process | Sort-Object WorkingSet64 -Descending | Select-Object -First 18 | ForEach-Object {
        $list += [ordered]@{
            pid  = $_.Id
            name = $_.ProcessName
            ram  = [math]::Round($_.WorkingSet64/1MB,0)
            cpu  = [math]::Round($_.CPU,0)
        }
    }
    return @{ procs = $list }
}

# ------------------------------------------------------------
#  HTML (Dashboard mit Seitenleiste)
# ------------------------------------------------------------
$html = @'
<!DOCTYPE html>
<html lang="de">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>PC Boost</title>
<link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'><path fill='%23c04bff' d='M13 2 3 14h7l-1 8 10-12h-7z'/></svg>">
<style>
  :root{
    --bg:#0a090d; --panel:#141318; --panel2:#1c1a22; --line:rgba(255,255,255,.075);
    --txt:#f3f2f7; --muted:#8b8794; --accent:#ff4172; --accent2:#ff2d78; --purple:#a78bfa;
    --green:#35e0a1; --blue:#2bb3fb; --yellow:#ffd24b; --red:#de3b28;
    --bolt:url("data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20width='28'%20height='28'%20viewBox='0%200%2024%2024'%3E%3Cpath%20d='M13%202%203%2014%2010%2014%209%2022%2019%2010%2012%2010Z'%20fill='%23ff4172'%20stroke='%23ffffff'%20stroke-width='1.3'%20stroke-linejoin='round'/%3E%3C/svg%3E");
  }
  *{box-sizing:border-box;margin:0;padding:0}
  body{background:#0a090d;
       background-image:radial-gradient(1100px 600px at 88% -6%,rgba(255,65,114,.06),transparent 60%);
       background-attachment:fixed;
       color:var(--txt);font-family:"Segoe UI",system-ui,sans-serif;min-height:100vh;cursor:var(--bolt) 14 2,auto}
  .mono{font-family:"Cascadia Code",Consolas,monospace}
  .app{display:flex;min-height:100vh}

  /* ---- Sidebar ---- */
  .side{width:230px;flex:none;background:linear-gradient(180deg,#160e22,#0f0918);border-right:1px solid var(--line);
        padding:18px 14px;position:sticky;top:0;height:100vh;overflow-y:auto}
  .side .brand{display:flex;align-items:center;gap:10px;margin-bottom:22px;padding:0 6px}
  .side .logo{width:38px;height:38px;border-radius:11px;background:linear-gradient(135deg,var(--purple),var(--accent));
        display:flex;align-items:center;justify-content:center;font-size:19px;box-shadow:0 0 20px rgba(255,65,114,.45)}
  .side .brand b{font-size:16px;letter-spacing:1.5px;display:block}
  .side .brand small{color:var(--muted);font-size:11px}
  .gamebadge{display:flex;align-items:center;gap:8px;margin:0 0 18px;padding:9px 12px;border-radius:10px;cursor:pointer;
        font-size:13px;font-weight:600;color:#ff7a9c;background:rgba(255,65,114,.10);border:1px solid rgba(255,65,114,.35)}
  .gamebadge:hover{background:rgba(255,65,114,.18)}
  .navgrp{color:var(--muted);font-size:10px;letter-spacing:2px;margin:16px 8px 6px}
  .nav{display:flex;align-items:center;gap:11px;padding:9px 12px;border-radius:10px;cursor:pointer;color:var(--muted);
       font-size:14px;transition:.15s;user-select:none}
  .nav:hover{background:rgba(255,255,255,.04);color:var(--txt)}
  .nav.active{background:rgba(255,65,114,.12);color:#fff;box-shadow:inset 2px 0 0 var(--accent)}
  .nav .ic{width:18px;text-align:center}
  .side .foot{margin-top:20px;padding:10px 8px;color:var(--muted);font-size:11px;border-top:1px solid var(--line)}
  .subtabs{display:flex;gap:4px;flex-wrap:wrap;margin-bottom:18px;border-bottom:1px solid var(--line)}
  .subtabs:empty{display:none}
  .subtab{padding:9px 16px;border-radius:9px 9px 0 0;cursor:pointer;color:var(--muted);font-size:14px;font-weight:600;border-bottom:2px solid transparent;transition:.12s}
  .subtab:hover{color:var(--txt)}
  .subtab.active{color:#fff;border-bottom-color:var(--accent);background:rgba(255,65,114,.09)}

  /* ---- Main ---- */
  .main{flex:1;padding:24px 30px 60px;min-width:0}
  .top{display:flex;align-items:center;justify-content:space-between;margin-bottom:20px}
  .top h1{font-size:22px}
  .top .sub{color:var(--muted);font-size:13px}
  .top .badges{display:flex;gap:8px;align-items:center}
  .chip{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:7px 13px;font-size:13px;color:var(--muted)}
  .chip b{color:var(--txt)}
  .live{display:inline-flex;align-items:center;gap:6px;color:var(--green);font-size:12px}
  .dot{width:8px;height:8px;border-radius:50%;background:var(--green);box-shadow:0 0 8px var(--green);animation:pulse 1.4s infinite}
  @keyframes pulse{0%,100%{opacity:1}50%{opacity:.3}}

  .page{display:none}
  .page.active{display:block}

  /* ---- Cards ---- */
  .pulse{background:linear-gradient(120deg,#2a0f38,#1a0d26);border:1px solid var(--line);border-radius:18px;
        padding:20px 24px;display:flex;align-items:center;gap:20px;margin-bottom:18px}
  .score{width:92px;height:92px;border-radius:50%;flex:none;display:flex;align-items:center;justify-content:center;
        background:conic-gradient(var(--green) 0%,rgba(255,255,255,.06) 0)}
  .score .inner{width:74px;height:74px;border-radius:50%;background:var(--panel);display:flex;flex-direction:column;
        align-items:center;justify-content:center}
  .score .inner b{font-size:25px;line-height:1}
  .score .inner span{font-size:10px;color:var(--muted);letter-spacing:2px}
  .pulse .txt{flex:1}
  .pulse .tag{display:inline-block;background:rgba(255,255,255,.08);border-radius:8px;padding:3px 10px;font-size:11px;
        letter-spacing:1px;color:var(--muted);margin-bottom:8px}
  .pulse h2{font-size:21px;margin-bottom:6px}
  .pulse p{color:var(--muted)}
  .pulse .badges{display:flex;flex-direction:column;gap:8px;align-items:flex-end}
  .badge{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:6px 14px;font-size:13px}

  .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:16px;margin-bottom:18px}
  .card{background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:18px 20px}
  .card .head{display:flex;justify-content:space-between;align-items:baseline;margin-bottom:14px}
  .card .head .lbl{color:var(--muted);font-size:12px;letter-spacing:2px}
  .card .head .val{font-size:26px;font-weight:700}
  .row{display:flex;align-items:center;gap:16px}
  .ring{width:64px;height:64px;border-radius:50%;flex:none;display:flex;align-items:center;justify-content:center;
        background:conic-gradient(var(--rc,var(--accent)) calc(var(--p,0)*1%),rgba(255,255,255,.06) 0)}
  .ring .hole{width:48px;height:48px;border-radius:50%;background:var(--panel);display:flex;align-items:center;
        justify-content:center;font-size:12px;color:var(--muted)}
  .card .sub{color:var(--muted);font-size:13px;line-height:1.5}
  .card .sub b{color:var(--txt)}
  .bar{height:6px;border-radius:6px;background:rgba(255,255,255,.06);margin-top:12px;overflow:hidden}
  .bar i{display:block;height:100%;border-radius:6px;background:linear-gradient(90deg,var(--accent),var(--accent2))}

  .cols{display:grid;grid-template-columns:1fr 1fr;gap:16px}
  @media(max-width:900px){.cols{grid-template-columns:1fr}}
  .panelbox{background:var(--panel);border:1px solid var(--line);border-radius:16px;padding:18px 20px;margin-bottom:16px}
  .panelbox h3{font-size:12px;letter-spacing:2px;color:var(--muted);margin-bottom:14px}
  canvas{width:100%;height:150px;display:block}

  /* infos / tables */
  .kv{display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--line);font-size:14px}
  .kv:last-child{border-bottom:none}
  .kv span{color:var(--muted)}  .kv b{color:var(--txt);font-weight:600;text-align:right}
  table{width:100%;border-collapse:collapse;font-size:13px}
  th{text-align:left;color:var(--muted);font-size:11px;letter-spacing:1px;padding:8px 10px;border-bottom:1px solid var(--line)}
  td{padding:9px 10px;border-bottom:1px solid var(--line)}
  tr:last-child td{border-bottom:none}

  .btn{background:linear-gradient(135deg,var(--accent),var(--accent2));color:#fff;border:none;border-radius:10px;
       padding:10px 16px;font-size:13px;cursor:pointer;font-weight:600;transition:.15s}
  .btn:hover{filter:brightness(1.12)}
  .btn.ghost{background:var(--panel2);border:1px solid var(--line);color:var(--txt)}
  .btn.danger{background:linear-gradient(135deg,#ff5b6e,#ff8a4b)}
  .btn.sm{padding:6px 11px;font-size:12px}
  .btn:disabled{opacity:.5;cursor:default}
  .tiles{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:12px}
  .tile{background:var(--panel2);border:1px solid var(--line);border-radius:13px;padding:16px 12px;text-align:center;
        cursor:pointer;transition:.15s;user-select:none}
  .tile:hover{border-color:var(--accent);transform:translateY(-2px)}
  .tile .ti{font-size:24px;margin-bottom:8px}
  .tile .tn{font-size:13px}
  .out{background:#0c0813;border:1px solid var(--line);border-radius:10px;padding:12px 14px;margin-top:12px;
       font-family:"Cascadia Code",Consolas,monospace;font-size:12px;color:var(--green);white-space:pre-wrap;
       max-height:220px;overflow:auto;display:none}
  .note{background:rgba(255,210,75,.08);border:1px solid rgba(255,210,75,.3);color:var(--yellow);
        border-radius:12px;padding:10px 14px;font-size:13px;margin-bottom:16px}
  .lat{display:flex;gap:14px;flex-wrap:wrap;margin-top:12px}
  .lat .l{flex:1;min-width:120px;background:var(--panel2);border:1px solid var(--line);border-radius:12px;padding:12px 14px}
  .lat .l .n{color:var(--muted);font-size:12px}
  .lat .l .v{font-size:22px;margin-top:4px}
  .spin{display:inline-block;width:13px;height:13px;border:2px solid rgba(255,255,255,.25);border-top-color:#fff;
        border-radius:50%;animation:sp .7s linear infinite;vertical-align:-2px;margin-right:6px}
  @keyframes sp{to{transform:rotate(360deg)}}
  .tw{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:11px 0;border-bottom:1px solid var(--line)}
  .tw:last-child{border-bottom:none}
  .cores{display:grid;grid-template-columns:repeat(auto-fill,minmax(78px,1fr));gap:8px}
  .core{background:var(--panel2);border:1px solid var(--line);border-radius:9px;padding:8px 9px}
  .core .cl{font-size:10px;color:var(--muted);display:flex;justify-content:space-between}
  .core .cbar{height:5px;border-radius:5px;background:rgba(255,255,255,.06);margin-top:6px;overflow:hidden}
  .core .cbar i{display:block;height:100%;border-radius:5px;transition:width .3s}
  .loginwrap{position:fixed;inset:0;z-index:1000;background:radial-gradient(1200px 600px at 50% -10%,#241033,#0a0710 60%);display:flex;align-items:center;justify-content:center}
  .loginbox{background:var(--panel);border:1px solid var(--line);border-radius:18px;padding:34px 36px;width:340px;max-width:90vw;text-align:center;box-shadow:0 20px 60px rgba(0,0,0,.5)}
  .loginbox .lg{width:56px;height:56px;border-radius:15px;background:linear-gradient(135deg,var(--accent),var(--accent2));display:flex;align-items:center;justify-content:center;font-size:28px;margin:0 auto 16px;box-shadow:0 0 26px rgba(192,75,255,.5)}
  .loginbox h2{font-size:19px;margin-bottom:6px;letter-spacing:1px}
  .loginbox .lp{color:var(--muted);font-size:13px;margin-bottom:18px}
  .loginbox input{width:100%;background:var(--panel2);border:1px solid var(--line);border-radius:10px;padding:12px 14px;color:var(--txt);font-size:15px;margin-bottom:10px;text-align:center}
  .loginbox .err{color:var(--red);font-size:12px;min-height:16px;margin-bottom:8px}
  .loginbox button{width:100%}
  .field{display:flex;flex-direction:column;gap:6px;margin-bottom:12px;text-align:left}
  .field label{font-size:12px;color:var(--muted)}
  .field input,.field select{background:var(--panel2);border:1px solid var(--line);border-radius:9px;padding:9px 11px;color:var(--txt);font-size:14px}

  /* ===== Schwarz + Glas Redesign ===== */
  .card,.panelbox,.chip,.badge,.tile,.core,.lat .l,.loginbox,.side,.pulse{
    -webkit-backdrop-filter:blur(16px) saturate(140%);backdrop-filter:blur(16px) saturate(140%)}
  .card,.panelbox,.pulse{box-shadow:0 10px 34px rgba(0,0,0,.5),inset 0 1px 0 rgba(255,255,255,.06)}
  .side{background:#0d0c0f;border-right:1px solid var(--line)}
  .pulse{background:linear-gradient(120deg,rgba(255,65,114,.12),rgba(167,139,250,.06))}
  .out{background:rgba(0,0,0,.4);color:var(--green)}
  .loginwrap{background:radial-gradient(1000px 560px at 50% -10%,rgba(255,65,114,.16),#0a090d 60%)}
  .bar,.core .cbar,.ring,.score{background-color:rgba(255,255,255,.08)}
  /* Blitz-Cursor ueberall, Textfelder behalten Text-Cursor */
  .btn,.nav,.tile,.chip,.badge,select,a,button,label,summary{cursor:var(--bolt) 14 2,pointer}
  input[type=text],input[type=number],input[type=password],input[type=email],textarea{cursor:text}

  /* ===== Design-Feinschliff ===== */
  ::-webkit-scrollbar{width:11px;height:11px}
  ::-webkit-scrollbar-track{background:transparent}
  ::-webkit-scrollbar-thumb{background:rgba(255,65,114,.30);border-radius:8px;border:2px solid transparent;background-clip:padding-box}
  ::-webkit-scrollbar-thumb:hover{background:rgba(255,65,114,.55);background-clip:padding-box}
  .btn{transition:transform .12s,filter .12s,box-shadow .12s;box-shadow:0 4px 14px rgba(192,75,255,.22)}
  .btn:hover{transform:translateY(-1px);box-shadow:0 7px 20px rgba(192,75,255,.34)}
  .btn:active{transform:translateY(0)}
  .btn.ghost{box-shadow:none}
  .btn.danger{box-shadow:0 4px 14px rgba(255,91,110,.24)}
  .nav{transition:background .15s,color .15s,box-shadow .15s,transform .1s}
  .nav:hover{transform:translateX(2px)}
  .nav.active{box-shadow:inset 2px 0 0 var(--accent),0 0 22px rgba(192,75,255,.16)}
  .panelbox h3{position:relative;padding-left:12px}
  .panelbox h3::before{content:"";position:absolute;left:0;top:1px;bottom:1px;width:3px;border-radius:3px;background:linear-gradient(180deg,var(--accent),var(--accent2))}
  .card{transition:border-color .15s,transform .12s,box-shadow .12s}
  .side .logo,.loginbox .lg{animation:glow 3.2s ease-in-out infinite}
  @keyframes glow{0%,100%{box-shadow:0 0 18px rgba(255,65,114,.45)}50%{box-shadow:0 0 30px rgba(167,139,250,.55)}}
  .tw{transition:background .12s}
  .tw:hover{background:rgba(255,255,255,.02)}
  .note{backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px)}
  .page.active{animation:fadeIn .26s ease}
  @keyframes fadeIn{from{opacity:0;transform:translateY(7px)}to{opacity:1;transform:none}}
  /* ---- Personalisierung: Effekte ---- */
  .app{position:relative;z-index:2}
  body.reduce-motion *{animation:none!important;transition:none!important}
  body.bg-grid::before{content:"";position:fixed;inset:0;z-index:0;pointer-events:none;background-image:linear-gradient(rgba(255,255,255,.045) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.045) 1px,transparent 1px);background-size:34px 34px}
  #pcb-orbs{position:fixed;inset:0;z-index:0;pointer-events:none;overflow:hidden}
  #pcb-orbs span{position:absolute;width:360px;height:360px;border-radius:50%;filter:blur(90px);opacity:.4;animation:orbfloat 20s ease-in-out infinite}
  #pcb-orbs span:nth-child(1){background:var(--accent);top:-90px;left:4%}
  #pcb-orbs span:nth-child(2){background:var(--accent2);bottom:-110px;right:6%;animation-delay:-7s}
  #pcb-orbs span:nth-child(3){background:var(--blue);top:38%;left:58%;animation-delay:-14s}
  @keyframes orbfloat{0%,100%{transform:translate(0,0)}33%{transform:translate(50px,-40px)}66%{transform:translate(-40px,25px)}}
  #pcb-snow{position:fixed;inset:0;z-index:9999;pointer-events:none;overflow:hidden}
  #pcb-snow span{position:absolute;top:-24px;color:#fff;animation:snowfall linear infinite}
  @keyframes snowfall{to{transform:translateY(106vh)}}
  .card:hover{border-color:rgba(255,65,114,.30)}
  .brand b{background:linear-gradient(90deg,var(--accent),var(--accent2));-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent}
  input:focus,select:focus,textarea:focus{outline:none;border-color:var(--accent);box-shadow:0 0 0 3px rgba(192,75,255,.15)}
</style>
</head>
<body>
<div id="login" class="loginwrap">
  <div class="loginbox">
    <div class="lg">&#9889;</div>
    <h2 id="login-title">PC BOOST</h2>
    <div class="lp" id="login-sub">Bitte anmelden.</div>
    <button class="btn" id="login-discord" style="display:none;background:#5865F2;margin-bottom:10px" onclick="discordLogin()">&#128377;&#65039; Mit Discord anmelden</button>
    <div id="login-or" style="display:none;color:var(--muted);font-size:11px;margin:10px 0;letter-spacing:1px">&mdash;&nbsp; oder &nbsp;&mdash;</div>
    <input id="login-email" type="text" placeholder="Benutzername" autocomplete="off" style="display:none" onkeydown="if(event.key==='Enter')loginAction()">
    <input id="login-pw" type="password" placeholder="Passwort" autocomplete="off" style="display:none" onkeydown="if(event.key==='Enter')loginAction()">
    <input id="login-code" type="text" inputmode="numeric" placeholder="Code" autocomplete="off" style="display:none" onkeydown="if(event.key==='Enter')loginAction()">
    <div class="err" id="login-err"></div>
    <button class="btn" id="login-btn" style="display:none" onclick="loginAction()">Anmelden</button>
    <div class="lp" id="login-toggle" style="display:none;cursor:pointer;color:var(--accent);margin-top:12px" onclick="toggleMode()">Noch kein Konto? Konto erstellen</div>
    <div class="lp" id="login-resend" style="display:none;cursor:pointer;color:var(--accent);margin-top:8px" onclick="resendCode()">Neuen Code senden</div>
  </div>
</div>
<div class="app">
  <!-- ===================== SIDEBAR ===================== -->
  <aside class="side">
    <div class="brand">
      <div class="logo">&#9889;</div>
      <div><b>PC BOOST</b><small>Setup &amp; Tweaks</small></div>
    </div>
    <div class="gamebadge" onclick="showCat('leistung');showSub('gaming')"><span>&#127918;</span> PC Boost Game Mode</div>
    <div class="navgrp">START</div>
    <div class="nav active" data-cat="overview" onclick="showCat('overview')"><span class="ic">&#127968;</span> &Uuml;bersicht</div>
    <div class="nav" data-cat="monitor" onclick="showCat('monitor')"><span class="ic">&#128200;</span> Monitor</div>
    <div class="navgrp">OPTIMIEREN</div>
    <div class="nav" data-cat="leistung" onclick="showCat('leistung')"><span class="ic">&#9889;</span> Leistung</div>
    <div class="nav" data-cat="anpassen" onclick="showCat('anpassen')"><span class="ic">&#127912;</span> Anpassen</div>
    <div class="navgrp">SICHERHEIT</div>
    <div class="nav" data-cat="sicherheit" onclick="showCat('sicherheit')"><span class="ic">&#128737;&#65039;</span> Sicherheit</div>
    <div class="navgrp">WERKZEUGE</div>
    <div class="nav" data-cat="netzwerk" onclick="showCat('netzwerk')"><span class="ic">&#127760;</span> Netzwerk &amp; Fixes</div>
    <div class="nav" data-cat="werkzeuge" onclick="showCat('werkzeuge')"><span class="ic">&#129520;</span> Werkzeuge</div>
    <div class="navgrp">SYSTEM</div>
    <div class="nav" data-cat="system" onclick="showCat('system')"><span class="ic">&#128190;</span> System</div>
    <div class="foot" id="adminFoot">
      <button class="btn ghost sm" style="width:100%;margin-bottom:6px" onclick="location.reload()">&#128260; Alles aktualisieren</button>
      <button class="btn ghost sm" style="width:100%;margin-bottom:8px" onclick="appBeenden()">&#9209;&#65039; PC Boost beenden</button>
      PC Boost v5.0 &bull; lokal &nbsp;<span style="color:var(--accent);cursor:pointer" onclick="logout()">Abmelden</span>
    </div>
  </aside>

  <!-- ===================== MAIN ===================== -->
  <main class="main">
    <div class="top">
      <div><div style="color:var(--accent);font-size:11px;font-weight:700;letter-spacing:2px;margin-bottom:2px">PC BOOST</div><h1 id="pageTitle">&Uuml;bersicht</h1><div class="sub" id="pageSub">Systemstatus und Hardware auf einen Blick.</div></div>
      <div class="badges">
        <span class="chip"><span class="live"><span class="dot"></span>Live</span></span>
        <span class="chip">CPU <b id="hCpu" class="mono">--%</b></span>
        <span class="chip">GPU <b id="hGpu" class="mono">--%</b></span>
        <span class="chip mono" id="hClock">--:--:--</span>
      </div>
    </div>
    <div id="subtabs" class="subtabs"></div>

    <!-- ===== PAGE: OVERVIEW ===== -->
    <section class="page active" id="page-overview">
      <div class="grid" id="ov-tiles"></div>
      <div class="panelbox">
        <h3>LIVE-AUSLASTUNG</h3>
        <div id="ov-live">
          <div class="tw" style="border:none;padding:6px 0"><div style="min-width:120px"><b>CPU</b> <span class="mono" id="ovl-cpu-v" style="color:var(--muted)">--%</span></div><span style="flex:1;height:9px;border-radius:6px;background:rgba(255,255,255,.06);overflow:hidden"><i id="ovl-cpu" style="display:block;height:100%;width:0;background:linear-gradient(90deg,var(--accent),var(--accent2));transition:width .5s"></i></span></div>
          <div class="tw" style="border:none;padding:6px 0"><div style="min-width:120px"><b>Arbeitsspeicher</b> <span class="mono" id="ovl-ram-v" style="color:var(--muted)">--%</span></div><span style="flex:1;height:9px;border-radius:6px;background:rgba(255,255,255,.06);overflow:hidden"><i id="ovl-ram" style="display:block;height:100%;width:0;background:linear-gradient(90deg,var(--purple),var(--accent));transition:width .5s"></i></span></div>
          <div class="tw" style="border:none;padding:6px 0"><div style="min-width:120px"><b>GPU</b> <span class="mono" id="ovl-gpu-v" style="color:var(--muted)">--%</span></div><span style="flex:1;height:9px;border-radius:6px;background:rgba(255,255,255,.06);overflow:hidden"><i id="ovl-gpu" style="display:block;height:100%;width:0;background:linear-gradient(90deg,var(--blue),var(--green));transition:width .5s"></i></span></div>
        </div>
      </div>
      <div class="cols">
        <div class="panelbox"><h3>PROZESSOR</h3><div id="ov-cpu"></div></div>
        <div class="panelbox"><h3>GRAFIKKARTE</h3><div id="ov-gpu"></div></div>
      </div>
      <div class="panelbox"><h3>PC AUFGESETZT</h3><div id="ov-setup"></div></div>
    </section>

    <!-- ===== PAGE: MONITOR ===== -->
    <section class="page" id="page-monitor">
      <div id="cputempwarn" class="note" style="display:none">
        &#9888;&#65039; CPU-Temperatur braucht Adminrechte &ndash; starte PC Boost neu und best&auml;tige die Windows-Nachfrage (UAC) mit &bdquo;Ja&ldquo;. Alles andere ist echt.
      </div>
      <div class="pulse">
        <div class="score" id="scoreRing"><div class="inner"><b id="vibe" class="mono">--</b><span>VIBE</span></div></div>
        <div class="txt">
          <span class="tag" id="mood">SYSTEM PULSE</span>
          <h2>System Pulse</h2>
          <p id="pulseText">Sammle Daten &hellip;</p>
        </div>
        <div class="badges">
          <div class="badge">GPU <b id="bGpu" class="mono">--%</b></div>
          <div class="badge" id="bUp">Laufzeit --</div>
        </div>
      </div>
      <div class="grid">
        <div class="card">
          <div class="head"><span class="lbl">CPU</span><span class="val mono" id="cpuPct">--%</span></div>
          <div class="row"><div class="ring" id="cpuRing"><div class="hole mono" id="cpuTemp">--</div></div>
            <div class="sub"><b id="cpuName">Prozessor</b><br><span id="cpuCores">-- Kerne</span></div></div>
        </div>
        <div class="card">
          <div class="head"><span class="lbl">RAM</span><span class="val mono" id="ramPct">--%</span></div>
          <div class="row"><div class="ring" id="ramRing" style="--rc:var(--accent2)"><div class="hole mono" id="ramGB">--</div></div>
            <div class="sub"><b id="ramUsed">-- GB</b> belegt<br><span id="ramTotal">von -- GB</span></div></div>
          <div class="bar"><i id="ramBar" style="width:0%"></i></div>
        </div>
        <div class="card">
          <div class="head"><span class="lbl">GPU</span><span class="val mono" id="gpuPct">--%</span></div>
          <div class="row"><div class="ring" id="gpuRing" style="--rc:var(--green)"><div class="hole mono" id="gpuTemp">--</div></div>
            <div class="sub"><b id="gpuName">Grafikkarte</b><br><span id="gpuMem">-- / -- GB</span></div></div>
          <div class="sub mono" id="gpuExtra" style="margin-top:10px;color:var(--muted)"></div>
        </div>
        <div class="card">
          <div class="head"><span class="lbl">NETZWERK</span><span class="val mono" style="font-size:18px">Mbit/s</span></div>
          <div class="row" style="gap:26px">
            <div><div class="sub">&darr; Empfang</div><div class="mono" style="font-size:22px;color:var(--blue)" id="rx">--</div></div>
            <div><div class="sub">&uarr; Sendung</div><div class="mono" style="font-size:22px;color:var(--accent2)" id="tx">--</div></div>
          </div>
        </div>
      </div>
      <div class="panelbox"><h3>PROZESSORKERNE</h3><div class="cores" id="cores"></div></div>
      <div class="cols">
        <div class="panelbox"><h3>SPEICHER</h3><div id="disks"></div></div>
        <div class="panelbox"><h3>VERLAUF &mdash; CPU (lila) &amp; GPU (gruen)</h3><canvas id="chart" width="600" height="150"></canvas></div>
      </div>
    </section>

    <!-- ===== PAGE: HARDWARE ===== -->
    <section class="page" id="page-hardware">
      <div class="panelbox">
        <h3>LIVE-STATUS</h3>
        <div id="hw-live" class="cols" style="gap:24px">
          <div>
            <div class="row" style="justify-content:space-between;margin-bottom:6px"><b>CPU</b><span class="mono" style="color:var(--muted)"><span id="hw-cpu-load">--</span>% &middot; <span id="hw-cpu-temp">--</span></span></div>
            <div style="height:10px;background:var(--panel2);border-radius:6px;overflow:hidden"><div id="hw-cpu-bar" style="height:100%;width:0;background:linear-gradient(90deg,var(--accent),var(--accent2));transition:width .5s"></div></div>
          </div>
          <div>
            <div class="row" style="justify-content:space-between;margin-bottom:6px"><b>Grafikkarte</b><span class="mono" style="color:var(--muted)"><span id="hw-gpu-load">--</span>% &middot; <span id="hw-gpu-temp">--</span></span></div>
            <div style="height:10px;background:var(--panel2);border-radius:6px;overflow:hidden"><div id="hw-gpu-bar" style="height:100%;width:0;background:linear-gradient(90deg,var(--accent),var(--accent2));transition:width .5s"></div></div>
          </div>
          <div>
            <div class="row" style="justify-content:space-between;margin-bottom:6px"><b>Arbeitsspeicher</b><span class="mono" style="color:var(--muted)"><span id="hw-ram-load">--</span>% &middot; <span id="hw-ram-gb">--</span></span></div>
            <div style="height:10px;background:var(--panel2);border-radius:6px;overflow:hidden"><div id="hw-ram-bar" style="height:100%;width:0;background:linear-gradient(90deg,var(--accent),var(--accent2));transition:width .5s"></div></div>
          </div>
        </div>
      </div>
      <div class="cols">
        <div class="panelbox"><h3>PROZESSOR</h3><div id="hw-cpu"></div></div>
        <div class="panelbox"><h3>GRAFIKKARTE</h3><div id="hw-gpu"></div></div>
      </div>
      <div class="cols">
        <div class="panelbox"><h3>ARBEITSSPEICHER</h3><div id="hw-ram"></div></div>
        <div class="panelbox"><h3>SYSTEM</h3><div id="hw-sys"></div></div>
      </div>
      <div class="panelbox"><h3>SPEICHERPLATZ</h3><div id="hw-vols"></div></div>
      <div class="panelbox"><h3>LAUFWERKE</h3><div id="hw-disks"></div></div>
      <div class="panelbox">
        <div class="row" style="justify-content:space-between;align-items:center;margin-bottom:6px">
          <h3 style="margin:0">WICHTIGE TREIBER</h3>
          <button class="btn ghost sm" id="drv-btn" onclick="loadDrivers()">Treiber pruefen</button>
        </div>
        <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Grafik, Netzwerk, Audio &amp; Speicher. Aelter als 2 Jahre wird markiert &ndash; dann lohnt evtl. ein Treiber-Update.</p>
        <div id="drv-list"></div>
      </div>
    </section>

    <!-- ===== PAGE: GAMING ===== -->
    <section class="page" id="page-gaming">
      <div class="note">&#9432; Diese Seite &auml;ndert echte Windows-Einstellungen. Alles ist umkehrbar (Schalter zur&uuml;ck / Energieplan wechseln). Tipp: vorher unter <b>Backup</b> einen Wiederherstellungspunkt erstellen.</div>
      <div class="panelbox" style="border-color:rgba(53,224,161,.35)">
        <h3>&#127919; STARTPAKET &ndash; falls du nicht weisst, wo anfangen</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:12px">
          Setzt 11 Schalter auf eine vorsichtige Grundeinstellung: Game DVR und Xbox-Aufnahme aus, Hintergrund-Apps aus,
          Telemetrie und Werbe-ID aus, Dateiendungen sichtbar. <b>Kein Neustart noetig</b>, keine Dienste angefasst, die Optik bleibt unveraendert.
          Jede Aenderung steht danach unter <b>Leistung &rarr; Aenderungen</b> und laesst sich einzeln oder komplett zuruecknehmen.
        </p>
        <button class="btn" onclick="empfohlenAnwenden(this)">Empfohlene Einstellungen anwenden</button>
        <div class="out" id="empf-out"></div>
      </div>
      <div class="panelbox">
        <h3>GAMING-SESSION</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Ein Klick: Energieplan auf <b>H&ouml;chstleistung</b> und Hintergrund-Apps (Discord, Spotify, Launcher &hellip;) beenden. &bdquo;Session beenden&ldquo; stellt den Energieplan wieder her. Browser werden <b>nicht</b> geschlossen.</p>
        <div class="row" style="gap:10px;flex-wrap:wrap">
          <button class="btn" onclick="runAsyncG('gamingstart',this,'Aktiviere Gaming')">&#127918; Alles f&uuml;r Gaming</button>
          <button class="btn ghost" onclick="runAsyncG('gamingstop',this,'Beende Session')">Session beenden</button>
        </div>
        <div class="out" id="gaming-out"></div>
      </div>
      <div class="panelbox">
        <h3>&#127918; GAMING-OVERLAY</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:14px">Ein kleines Fenster, das <b>immer im Vordergrund</b> bleibt &ndash; auch ueber deinem Spiel (randloser Fenstermodus). Zeigt live deine Werte mit farbigen Balken. Frei verschiebbar. Aenderungen unten werden bei laufendem Overlay automatisch uebernommen.</p>
        <div class="cols">
          <div>
            <label style="font-size:12px;color:var(--muted)">Angezeigte Werte</label>
            <div class="row" style="gap:14px 18px;flex-wrap:wrap;margin:8px 0 4px">
              <label style="display:flex;align-items:center;gap:6px;font-size:13px"><input type="checkbox" id="ovm-cpu" checked onchange="ovApply()">CPU-Last</label>
              <label style="display:flex;align-items:center;gap:6px;font-size:13px"><input type="checkbox" id="ovm-cpuTemp" checked onchange="ovApply()">CPU-Temp</label>
              <label style="display:flex;align-items:center;gap:6px;font-size:13px"><input type="checkbox" id="ovm-gpu" checked onchange="ovApply()">GPU-Last</label>
              <label style="display:flex;align-items:center;gap:6px;font-size:13px"><input type="checkbox" id="ovm-gpuTemp" checked onchange="ovApply()">GPU-Temp</label>
              <label style="display:flex;align-items:center;gap:6px;font-size:13px"><input type="checkbox" id="ovm-vram" onchange="ovApply()">VRAM</label>
              <label style="display:flex;align-items:center;gap:6px;font-size:13px"><input type="checkbox" id="ovm-ram" checked onchange="ovApply()">RAM</label>
              <label style="display:flex;align-items:center;gap:6px;font-size:13px"><input type="checkbox" id="ovm-gpuClock" onchange="ovApply()">GPU-Takt</label>
              <label style="display:flex;align-items:center;gap:6px;font-size:13px"><input type="checkbox" id="ovm-gpuPower" onchange="ovApply()">GPU-Watt</label>
              <label style="display:flex;align-items:center;gap:6px;font-size:13px"><input type="checkbox" id="ovm-net" onchange="ovApply()">Netzwerk</label>
              <label style="display:flex;align-items:center;gap:6px;font-size:13px"><input type="checkbox" id="ovm-clock" onchange="ovApply()">Uhrzeit</label>
              <label style="display:flex;align-items:center;gap:6px;font-size:13px"><input type="checkbox" id="ovm-input" checked onchange="ovApply()">Makro/Klicker-Status</label>
            </div>
          </div>
          <div>
            <div class="row" style="gap:16px;flex-wrap:wrap;align-items:flex-end">
              <div class="field" style="margin:0"><label>Position</label>
                <select id="ov-pos" onchange="ovApply()"><option value="tl">Oben links</option><option value="tr">Oben rechts</option><option value="bl">Unten links</option><option value="br">Unten rechts</option></select>
              </div>
              <div class="row" style="gap:8px;align-items:center"><label style="font-size:13px">Farbe</label><input type="color" id="ov-accent" value="#ff4172" onchange="ovApply()" style="width:46px;height:32px;border:none;background:none;cursor:pointer"></div>
              <div class="row" style="gap:8px;align-items:center"><input type="checkbox" id="ov-graph" checked onchange="ovApply()"><label for="ov-graph" style="font-size:13px;cursor:pointer">Verlaufsgraph <span style="color:var(--muted);font-size:11px">(aus = kompakte Balken)</span></label></div>
            </div>
            <div class="field" style="margin:12px 0 0"><label>Groesse: <b id="ov-scale-lbl">100</b>%</label><input type="range" id="ov-scale" min="70" max="180" value="100" oninput="$('ov-scale-lbl').textContent=this.value;ovApply()" style="width:100%"></div>
            <div class="field" style="margin:10px 0 0"><label>Transparenz: <b id="ov-op-lbl">85</b>%</label><input type="range" id="ov-op" min="30" max="100" value="85" oninput="$('ov-op-lbl').textContent=this.value;ovApply()" style="width:100%"></div>
          </div>
        </div>
        <div class="row" style="gap:10px;flex-wrap:wrap;margin-top:14px">
          <button class="btn" onclick="overlayToggle('on',this)">&#128065;&#65039; Overlay einblenden</button>
          <button class="btn ghost" onclick="overlayToggle('off',this)">Overlay ausblenden</button>
        </div>
        <div class="out" id="overlay-out"></div>
      </div>
      <div class="cols">
        <div class="panelbox"><h3>ENERGIEPLAN</h3><div id="plans" class="row" style="gap:10px;flex-wrap:wrap"></div></div>
        <div class="panelbox"><h3>SYSTEM-TWEAKS</h3><div id="tweaks"></div></div>
      </div>
      <div class="cols">
        <div class="panelbox"><h3>MEHR FPS</h3><div id="fps-tweaks"></div></div>
        <div class="panelbox"><h3>INPUT-LAG &amp; LATENZ</h3><div id="lat-tweaks"></div></div>
      </div>
      <div class="cols">
        <div class="panelbox"><h3>WINDOWS-OPTIMIERUNGEN</h3><div id="win-tweaks"></div></div>
        <div class="panelbox"><h3>PERFORMANCE &amp; SYSTEM</h3><div id="perf-tweaks"></div></div>
      </div>
    </section>

    <!-- ===== PAGE: OVERCLOCK (nur Monitor) ===== -->
    <section class="page" id="page-overclock">
      <div class="note">&#9432; <b>Live-Monitor + sicheres GPU-Tuning.</b> PC Boost aendert keine Taktraten/Spannungen (das kann abstuerzen) &ndash; aber du kannst das <b>Power-Limit</b> deiner NVIDIA-GPU regeln. Das ist ungefaehrlich: die Karte laesst nur ihren eigenen erlaubten Bereich zu, und alles ist per Klick umkehrbar.</div>
      <div class="panelbox">
        <h3>GRAFIKKARTE (LIVE)</h3>
        <div id="oc-gpuname" style="font-size:16px;font-weight:700;margin-bottom:14px">--</div>
        <div class="grid" id="oc-gpu"></div>
      </div>
      <div class="panelbox" id="oc-tune-box">
        <h3>GPU-POWER-LIMIT (echtes Tuning)</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:14px">Weniger Watt = kuehler &amp; leiser (etwas weniger Leistung). Mehr Watt = volle Leistung. Braucht Adminrechte (PC-Boost als Admin starten).</p>
        <div id="oc-tune"><div class="kv"><span>Pruefe GPU &hellip;</span></div></div>
        <div class="out" id="oc-tune-out"></div>
      </div>

      <div class="panelbox" style="border:1px solid rgba(222,59,40,.5)">
        <h3 style="color:var(--red)">&#9888;&#65039; UEBERTAKTEN &ndash; UNSICHER, AUF EIGENE GEFAHR</h3>
        <div class="note" style="background:rgba(222,59,40,.10);border-color:rgba(222,59,40,.4);color:#ff9a8a">
          <b>Warnung:</b> Uebertakten zwingt die Hardware ans Limit. Das kann zu <b>Abstuerzen, Grafikfehlern oder Instabilitaet</b> fuehren. Alles hier ist <b>umkehrbar</b> (Zuruecksetzen-Knopf) und bleibt innerhalb der von der Karte erlaubten Grenzen &ndash; trotzdem: nur nutzen, wenn du weisst, was du tust. Bei Problemen: <b>Zuruecksetzen + Neustart</b>.
        </div>
        <div id="oc-oc"><div class="kv"><span>Pruefe GPU &hellip;</span></div></div>
        <div class="out" id="oc-oc-out"></div>
      </div>

      <div class="panelbox">
        <h3>PROZESSOR &amp; RAM &ndash; UEBERTAKTEN</h3>
        <div class="note">&#9432; <b>Ehrlich:</b> Echtes CPU-/RAM-Uebertakten geht <b>nicht</b> aus Windows heraus &ndash; nur im <b>BIOS/UEFI</b> (RAM: XMP/EXPO aktivieren; CPU: Multiplikator/Spannung) oder mit <b>Ryzen Master / Intel XTU</b> (eigene Kernel-Treiber). PC Boost kann stattdessen alle <b>Bremsen loesen</b> (Dauer-Hoechsttakt, kein Throttling).</div>
        <div class="row" style="gap:10px;flex-wrap:wrap">
          <button class="btn" onclick="show('maxperf')">&#9889; Zur Max-Leistung (alle Bremsen loesen)</button>
          <button class="btn ghost" onclick="ocCpuMax(this)">CPU: Dauer-Hoechsttakt</button>
        </div>
        <div class="out" id="oc-cpu2-out"></div>
      </div>

      <div class="panelbox">
        <h3>&#128421;&#65039; BILDSCHIRM-TAKT (AKTUALISIERUNGSRATE)</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Viele Monitore laufen versehentlich auf 60 Hz, koennen aber mehr. Hoehere Hz = fluessigeres Bild. Sicher &amp; umkehrbar.</p>
        <div id="oc-refresh"><div class="kv"><span>Pruefe Bildschirm &hellip;</span></div></div>
        <div class="out" id="oc-refresh-out"></div>
      </div>

      <div class="panelbox">
        <h3>PROZESSOR (LIVE)</h3>
        <div class="grid" id="oc-cpu"></div>
      </div>
    </section>

    <!-- ===== PAGE: PERSONALISIERUNG ===== -->
    <section class="page" id="page-personalize">
      <div class="note">&#9432; Passe Windows nach deinem Geschmack an &ndash; Taskleiste, Explorer, Optik, Maus. <b>Alles umkehrbar.</b> Taskleisten-/Explorer-Aenderungen werden erst nach <b>Explorer neu starten</b> sichtbar.</div>
      <div class="cols">
        <div class="panelbox">
          <h3>TASKLEISTE &amp; EXPLORER</h3>
          <div id="pers-tweaks"></div>
          <button class="btn" style="margin-top:12px" onclick="runAsyncP('explorerrestart',this,'Starte Explorer neu')">&#128260; Explorer neu starten (Aenderungen uebernehmen)</button>
          <div class="out" id="pers-out"></div>
        </div>
        <div class="panelbox">
          <h3>OPTIK &amp; BEDIENUNG</h3>
          <div class="tw"><div><b>Klassisches Rechtsklick-Menue (Win11)</b><br><span style="color:var(--muted);font-size:12px">Das volle alte Menue statt des gekuerzten.</span></div><div style="display:flex;gap:6px;flex:none"><button class="btn sm" onclick="runAsyncP2('ctxmenu','on',this)">An</button><button class="btn ghost sm" onclick="runAsyncP2('ctxmenu','off',this)">Aus</button></div></div>
          <div class="tw"><div><b>Maus-Beschleunigung</b><br><span style="color:var(--muted);font-size:12px">Aus = 1:1-Bewegung, praeziser fuers Zielen.</span></div><div style="display:flex;gap:6px;flex:none"><button class="btn sm" onclick="runAsyncP2('mouseaccel','off',this)">Aus</button><button class="btn ghost sm" onclick="runAsyncP2('mouseaccel','on',this)">An</button></div></div>
          <div class="tw"><div><b>System-Design</b><br><span style="color:var(--muted);font-size:12px">Dunkel oder Hell fuer Windows &amp; Apps.</span></div><div style="display:flex;gap:6px;flex:none"><button class="btn sm" onclick="runAsyncP2('darkmode','dark',this)">Dunkel</button><button class="btn ghost sm" onclick="runAsyncP2('darkmode','light',this)">Hell</button></div></div>
          <div class="tw"><div><b>Visuelle Effekte</b><br><span style="color:var(--muted);font-size:12px">Beste Leistung = weniger Animationen, schneller.</span></div><div style="display:flex;gap:6px;flex:none"><button class="btn sm" onclick="runAsyncP2('visualfx','perf',this)">Leistung</button><button class="btn ghost sm" onclick="runAsyncP2('visualfx','appearance',this)">Optik</button></div></div>
          <div class="out" id="pers-out2"></div>
        </div>
      </div>
    </section>

    <!-- ===== PAGE: FIXES ===== -->
    <section class="page" id="page-fixes">
      <div class="note">&#9432; Ein-Klick-Reparaturen f&uuml;r h&auml;ufige Probleme. Manche brauchen danach einen Neustart (ist markiert). Bei tiefen Reparaturen vorher unter <b>Backup</b> einen Wiederherstellungspunkt erstellen.</div>
      <div class="panelbox">
        <div class="row" style="justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:12px">
          <h3 style="margin:0">REPARATUREN <span id="fix-count" style="color:var(--muted);font-weight:400">&mdash;</span></h3>
          <input id="fix-search" placeholder="Reparatur suchen &hellip;" oninput="renderFixes()" style="background:var(--panel2);border:1px solid var(--line);border-radius:9px;padding:8px 12px;color:var(--txt);font-size:13px;width:220px">
        </div>
        <div class="row" id="fix-cats" style="gap:8px;flex-wrap:wrap;margin-bottom:14px"></div>
        <div id="fix-list"></div><div class="out" id="fix-out"></div>
      </div>
    </section>


    <!-- ===== PAGE: AUTOTOOLS ===== -->
    <section class="page" id="page-autotools">
      <div class="note">&#9888;&#65039; Auto-Klicker &amp; Tasten-Wiederholer bewegen echte Maus/Tastatur. Der Klick passiert an der <b>aktuellen Mausposition</b> oder an einer <b>festen Position</b> (X/Y). Nach dem Start hast du die Vorlaufzeit, um alles vorzubereiten. Stoppen jederzeit mit dem roten Knopf. Manche Online-Spiele verbieten Automatisierung &ndash; nutze es fair.</div>
      <div class="cols">
        <div class="panelbox">
          <h3>AUTO-KLICKER</h3>
          <label style="font-size:12px;color:var(--muted)">Klick-Intervall</label>
          <div class="row" style="gap:6px;flex-wrap:wrap;align-items:center;margin:6px 0 12px">
            <input id="ac-h" type="number" value="0" min="0" style="width:60px"><span style="font-size:12px;color:var(--muted)">h</span>
            <input id="ac-m" type="number" value="0" min="0" style="width:60px"><span style="font-size:12px;color:var(--muted)">min</span>
            <input id="ac-s" type="number" value="0" min="0" style="width:60px"><span style="font-size:12px;color:var(--muted)">s</span>
            <input id="ac-ms" type="number" value="100" min="0" style="width:70px"><span style="font-size:12px;color:var(--muted)">ms</span>
          </div>
          <div class="row" style="gap:8px;align-items:center;margin-bottom:12px">
            <label style="font-size:13px;display:flex;align-items:center;gap:6px;cursor:pointer"><input id="ac-rndon" type="checkbox">Zufalls-Abweichung &plusmn;</label>
            <input id="ac-rnd" type="number" value="40" min="0" style="width:70px"><span style="font-size:12px;color:var(--muted)">ms</span>
          </div>
          <div class="row" style="gap:12px;flex-wrap:wrap">
            <div class="field" style="margin:0"><label>Maustaste</label><select id="ac-btn"><option value="left">Links</option><option value="right">Rechts</option><option value="middle">Mitte</option></select></div>
            <div class="field" style="margin:0"><label>Klick-Typ</label><select id="ac-type"><option value="single">Einzel</option><option value="double">Doppel</option></select></div>
            <div class="field" style="margin:0"><label>Anzahl (0 = unbegrenzt)</label><input id="ac-limit" type="number" value="0" min="0" style="width:120px"></div>
          </div>
          <label style="font-size:12px;color:var(--muted);display:block;margin-top:12px">Klick-Position</label>
          <div class="row" style="gap:14px;flex-wrap:wrap;align-items:center;margin:6px 0">
            <label style="font-size:13px;display:flex;align-items:center;gap:6px;cursor:pointer"><input type="radio" name="ac-pos" value="cur" checked onchange="acPosMode()">Aktuelle Position</label>
            <label style="font-size:13px;display:flex;align-items:center;gap:6px;cursor:pointer"><input type="radio" name="ac-pos" value="fix" onchange="acPosMode()">Feste Position</label>
            <input id="ac-x" type="number" value="0" style="width:74px" placeholder="X" disabled>
            <input id="ac-y" type="number" value="0" style="width:74px" placeholder="Y" disabled>
            <button class="btn ghost sm" id="ac-pick" onclick="acPick()" disabled>Position w&auml;hlen</button>
          </div>
          <div class="field" style="margin:6px 0 12px"><label>Start-Vorlaufzeit (Sekunden)</label><input id="ac-delay" type="number" value="3" min="0" max="10" style="width:120px"></div>
          <div class="row" style="gap:10px"><button class="btn" onclick="autoStart()">Start</button><button class="btn danger" onclick="stopInput()">Stopp</button></div>
          <div class="out" id="ac-status"></div>
        </div>
        <div class="panelbox">
          <h3>TASTEN-WIEDERHOLER</h3>
          <div class="field"><label>Taste</label><select id="kr-key">
            <option value="32">Leertaste</option><option value="87">W</option><option value="65">A</option><option value="83">S</option><option value="68">D</option>
            <option value="69">E</option><option value="81">Q</option><option value="82">R</option><option value="70">F</option><option value="16">Shift</option>
            <option value="17">Strg</option><option value="13">Enter</option><option value="112">F1</option></select></div>
          <div class="field"><label>&nbsp;</label><button class="btn ghost" onclick="captureHotkey('kr-key',this)">&#9000;&#65039; Taste dr&uuml;cken</button></div>
          <div class="field"><label>Intervall (ms)</label><input id="kr-interval" type="number" value="100" min="10"></div>
          <div class="field"><label>Anzahl (0 = unbegrenzt)</label><input id="kr-limit" type="number" value="0" min="0"></div>
          <div class="field"><label>Start-Vorlaufzeit (Sekunden)</label><input id="kr-delay" type="number" value="3" min="0" max="10"></div>
          <div class="row" style="gap:10px"><button class="btn" onclick="keyStart()">Start</button><button class="btn danger" onclick="stopInput()">Stopp</button></div>
          <div class="out" id="kr-status"></div>
        </div>
      </div>
      <div class="panelbox">
        <h3>MAKRO-EDITOR (eigene Tastenfolge)</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Baue eine Abfolge aus Tasten und Klicks mit Pausen &ndash; wird der Reihe nach abgespielt. Ideal fuer wiederkehrende Ablaeufe.</p>
        <div class="row" style="gap:10px;flex-wrap:wrap;align-items:flex-end">
          <div class="field" style="margin:0"><label>Aktion</label><select id="mac-key">
            <option value="cl">Linksklick</option><option value="cr">Rechtsklick</option>
            <option value="32">Leertaste</option><option value="87">W</option><option value="65">A</option><option value="83">S</option><option value="68">D</option>
            <option value="69">E</option><option value="81">Q</option><option value="82">R</option><option value="70">F</option><option value="16">Shift</option>
            <option value="17">Strg</option><option value="13">Enter</option><option value="9">Tab</option>
            <option value="37">Pfeil links</option><option value="38">Pfeil hoch</option><option value="39">Pfeil rechts</option><option value="40">Pfeil runter</option>
            <option value="49">1</option><option value="50">2</option><option value="51">3</option><option value="112">F1</option></select></div>
          <div class="field" style="margin:0"><label>Pause danach (ms)</label><input id="mac-delay" type="number" value="100" min="0" style="width:120px"></div>
          <button class="btn ghost" onclick="macAdd()">Schritt hinzuf&uuml;gen</button>
        </div>
        <div id="mac-steps" style="margin-top:12px"></div>
        <div class="row" style="gap:10px;flex-wrap:wrap;align-items:flex-end;margin-top:12px">
          <div class="field" style="margin:0"><label>Wiederholungen (0 = unbegrenzt)</label><input id="mac-loops" type="number" value="1" min="0" style="width:150px"></div>
          <div class="field" style="margin:0"><label>Start-Vorlaufzeit (s)</label><input id="mac-start" type="number" value="3" min="0" max="10" style="width:120px"></div>
          <button class="btn" onclick="macStart()">Makro abspielen</button>
          <button class="btn danger" onclick="stopInput()">Stopp</button>
          <button class="btn ghost" onclick="macClear()">Leeren</button>
        </div>
        <div class="row" style="gap:10px;flex-wrap:wrap;align-items:flex-end;margin-top:10px;border-top:1px solid var(--line);padding-top:12px">
          <div class="field" style="margin:0"><label>Hotkey &ndash; spielt das Makro auf Tastendruck (auch im Spiel)</label><select id="mac-hotkey">
            <option value="119">F8</option><option value="120">F9</option><option value="121">F10</option><option value="118">F7</option><option value="117">F6</option><option value="115">F4</option><option value="45">Einfg</option><option value="34">Bild ab</option></select></div>
          <button class="btn ghost" onclick="captureHotkey('mac-hotkey',this)" data-echo="mac-hkecho">&#9000;&#65039; Taste dr&uuml;cken</button>
          <button class="btn" onclick="macArm()">Hotkey aktivieren</button>
          <button class="btn danger" onclick="macDisarm()">Hotkey aus</button>
          <span id="mac-hkecho" style="color:var(--muted);font-size:12px"></span>
        </div>
        <div class="out" id="mac-status"></div>
      </div>
    </section>

    <!-- ===== PAGE: TOOLBOX ===== -->
    <section class="page" id="page-toolbox">
      <div class="cols">
        <div class="panelbox">
          <h3>&#128421;&#65039; FENSTER-MANAGER</h3>
          <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Alle offenen Fenster &ndash; in den Vordergrund holen, immer oben halten oder schliessen.</p>
          <button class="btn ghost sm" onclick="loadWindows()">Aktualisieren</button>
          <div id="win-list" style="margin-top:12px"></div>
        </div>
        <div class="panelbox">
          <h3>&#128247; SCREENSHOT</h3>
          <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Nimmt den gesamten Bildschirm auf und speichert ihn als PNG (Desktop-Ordner &bdquo;PC-Boost&ldquo;).</p>
          <button class="btn" id="shot-btn" onclick="takeShot()">&#128247; Screenshot aufnehmen</button>
          <div class="out" id="shot-out"></div>
        </div>
      </div>
      <div class="cols">
        <div class="panelbox">
          <h3>&#127752; FARB-PICKER</h3>
          <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Liest die Farbe unter dem Mauszeiger. Nach dem Klick hast du die Vorlaufzeit, um den Zeiger zu positionieren.</p>
          <div class="row" style="gap:10px;align-items:flex-end;flex-wrap:wrap">
            <div class="field" style="margin:0"><label>Vorlaufzeit (s)</label><input id="cp-delay" type="number" value="3" min="0" max="10" style="width:110px"></div>
            <button class="btn" id="cp-btn" onclick="pickColor()">Farbe aufnehmen</button>
          </div>
          <div id="cp-result" style="display:none;margin-top:14px;align-items:center;gap:14px">
            <div id="cp-swatch" style="width:56px;height:56px;border-radius:12px;border:2px solid var(--line);flex:none"></div>
            <div><div class="mono" id="cp-hex" style="font-size:20px;font-weight:700"></div><div class="mono" id="cp-rgb" style="color:var(--muted);font-size:13px"></div></div>
            <button class="btn ghost sm" onclick="cpCopy()">HEX kopieren</button>
          </div>
        </div>
        <div class="panelbox">
          <h3>&#129529; DATEI-SHREDDER</h3>
          <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Ueberschreibt eine Datei 3x mit Zufallsdaten und loescht sie dann &ndash; <b>unwiederbringlich</b>. System-/Programm-Ordner sind gesperrt.</p>
          <div class="field"><label>Vollstaendiger Pfad zur Datei</label><input id="shred-path" type="text" placeholder="z.B. C:\Users\Du\Downloads\geheim.txt"></div>
          <button class="btn danger" id="shred-btn" onclick="shredFile()">&#129529; Sicher &amp; endgueltig loeschen</button>
          <div class="out" id="shred-out"></div>
        </div>
      </div>
      <div class="cols">
        <div class="panelbox">
          <h3>&#128273; PASSWORT-GENERATOR</h3>
          <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Starke, zufaellige Passwoerter &ndash; direkt kopierbar.</p>
          <div class="field" style="margin:0 0 10px"><label>Laenge: <b id="pw-len-lbl">16</b></label><input id="pw-len" type="range" min="6" max="48" value="16" oninput="$('pw-len-lbl').textContent=this.value;genPw()" style="width:100%"></div>
          <div class="row" style="gap:14px;flex-wrap:wrap;font-size:13px;margin-bottom:12px">
            <label style="display:flex;align-items:center;gap:5px"><input id="pw-upper" type="checkbox" checked onchange="genPw()">A-Z</label>
            <label style="display:flex;align-items:center;gap:5px"><input id="pw-lower" type="checkbox" checked onchange="genPw()">a-z</label>
            <label style="display:flex;align-items:center;gap:5px"><input id="pw-num" type="checkbox" checked onchange="genPw()">0-9</label>
            <label style="display:flex;align-items:center;gap:5px"><input id="pw-sym" type="checkbox" checked onchange="genPw()">!@#$</label>
          </div>
          <div class="row" style="gap:10px;align-items:center"><input id="pw-result" readonly class="mono" style="flex:1;min-width:150px;background:var(--panel2);border:1px solid var(--line);border-radius:9px;padding:11px 13px;color:var(--txt);font-size:15px"><button class="btn" onclick="genPw()">Neu</button><button class="btn ghost" onclick="copyPw()">Kopieren</button></div>
          <div id="pw-strength" style="font-size:12px;color:var(--muted);margin-top:8px"></div>
        </div>
        <div class="panelbox">
          <h3>&#128196; DATEI-HASH / PRUEFSUMME</h3>
          <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Berechnet MD5/SHA1/SHA256 &ndash; zum Pruefen von Downloads (mit der Angabe der Quelle vergleichen).</p>
          <div class="field"><label>Vollstaendiger Pfad zur Datei</label><input id="fh-path" type="text" placeholder="z.B. C:\Users\Du\Downloads\setup.exe"></div>
          <button class="btn" id="fh-btn" onclick="calcFileHash()">Pruefsummen berechnen</button>
          <div id="fh-result" style="margin-top:12px"></div>
        </div>
      </div>
      <div class="cols">
        <div class="panelbox">
          <h3>&#128207; EINHEITEN-UMRECHNER</h3>
          <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Rechnet Datengroessen, Laenge, Gewicht und Temperatur um.</p>
          <div class="field"><label>Kategorie</label><select id="uc-cat" onchange="ucBuild()"></select></div>
          <div class="row" style="gap:10px;align-items:flex-end;flex-wrap:wrap">
            <div class="field" style="margin:0;flex:1;min-width:110px"><label>Wert</label><input id="uc-val" type="number" value="1" oninput="ucCalc()"></div>
            <div class="field" style="margin:0;flex:1;min-width:110px"><label>Von</label><select id="uc-from" onchange="ucCalc()"></select></div>
            <div class="field" style="margin:0;flex:1;min-width:110px"><label>Nach</label><select id="uc-to" onchange="ucCalc()"></select></div>
          </div>
          <div id="uc-result" class="mono" style="font-size:20px;font-weight:700;margin-top:14px;color:var(--accent)">&ndash;</div>
        </div>
        <div class="panelbox">
          <h3>&#128221; NOTIZBLOCK</h3>
          <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Schnelle Notizen &ndash; werden lokal auf diesem PC gespeichert (bleiben erhalten).</p>
          <textarea id="notes" oninput="saveNotes()" placeholder="Hier tippen &hellip;" style="width:100%;min-height:130px;background:var(--panel2);border:1px solid var(--line);border-radius:10px;padding:12px 14px;color:var(--txt);font-size:14px;font-family:inherit;resize:vertical"></textarea>
          <div id="notes-saved" style="font-size:11px;color:var(--muted);margin-top:6px"></div>
        </div>
      </div>
      <div class="panelbox">
        <h3>&#128203; SYSTEM-BERICHT</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Fasst alle wichtigen PC-Daten (Modell, CPU, GPU, RAM, Laufwerke, Laufzeit) auf einen Klick zusammen &ndash; ideal, um sie zu speichern oder z.B. im Support-Chat zu teilen.</p>
        <div class="row" style="gap:10px;flex-wrap:wrap">
          <button class="btn" id="sr-btn" onclick="makeReport()">&#128203; Bericht erstellen</button>
          <button class="btn ghost" id="sr-copy" onclick="copyReport()" style="display:none">Kopieren</button>
        </div>
        <div id="sr-path" style="font-size:12px;color:var(--muted);margin-top:8px"></div>
        <pre id="sr-text" class="mono" style="display:none;white-space:pre-wrap;background:var(--panel2);border:1px solid var(--line);border-radius:10px;padding:14px;margin-top:12px;font-size:12px;max-height:340px;overflow:auto"></pre>
      </div>
    </section>

    <!-- ===== PAGE: PASSWORT-MANAGER ===== -->
    <section class="page" id="page-passwords">
      <div class="note">&#9432; Lokaler, <b>AES-256-verschluesselter</b> Passwort-Tresor. Alles wird mit deinem Master-Passwort verschluesselt und <b>nur auf diesem PC</b> gespeichert &ndash; nichts wird gesendet, ich sehe deine Passwoerter nie. <b>Vergisst du das Master-Passwort, sind die Daten unwiederbringlich weg</b> (so ist Verschluesselung gedacht). Kein Ersatz fuer einen geprueften Manager wie KeePass/Bitwarden, aber sicher fuer den Eigengebrauch.</div>
      <div class="panelbox" id="pm-lock">
        <h3 id="pm-lock-title">TRESOR ENTSPERREN</h3>
        <div id="pm-lock-body"></div>
        <div class="out" id="pm-lock-out"></div>
      </div>
      <div class="panelbox" id="pm-vault" style="display:none">
        <div class="row" style="justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:12px">
          <h3 style="margin:0">TRESOR <span id="pm-count" style="color:var(--muted);font-weight:400"></span></h3>
          <div class="row" style="gap:8px"><input id="pm-search" placeholder="Suchen &hellip;" oninput="pmRender()" style="background:var(--panel2);border:1px solid var(--line);border-radius:9px;padding:8px 12px;color:var(--txt);font-size:13px;width:160px"><button class="btn ghost sm" onclick="pmLock()">&#128274; Sperren</button></div>
        </div>
        <div id="pm-list"></div>
      </div>
      <div class="panelbox" id="pm-add" style="display:none">
        <h3>NEUER EINTRAG</h3>
        <div class="cols">
          <div class="field"><label>Titel *</label><input id="pm-title" placeholder="z.B. Gmail"></div>
          <div class="field"><label>Benutzername / E-Mail</label><input id="pm-user"></div>
        </div>
        <div class="field"><label>Passwort</label><div class="row" style="gap:8px"><input id="pm-pw" type="text" style="flex:1"><button class="btn ghost" onclick="$('pm-pw').value=pmGen()">Generieren</button></div></div>
        <div class="cols">
          <div class="field"><label>Website (optional)</label><input id="pm-url"></div>
          <div class="field"><label>Notiz (optional)</label><input id="pm-note"></div>
        </div>
        <button class="btn" onclick="pmAdd()">Eintrag speichern</button>
        <div class="out" id="pm-add-out"></div>
      </div>
    </section>

    <!-- ===== PAGE: NETWORK ===== -->
    <section class="page" id="page-network">
      <div class="cols">
        <div class="panelbox"><h3>NETZWERKADAPTER</h3><div id="net-info"></div></div>
        <div class="panelbox">
          <h3>LATENZ-MONITOR</h3>
          <p class="card sub" style="border:none;padding:0;margin-bottom:10px">Ping &amp; Antwortzeit zu bekannten DNS-Servern.</p>
          <button class="btn" id="btnLat" onclick="measureLatency()">Latenz messen</button>
          <div class="lat" id="latResults"></div>
        </div>
      </div>
      <div class="panelbox">
        <h3>DNS-SERVER WECHSELN</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:10px">Ein schneller DNS-Server laedt Webseiten flotter und schuetzt deine Privatsphaere. Aktuell: <b id="dns-cur">&hellip;</b></p>
        <div class="row" style="gap:10px;flex-wrap:wrap">
          <button class="btn ghost" onclick="setDns('cloudflare',this)">Cloudflare 1.1.1.1</button>
          <button class="btn ghost" onclick="setDns('google',this)">Google 8.8.8.8</button>
          <button class="btn ghost" onclick="setDns('quad9',this)">Quad9 9.9.9.9</button>
          <button class="btn ghost" onclick="setDns('opendns',this)">OpenDNS</button>
          <button class="btn ghost" onclick="setDns('auto',this)">Automatisch (Standard)</button>
        </div>
        <div class="out" id="dns-out"></div>
      </div>
      <div class="panelbox">
        <h3>GESPEICHERTE WLAN-PASSWOERTER</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Zeigt die auf diesem PC gespeicherten WLAN-Netze und ihre Passwoerter &ndash; praktisch, um dein eigenes Passwort wiederzufinden oder einem Gast zu geben. Braucht Adminrechte.</p>
        <button class="btn" id="wifi-btn" onclick="loadWifi()">&#128272; WLAN-Passwoerter anzeigen</button>
        <div id="wifi-list" style="margin-top:12px"></div>
      </div>
      <div class="panelbox">
        <h3>NETZWERK-WERKZEUGE</h3>
        <div class="row" style="gap:10px;flex-wrap:wrap">
          <button class="btn ghost" onclick="runAsync('flushdns', null, this, 'DNS-Cache wird geleert')">DNS-Cache leeren</button>
          <button class="btn ghost" onclick="runAsync('renewip', null, this, 'IP-Adresse wird erneuert')">IP-Adresse erneuern</button>
          <button class="btn ghost" onclick="runAsync('pingtest', null, this, 'Ping laeuft')">Ping-Test (8.8.8.8)</button>
        </div>
        <div class="out" id="net-out"></div>
      </div>
    </section>

    <!-- ===== PAGE: TOOLS ===== -->
    <section class="page" id="page-tools">
      <div class="panelbox">
        <h3>WINDOWS-WERKZEUGE OEFFNEN</h3>
        <div class="tiles" id="toolTiles"></div>
        <div class="out" id="tool-out"></div>
      </div>
    </section>

    <!-- ===== PAGE: PROZESSE ===== -->
    <section class="page" id="page-prozesse">
      <div class="panelbox">
        <div class="row" style="justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:12px">
          <h3 style="margin:0">LAUFENDE PROZESSE <span id="proc-count" style="color:var(--muted);font-weight:400">&mdash;</span></h3>
          <div class="row" style="gap:8px;flex-wrap:wrap">
            <input id="proc-search" placeholder="Suchen &hellip;" oninput="renderProcs()" style="background:var(--panel2);border:1px solid var(--line);border-radius:9px;padding:8px 12px;color:var(--txt);font-size:13px;width:170px">
            <button class="btn ghost sm" id="proc-sort-ram" onclick="procSort('ram')">RAM &#9660;</button>
            <button class="btn ghost sm" id="proc-sort-cpu" onclick="procSort('cpu')">CPU</button>
            <button class="btn ghost sm" id="proc-sort-name" onclick="procSort('name')">Name</button>
          </div>
        </div>
        <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Klick auf &bdquo;Beenden&ldquo; schliesst den Prozess. Vorsicht bei System-Prozessen. Die groessten Verbraucher sind hervorgehoben.</p>
        <table><thead><tr><th>Prozess</th><th>PID</th><th>RAM</th><th>CPU (s)</th><th></th></tr></thead>
          <tbody id="procBody"></tbody></table>
      </div>
    </section>

    <!-- ===== PAGE: OPSEC-CHECK ===== -->
    <section class="page" id="page-opsec">
      <div class="note">&#9432; <b>OPSEC = deine Angriffsflaeche &amp; Privatsphaere.</b> Prueft Fernzugriff, unsichere Dienste und Datenabfluss deines PCs. Alle Aenderungen sind umkehrbar. Das haertet <b>deinen eigenen Rechner</b> ab &ndash; es geht nicht ums Verstecken vor Erkennung.</div>
      <div class="panelbox">
        <div class="row" style="justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px">
          <div style="display:flex;align-items:center;gap:20px">
            <div id="opsec-ring" style="width:104px;height:104px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:conic-gradient(var(--muted) 0deg,var(--line) 0deg);flex:none">
              <div style="width:82px;height:82px;border-radius:50%;background:var(--panel);display:flex;flex-direction:column;align-items:center;justify-content:center">
                <span id="opsec-score" style="font-size:26px;font-weight:800">&ndash;</span><span style="font-size:10px;color:var(--muted)">OPSEC</span>
              </div>
            </div>
            <div><h3 style="margin:0" id="opsec-title">OPSEC-Check</h3><div class="sub" id="opsec-sub">Wie gut ist dein PC gegen Fernzugriff &amp; Tracking abgesichert?</div></div>
          </div>
          <div style="display:flex;gap:8px;flex-wrap:wrap"><button class="btn" id="opsec-btn" onclick="loadOpsec()">Jetzt pruefen</button><button class="btn ghost" id="opsec-harden" onclick="hardenAll()">&#128737;&#65039; Alles sicher h&auml;rten</button></div>
        </div>
      </div>
      <div class="panelbox">
        <h3>PRUEFPUNKTE</h3>
        <div id="opsec-list"><div class="kv"><span>Noch nicht geprueft &ndash; auf &bdquo;Jetzt pruefen&ldquo; klicken.</span></div></div>
        <div class="out" id="opsec-out"></div>
      </div>
    </section>

    <!-- ===== PAGE: VIRENSCAN ===== -->
    <section class="page" id="page-scanner">
      <div class="note">&#9432; <b>PC Boost Waechter</b> &ndash; eigener Heuristik-Scan. Prueft die typischen Verstecke von Schadsoftware: Autostart, laufende Programme aus Temp-/Download-Ordnern, manipulierte hosts-Datei, getarnte Downloads. Ehrlich gesagt: das <b>ergaenzt</b> deinen Echtzeitschutz, ersetzt ihn nicht &ndash; und es meldet nur, was es wirklich findet.</div>
      <div class="panelbox">
        <div class="row" style="justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px">
          <div style="display:flex;align-items:center;gap:20px">
            <div id="scan-ring" style="width:104px;height:104px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:conic-gradient(var(--muted) 0deg,var(--line) 0deg);flex:none">
              <div style="width:82px;height:82px;border-radius:50%;background:var(--panel);display:flex;flex-direction:column;align-items:center;justify-content:center">
                <span id="scan-score" style="font-size:26px;font-weight:800">&ndash;</span><span style="font-size:10px;color:var(--muted)">SICHER</span>
              </div>
            </div>
            <div>
              <h3 style="margin:0" id="scan-title">Virenscan</h3>
              <div class="sub" id="scan-sub">Sucht nach verdaechtigen Programmen und Manipulationen.</div>
            </div>
          </div>
          <button class="btn" id="scan-btn" onclick="runAvScan()">Scan starten</button>
        </div>
      </div>
      <div class="panelbox">
        <h3>ERGEBNIS</h3>
        <div id="scan-list"><div class="kv"><span>Noch nicht gescannt &ndash; auf &bdquo;Scan starten&ldquo; klicken.</span></div></div>
        <div class="out" id="scan-out"></div>
      </div>
      <div class="panelbox" id="quar-box" style="display:none">
        <h3>&#128274; QUARANTAENE</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Isolierte Dateien &ndash; laufen nicht mehr. Du kannst sie wiederherstellen oder endgueltig loeschen.</p>
        <div id="quar-list"></div>
      </div>
      <div class="panelbox">
        <h3>&#128225; ECHTZEIT-WAECHTER &amp; AUTO-SCAN</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Laufen im Hintergrund, solange PC Boost offen ist. Der Waechter prueft jede neue Datei im Download-Ordner sofort; der Auto-Scan scannt regelmaessig automatisch.</p>
        <div class="tw"><div><b>Echtzeit-Waechter (Downloads)</b><br><span style="color:var(--muted);font-size:12px">Warnt sofort bei neuen unsignierten Programmen im Download-Ordner.</span></div><button class="btn sm" id="watch-btn" onclick="toggleWatcher()">&hellip;</button></div>
        <div class="tw"><div><b>Geplanter Auto-Scan</b><br><span style="color:var(--muted);font-size:12px" id="auto-sub">Scannt automatisch im Hintergrund.</span></div><button class="btn sm" id="auto-btn" onclick="toggleAutoscan()">&hellip;</button></div>
        <div style="display:flex;justify-content:space-between;align-items:center;margin-top:10px">
          <b style="font-size:13px">Meldungen</b>
          <button class="btn ghost sm" onclick="clearAlerts()">Meldungen leeren</button>
        </div>
        <div id="watch-alerts" style="margin-top:8px"></div>
      </div>
    </section>

    <!-- ===== PAGE: PC-CHECK ===== -->
    <section class="page" id="page-health">
      <div class="panelbox">
        <div class="row" style="justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px">
          <div style="display:flex;align-items:center;gap:20px">
            <div id="health-ring" style="width:104px;height:104px;border-radius:50%;display:flex;align-items:center;justify-content:center;background:conic-gradient(var(--muted) 0deg,var(--line) 0deg);flex:none">
              <div style="width:82px;height:82px;border-radius:50%;background:var(--panel);display:flex;flex-direction:column;align-items:center;justify-content:center">
                <span id="health-score" style="font-size:26px;font-weight:800">&ndash;</span><span style="font-size:10px;color:var(--muted)">PUNKTE</span>
              </div>
            </div>
            <div>
              <h3 style="margin:0" id="health-title">PC-Gesundheit</h3>
              <div class="sub" id="health-sub">Ein Klick prueft Schutz, Speicher, Ballast und mehr.</div>
            </div>
          </div>
          <button class="btn" id="health-btn" onclick="loadHealth()">Jetzt pruefen</button>
        </div>
      </div>
      <div class="panelbox">
        <h3>PRUEFPUNKTE</h3>
        <div id="health-list"><div class="kv"><span>Noch nicht geprueft &ndash; auf &bdquo;Jetzt pruefen&ldquo; klicken.</span></div></div>
        <div class="out" id="health-out"></div>
      </div>
    </section>

    <!-- ===== PAGE: ANTI-TRACKING ===== -->
    <section class="page" id="page-tracking">
      <div class="note">&#9432; Legitime Privatsph&auml;re-H&auml;rtung: reduziert Tracking, Telemetrie und Werbe-Profiling. <b>Alles umkehrbar</b> (Schalter zur&uuml;ck / Blockierung entfernen). Kein Sperr- oder Forensik-Trickserei &ndash; nur weniger Datensammlung &uuml;ber dich.</div>
      <div class="panelbox">
        <h3>WINDOWS ANTI-TRACKING-SCHALTER</h3>
        <div id="tracking-tweaks"></div>
      </div>
      <div class="panelbox">
        <h3>SICHERHEITS-HAERTUNG</h3>
        <div id="sec-tweaks"></div>
      </div>
      <div class="panelbox">
        <h3>TELEMETRIE-DOMAINS BLOCKIEREN (hosts-Datei)</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Leitet bekannte Microsoft-/Werbe-Telemetrie-Adressen ins Leere. Vollst&auml;ndig umkehrbar &ndash; PC Boost setzt einen klar markierten Block in die hosts-Datei.</p>
        <div id="hosts-box"></div>
        <div class="out" id="hosts-out"></div>
      </div>
      <div class="panelbox">
        <h3>SPUREN-RESET (Privatsph&auml;re)</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Leert Zuletzt-verwendet-Liste, DNS-Cache und Thumbnail-Cache. Reduziert lokale Tracking-Reste. (Ereignisprotokolle werden bewusst NICHT angetastet.)</p>
        <button class="btn ghost" onclick="runAsyncT('privreset',this,'Setze Spuren zurueck')">Spuren zur&uuml;cksetzen</button>
        <div class="out" id="tracking-out"></div>
      </div>
    </section>

    <!-- ===== PAGE: CLEANUP ===== -->
    <section class="page" id="page-cleanup">
      <div class="note">&#9432; Diese Seite &auml;ndert echte Windows-Einstellungen und kann Apps entfernen. Schalter sind umkehrbar; entfernte Apps lassen sich im Store neu installieren. Tipp: vorher unter <b>Backup</b> einen Wiederherstellungspunkt erstellen.</div>
      <div class="panelbox">
        <h3>SPEICHER FREIGEBEN</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:12px">L&ouml;scht tempor&auml;re Dateien und leert den Papierkorb. Sicher &ndash; das macht auch die Windows-Datentr&auml;gerbereinigung.</p>
        <div class="row" style="gap:10px;flex-wrap:wrap">
          <button class="btn" onclick="runAsyncC('deepclean',this,'Raeume gruendlich auf')">&#10024; Alles freigeben (Tiefen-Reinigung)</button>
          <button class="btn ghost" onclick="runAsyncC('cleantemp',this,'Bereinige Temp')">Nur Temp-Dateien</button>
          <button class="btn ghost" onclick="runAsyncC('emptybin',this,'Leere Papierkorb')">Nur Papierkorb</button>
        </div>
        <p class="card sub" style="border:none;padding:0;margin-top:10px">Die Tiefen-Reinigung leert Temp, Prefetch, Update-Reste, Absturzberichte, Thumbnail-Cache und Papierkorb &ndash; und zeigt, wie viel Platz frei wurde.</p>
        <div class="out" id="freeup-out"></div>
      </div>
      <div class="panelbox">
        <h3>AUTOSTART-PROGRAMME</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Was startet automatisch mit Windows. &bdquo;Aus&ldquo; = startet nicht mehr mit (jederzeit wieder &bdquo;An&ldquo;). Wie im Task-Manager.</p>
        <div id="startup-list"></div>
      </div>
      <div class="panelbox">
        <h3>BLOATWARE ENTFERNEN</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Vorinstallierte Apps, die viele nicht brauchen. Nur diese kuratierte, sichere Auswahl wird angezeigt.</p>
        <div id="bloat-list"></div>
        <div class="out" id="cleanup-out"></div>
      </div>
      <div class="panelbox">
        <h3>PC AUSMISTEN &ndash; GRO&SZLIG;E DATEIEN</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Findet die gr&ouml;&szlig;ten Dateien in einem Ordner. &bdquo;In Papierkorb&ldquo; ist wiederherstellbar. Es werden nur Downloads/Desktop/Dokumente/Videos durchsucht.</p>
        <div class="row" style="gap:10px;flex-wrap:wrap">
          <select id="big-dir" style="background:var(--panel2);border:1px solid var(--line);border-radius:9px;padding:9px 11px;color:var(--txt);font-size:14px">
            <option value="downloads">Downloads</option><option value="desktop">Desktop</option><option value="dokumente">Dokumente</option><option value="videos">Videos</option></select>
          <button class="btn" onclick="scanBig()">Scannen</button>
        </div>
        <div id="big-list" style="margin-top:12px"></div>
      </div>
    </section>

    <!-- ===== PAGE: BACKUP ===== -->
    <section class="page" id="page-backup">
      <div class="panelbox">
        <h3>WIEDERHERSTELLUNGSPUNKT</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:14px">
          Ein Wiederherstellungspunkt ist ein Sicherungspunkt von Windows. Wenn ein Tweak etwas kaputt macht,
          kannst du Windows damit auf diesen Zeitpunkt zuruecksetzen &ndash; deine Dateien bleiben erhalten.
          <b>Empfohlen, bevor du System-Tweaks machst.</b>
        </p>
        <button class="btn" id="btnRp" onclick="runAsync('restorepoint', null, this, 'Erstelle Wiederherstellungspunkt (kann ~30s dauern)')">Wiederherstellungspunkt erstellen</button>
        <div class="out" id="backup-out"></div>
      </div>
    </section>

    <!-- ===== PAGE: MAX-LEISTUNG ===== -->
    <section class="page" id="page-maxperf">
      <div class="note">&#9432; Holt das <b>Maximum aus PC &amp; Zubehoer</b> heraus: CPU-Dauertakt, GPU-Power-Limit hoch, USB/Maus/Tastatur voll reaktionsschnell, weniger Netzwerk-Latenz, Spiele-Prioritaet. <b>Alles umkehrbar</b> (Standard-Knopf). Braucht Adminrechte. Fuer volle Wirkung danach neu starten.</div>
      <div class="panelbox">
        <h3>&#9889; MAXIMALE LEISTUNG</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:14px">Ein Klick wendet das ganze Performance-Paket an: Ultimate-Energieplan, CPU 100% &amp; Core-Parking aus, USB-Energiesparen aus, Power-Throttling aus, Game Mode + HAGS, Spiele-Prioritaet, GPU auf max. Power-Limit, Maus/Tastatur auf Maximum.</p>
        <div class="row" style="gap:10px;flex-wrap:wrap">
          <button class="btn" onclick="runAsyncMax('maxperf',this,'Stelle auf Maximum')">&#9889; Alles auf Maximum</button>
          <button class="btn ghost" onclick="runAsyncMax('maxperfreset',this,'Stelle auf Standard')">Standard wiederherstellen</button>
        </div>
        <div class="out" id="max-out"></div>
      </div>
      <div class="panelbox">
        <h3>EINZELN OPTIMIEREN</h3>
        <div class="tiles">
          <div class="tile" onclick="runAsyncMaxT('cpumax',this)"><div class="ti">&#129468;</div><div class="tn">CPU: Dauer-Hoechsttakt</div></div>
          <div class="tile" onclick="runAsyncMaxT2('usbpower','off',this)"><div class="ti">&#128268;</div><div class="tn">USB-Zubehoer voll reaktiv</div></div>
          <div class="tile" onclick="runAsyncMaxT2('nagleoff','off',this)"><div class="ti">&#127760;</div><div class="tn">Netzwerk-Latenz senken</div></div>
          <div class="tile" onclick="runAsyncMaxT2('mouseaccel','off',this)"><div class="ti">&#128433;&#65039;</div><div class="tn">Maus 1:1 (Accel aus)</div></div>
          <div class="tile" onclick="show('overclock')"><div class="ti">&#127918;</div><div class="tn">GPU-Power-Limit regeln</div></div>
        </div>
        <div class="out" id="max-out2"></div>
      </div>
      <div class="panelbox">
        <h3>SPEICHER &amp; DIENSTE</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Energieplan, Ruhezustand und der SysMain-Dienst. Alles umkehrbar.</p>
        <div class="tiles">
          <div class="tile" onclick="runAsyncMaxT('ultplan',this)"><div class="ti">&#9889;</div><div class="tn">Ultimative Leistung (Energieplan)</div></div>
          <div class="tile" onclick="runAsyncMaxT('hibernateoff',this)"><div class="ti">&#128190;</div><div class="tn">Ruhezustand aus (Speicher frei)</div></div>
          <div class="tile" onclick="runAsyncMaxT('hibernateon',this)"><div class="ti">&#128337;</div><div class="tn">Ruhezustand an</div></div>
          <div class="tile" onclick="runAsyncMaxT('sysmainoff',this)"><div class="ti">&#128194;</div><div class="tn">SysMain/Superfetch aus</div></div>
          <div class="tile" onclick="runAsyncMaxT('sysmainon',this)"><div class="ti">&#128194;</div><div class="tn">SysMain an</div></div>
        </div>
      </div>
    </section>

    <!-- ===== PAGE: ENERGIE / POWER ===== -->
    <section class="page" id="page-power">
      <div class="note">&#9432; Energie &amp; Sitzung. Neustart/Herunterfahren mit Timer &ndash; abbrechbar, solange der Timer laeuft.</div>
      <div class="panelbox">
        <h3>SITZUNG</h3>
        <div class="tiles">
          <div class="tile" onclick="powerAct('lock')"><div class="ti">&#128274;</div><div class="tn">Sperren</div></div>
          <div class="tile" onclick="powerAct('sleep')"><div class="ti">&#127769;</div><div class="tn">Energiesparmodus</div></div>
          <div class="tile" onclick="powerAct('hibernate')"><div class="ti">&#128164;</div><div class="tn">Ruhezustand</div></div>
          <div class="tile" onclick="powerAct('logoff')"><div class="ti">&#128682;</div><div class="tn">Abmelden</div></div>
        </div>
      </div>
      <div class="panelbox">
        <h3>NEUSTART &amp; HERUNTERFAHREN</h3>
        <div class="row" style="gap:14px;align-items:flex-end;flex-wrap:wrap;margin-bottom:14px">
          <div class="field" style="margin:0"><label>Timer (Sekunden, 0 = sofort)</label><input id="pw-sec" type="number" value="0" min="0" style="width:150px"></div>
          <button class="btn" onclick="powerAct('restart')">&#128260; Neustart</button>
          <button class="btn danger" onclick="powerAct('shutdown')">&#9211;&#65039; Herunterfahren</button>
          <button class="btn ghost" onclick="powerAct('cancel')">Abbrechen</button>
        </div>
        <div class="out" id="pw-out"></div>
      </div>
    </section>

    <!-- ===== PAGE: EINSTELLUNGEN (Hub Setup) ===== -->
    <section class="page" id="page-settings">
      <div class="note">&#9432; Personalisiere PC Boost selbst &ndash; Farbe, Groesse, Hintergrund-Effekte. Wird lokal gespeichert und beim naechsten Start automatisch angewendet.</div>
      <div class="cols">
        <div class="panelbox">
          <h3>AKZENTFARBE</h3>
          <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Faerbt Buttons, Nav, Ringe &amp; Cursor.</p>
          <div id="theme-swatches" style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:14px"></div>
          <div class="row" style="gap:10px;align-items:center"><label style="font-size:13px">Eigene Farbe:</label><input id="theme-custom" type="color" value="#ff4172" onchange="setAccentCustom(this.value)" style="width:52px;height:34px;border:none;background:none;cursor:pointer"></div>
        </div>
        <div class="panelbox">
          <h3>GROESSE &amp; BEWEGUNG</h3>
          <div class="field" style="margin:0 0 14px"><label>UI-Groesse: <b id="ui-size-lbl">100%</b></label><input id="ui-size" type="range" min="80" max="130" value="100" step="5" oninput="setUiSize(this.value)" style="width:100%"></div>
          <div class="tw"><div><b>Animationen reduzieren</b><br><span style="color:var(--muted);font-size:12px">Weniger Bewegung = ruhiger/schneller.</span></div><button class="btn sm ghost" id="set-motion" onclick="toggleSetting('reduceMotion')">Aus</button></div>
        </div>
      </div>
      <div class="panelbox">
        <h3>HINTERGRUND-EFFEKTE</h3>
        <div class="tw"><div><b>Leucht-Orbs</b><br><span style="color:var(--muted);font-size:12px">Sanft schwebende Farbkugeln im Hintergrund.</span></div><button class="btn sm ghost" id="set-orbs" onclick="toggleSetting('orbs')">Aus</button></div>
        <div class="tw"><div><b>Raster-Hintergrund</b><br><span style="color:var(--muted);font-size:12px">Dezentes Gitter (Tech-Look).</span></div><button class="btn sm ghost" id="set-grid" onclick="toggleSetting('grid')">Aus</button></div>
        <div class="tw"><div><b>Schnee</b><br><span style="color:var(--muted);font-size:12px">Fallende Schneeflocken (nur Deko).</span></div><button class="btn sm ghost" id="set-snow" onclick="toggleSetting('snow')">Aus</button></div>
        <div style="margin-top:14px"><button class="btn ghost" onclick="resetSettings()">Alles zuruecksetzen</button></div>
      </div>
      <div class="panelbox">
        <h3>&#127777;&#65039; TEMPERATUR-ALARM</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Warnt dich mit einem Banner, sobald CPU oder GPU zu heiss werden &ndash; egal auf welcher Seite du gerade bist.</p>
        <div class="tw"><div><b>Alarm aktiv</b><br><span style="color:var(--muted);font-size:12px">Prueft die Live-Temperaturen jede Sekunde.</span></div><button class="btn sm ghost" id="ta-on" onclick="taToggle()">Aus</button></div>
        <div class="row" style="gap:20px;flex-wrap:wrap;margin-top:8px">
          <div class="field" style="margin:0"><label>CPU-Grenze: <b id="ta-cpu-lbl">85</b> &deg;C</label><input id="ta-cpu" type="range" min="60" max="100" value="85" oninput="taSet()" style="width:200px"></div>
          <div class="field" style="margin:0"><label>GPU-Grenze: <b id="ta-gpu-lbl">85</b> &deg;C</label><input id="ta-gpu" type="range" min="60" max="100" value="85" oninput="taSet()" style="width:200px"></div>
        </div>
      </div>
    </section>

    <!-- ===== PAGE: PROGRAMME ===== -->
    <section class="page" id="page-programs">
      <div class="note">&#9432; Zeigt die auf diesem PC installierten Programme. &bdquo;Deinstallieren&ldquo; startet den regulaeren Uninstaller des jeweiligen Programms &ndash; wie in den Windows-Einstellungen, nur schneller auffindbar.</div>
      <div class="panelbox">
        <div class="row" style="justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:12px">
          <h3 style="margin:0">INSTALLIERTE PROGRAMME <span id="prog-count" style="color:var(--muted);font-weight:400">&mdash;</span></h3>
          <div class="row" style="gap:8px;flex-wrap:wrap">
            <input id="prog-search" placeholder="Programm suchen &hellip;" oninput="renderPrograms()" style="background:var(--panel2);border:1px solid var(--line);border-radius:9px;padding:8px 12px;color:var(--txt);font-size:13px;width:200px">
            <button class="btn ghost sm" id="prog-sort" onclick="progToggleSort()">Nach Groesse</button>
          </div>
        </div>
        <div id="prog-list"><div class="kv"><span>Lade Programmliste &hellip;</span></div></div>
        <div class="out" id="prog-out"></div>
      </div>
    </section>

    <!-- ===== PAGE: ABSTURZ-ANALYSE ===== -->
    <section class="page" id="page-events">
      <div class="note">&#9432; Die letzten <b>kritischen Fehler und Abstuerze</b> aus dem Windows-Ereignisprotokoll der vergangenen 7 Tage. Hilft zu verstehen, warum der PC abgestuerzt ist, neu gestartet hat oder haengt. Nur Anzeige &ndash; es wird nichts veraendert.</div>
      <div class="panelbox">
        <div class="row" style="justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:12px">
          <h3 style="margin:0">EREIGNISSE <span id="ev-count" style="color:var(--muted);font-weight:400">&mdash;</span></h3>
          <button class="btn ghost sm" onclick="loadEvents()">Aktualisieren</button>
        </div>
        <div id="ev-list"><div class="kv"><span>Lese Ereignisprotokoll &hellip;</span></div></div>
      </div>
    </section>

    <!-- ===== PAGE: ADMIN ===== -->
    <section class="page" id="page-admin">
      <div class="panelbox">
        <h3>&#128081; ADMIN &ndash; deine PC-Boost-Instanz</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:6px">
          Verwaltung fuer <b>diesen PC</b>: wer sich hier anmelden darf und wann sich jemand angemeldet hat.
          Alles wird nur lokal gespeichert (pcboost-access.json / pcboost-loginlog.json) &ndash; nichts verlaesst deinen Rechner.
        </p>
        <div id="admin-me" class="kv" style="margin-top:8px"></div>
        <div class="grid" id="admin-stats" style="margin-top:14px"></div>
      </div>

      <div class="panelbox">
        <h3>&#128100; KONTEN &amp; RICHTLINIEN</h3>
        <div class="tw"><div><b>Neue Registrierungen erlauben</b><br><span style="color:var(--muted);font-size:12px">Aus = niemand kann neue lokale Konten anlegen (nur bestehende melden sich an).</span></div><button class="btn sm" id="adm-reg-btn" onclick="admToggleReg()">&hellip;</button></div>
        <div style="margin-top:14px"><b style="font-size:13px">Lokale Konten</b><div id="adm-accounts" style="margin-top:8px"></div></div>
        <div class="out" id="adm-acc-out"></div>
      </div>

      <div class="panelbox">
        <h3>&#128274; ZUGANG VERWALTEN</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:12px">
          Discord-User-ID freischalten, sperren oder zum Admin machen. Ist die Freischalt-Liste leer, darf sich jeder mit Discord anmelden.
          <br><span style="color:var(--muted);font-size:12px">Discord-ID herausfinden: in Discord Entwicklermodus an &rarr; Rechtsklick auf Profil &rarr; &bdquo;ID kopieren&ldquo;.</span>
        </p>
        <div class="row" style="gap:10px;flex-wrap:wrap;align-items:flex-end">
          <div class="field" style="margin:0"><label>Discord-User-ID</label><input id="adm-id" type="text" placeholder="z.B. 123456789012345678" style="width:240px"></div>
          <button class="btn" onclick="admAccess('allow')">Freischalten</button>
          <button class="btn danger" onclick="admAccess('block')">Sperren</button>
          <button class="btn ghost" onclick="admAccess('admin')">Zu Admin machen</button>
        </div>
        <div class="out" id="adm-out"></div>
        <div style="margin-top:14px;display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:12px">
          <div class="card"><h4 style="margin:0 0 8px">Freigeschaltet</h4><div id="adm-allowed"></div></div>
          <div class="card"><h4 style="margin:0 0 8px">Admins</h4><div id="adm-admins"></div></div>
          <div class="card"><h4 style="margin:0 0 8px">Gesperrt</h4><div id="adm-blocked"></div></div>
        </div>
      </div>

      <div class="panelbox" style="border-color:rgba(88,101,242,.4)">
        <h3>&#128276; ANMELDUNGEN VON ALLEN PCs (Discord-Webhook)</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:10px">
          Weil PC Boost rein lokal laeuft, sieht dieser PC normalerweise nur seine eigenen Anmeldungen.
          Mit einem <b>Discord-Webhook</b> meldet jede Installation &ndash; egal auf welchem PC &ndash; jede Anmeldung an <b>deinen</b> Discord-Kanal.
          So siehst du zentral, wer das Programm nutzt.
        </p>
        <div class="note" style="margin-bottom:12px">&#9432; Fairness-Hinweis: Sag den Leuten, denen du das Tool gibst, dass Anmeldungen an dich gemeldet werden. Gemeldet werden Benutzername, PC-Name, Windows-Konto und Zeit &ndash; sonst nichts.</div>
        <div id="wh-status" style="margin-bottom:10px"></div>
        <div class="field" style="margin:0 0 10px">
          <label>Webhook-URL <span style="color:var(--muted);font-size:11px">(Discord: Kanal bearbeiten &rarr; Integrationen &rarr; Webhooks &rarr; URL kopieren)</span></label>
          <input id="wh-url" type="text" placeholder="https://discord.com/api/webhooks/..." spellcheck="false" style="width:100%">
        </div>
        <div class="row" style="gap:8px;flex-wrap:wrap">
          <button class="btn" onclick="whSave()">Speichern</button>
          <button class="btn ghost" onclick="whTest()">Testnachricht senden</button>
          <button class="btn danger ghost" onclick="whClear()">Entfernen</button>
        </div>
        <div class="out" id="wh-out"></div>
      </div>

      <div class="panelbox" style="border-color:rgba(53,224,161,.4)">
        <h3>&#127758; ALLE PCs &ndash; ZENTRAL ueber den Bot</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:10px">
          Wenn dein Discord-Bot laeuft, liest er die Webhook-Meldungen mit und sammelt <b>alle</b> Anmeldungen &ndash; egal auf welchem PC.
          Hier siehst du sie direkt im Panel, ohne in Discord schauen zu muessen.
        </p>
        <button class="btn sm ghost" onclick="loadGlobal()" style="margin-bottom:10px">Aktualisieren</button>
        <div id="global-status" style="margin-bottom:10px"></div>
        <div id="global-summary" style="margin-bottom:14px"></div>
        <div id="global-list"></div>
      </div>

      <div class="panelbox">
        <h3>&#128101; WER HAT SICH ANGEMELDET (dieser PC)</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Zusammengefasst je Benutzer: wie oft, zuletzt, seit wann, auf welchen PCs.</p>
        <div id="admin-summary"></div>
      </div>

      <div class="panelbox">
        <h3>&#128200; ANMELDUNGEN &ndash; LETZTE 7 TAGE</h3>
        <div id="admin-pertag"></div>
      </div>

      <div class="panelbox">
        <h3>&#128220; VOLLSTAENDIGER VERLAUF (dieser PC)</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Jede einzelne Anmeldung mit Methode, PC und Windows-Konto.</p>
        <div class="row" style="gap:8px;margin-bottom:12px">
          <button class="btn ghost sm" onclick="admExportLog()">Als Datei speichern</button>
          <button class="btn ghost sm" onclick="admClearLog()">Verlauf leeren</button>
        </div>
        <div id="admin-logins"></div>
      </div>

      <div class="panelbox">
        <h3>&#8505;&#65039; INSTANZ-INFO</h3>
        <div id="admin-appinfo"></div>
      </div>
    </section>

    <!-- ===== PAGE: SELBSTTEST ===== -->
    <section class="page" id="page-selbsttest">
      <div class="note">&#9432; Prueft die Umgebung und klopft jede Schnittstelle einzeln ab. Wenn etwas nicht geht, siehst du hier auf einen Blick <b>was</b> &ndash; und kannst es weitergeben, statt &bdquo;geht nicht&ldquo; zu melden.</div>
      <div class="panelbox">
        <h3>&#129514; PRUEFUNG</h3>
        <button class="btn" onclick="stRun()">Selbsttest starten</button>
        <button class="btn ghost" onclick="stCopy()">Ergebnis als Datei speichern</button>
        <div id="st-summary" style="margin-top:14px"></div>
      </div>
      <div class="panelbox">
        <h3>&#128295; UMGEBUNG</h3>
        <div id="st-env"><div class="kv"><span>Noch nicht geprueft.</span></div></div>
      </div>
      <div class="panelbox">
        <h3>&#128225; SCHNITTSTELLEN</h3>
        <div id="st-api"><div class="kv"><span>Noch nicht geprueft.</span></div></div>
      </div>
    </section>

    <!-- ===== PAGE: AENDERUNGEN ===== -->
    <section class="page" id="page-tweaklog">
      <div class="note">&#9432; Jede Umstellung eines Schalters wird hier mit dem vorherigen Registry-Wert festgehalten. Damit laesst sich alles wieder zuruecknehmen &ndash; auch wenn du nicht mehr weisst, was du geaendert hast.</div>
      <div class="panelbox">
        <h3>&#128260; ZURUECKNEHMEN</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:12px">
          Setzt jeden protokollierten Schalter auf den Wert zurueck, den er <b>vor deiner ersten Aenderung</b> hatte. Danach ist das Protokoll leer.
        </p>
        <button class="btn danger" onclick="tlUndoAll()">Alle Aenderungen zuruecknehmen</button>
        <button class="btn ghost" onclick="tlClear()">Nur Protokoll leeren</button>
        <div class="out" id="tl-out"></div>
      </div>
      <div class="panelbox">
        <h3>&#128220; PROTOKOLL</h3>
        <div class="row" style="gap:10px;align-items:center;margin-bottom:12px">
          <label style="font-size:13px;color:var(--muted)">Vergleichsfenster</label>
          <select id="tl-fenster" style="width:150px">
            <option value="15">15 Minuten</option>
            <option value="30" selected>30 Minuten</option>
            <option value="60">1 Stunde</option>
            <option value="120">2 Stunden</option>
          </select>
        </div>
        <div id="tl-list"></div>
        <div id="tl-effect" style="display:none;margin-top:16px;background:var(--panel2);border:1px solid var(--line);border-radius:12px;padding:16px"></div>
      </div>
    </section>

    <!-- ===== PAGE: PROFIL ===== -->
    <section class="page" id="page-profil">
      <div class="note">&#9432; Ein Profil enthaelt ausschliesslich die Stellungen deiner Schalter und den Energieplan &ndash; keine Konten, keine persoenlichen Daten.</div>
      <div class="panelbox">
        <h3>&#128229; PROFIL SICHERN</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Speichert alle Schalterstellungen als Datei. Die kannst du aufheben oder einem Freund mitgeben.</p>
        <button class="btn" onclick="profExport()">Als Datei speichern</button>
        <button class="btn ghost" onclick="profShow()">Anzeigen</button>
        <div class="out" id="prof-out"></div>
      </div>
      <div class="panelbox">
        <h3>&#128228; PROFIL UEBERNEHMEN</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:12px">
          Profildatei waehlen oder den Inhalt einfuegen. Es werden nur Schalter angefasst, die abweichen &ndash; und alles landet im Aenderungsprotokoll, bleibt also umkehrbar.
        </p>
        <input type="file" id="prof-file" accept=".json,application/json" onchange="profFile(this)" style="margin-bottom:10px;font-size:13px">
        <textarea id="prof-text" placeholder="oder Profil-Inhalt hier einfuegen" spellcheck="false"
          style="width:100%;height:110px;background:var(--panel2);color:var(--txt);border:1px solid var(--line);border-radius:8px;padding:10px;font-family:Consolas,monospace;font-size:12px"></textarea>
        <div style="margin-top:10px"><button class="btn" onclick="profImport()">Profil uebernehmen</button></div>
        <div class="out" id="prof-imp-out"></div>
      </div>
    </section>

    <!-- ===== PAGE: VERLAUF ===== -->
    <section class="page" id="page-verlauf">
      <div class="note">&#9432; PC Boost schreibt jede Minute einen Messwert mit. Der Verlauf beginnt mit dem ersten Start &ndash; direkt danach ist er noch leer und fuellt sich mit der Laufzeit.</div>
      <div class="panelbox">
        <h3>&#128200; AUSLASTUNG &amp; TEMPERATUREN</h3>
        <div class="row" style="gap:8px;flex-wrap:wrap;margin-bottom:14px">
          <button class="btn sm" onclick="vlLoad(6)">6 Stunden</button>
          <button class="btn sm" onclick="vlLoad(24)">24 Stunden</button>
          <button class="btn sm" onclick="vlLoad(72)">3 Tage</button>
          <button class="btn sm" onclick="vlLoad(168)">7 Tage</button>
        </div>
        <div id="vl-chart"></div>
        <div id="vl-info" style="color:var(--muted);font-size:12px;margin-top:10px"></div>
      </div>
      <div class="panelbox">
        <h3>&#128269; AUFFAELLIGKEITEN</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Die Kurven in Saetzen &ndash; laengste Phase ueber der Schwelle, Spitzenwert mit Uhrzeit, Durchschnitt.</p>
        <div id="vl-funde"><div class="kv"><span>Wird mit dem Verlauf geladen.</span></div></div>
      </div>
    </section>

    <!-- ===== PAGE: MAKRO-STUDIO ===== -->
    <section class="page" id="page-makros">
      <div class="panelbox">
        <h3>&#9889; MAKRO-STUDIO - Erweitert</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Erstelle und verwalte benutzerdefinierte Makros mit verschiedenen Tasten und Zeitversaetzen.</p>
        <div class="row" style="gap:10px;flex-wrap:wrap;align-items:flex-end">
          <div class="field" style="margin:0;flex:1;min-width:150px"><label>Makro-Name</label><input id="mk-name" type="text" placeholder="z.B. Mein Makro"></div>
          <div class="field" style="margin:0;flex:1;min-width:120px"><label>Verzoegerung (ms)</label><input id="mk-delay" type="number" value="50" min="10" max="1000" style="width:100px"></div>
          <div class="field" style="margin:0;flex:1;min-width:120px"><label>Wiederholungen</label><input id="mk-repeat" type="number" value="1" min="1" max="100" style="width:100px"></div>
        </div>
        <div class="row" style="gap:10px;flex-wrap:wrap;align-items:flex-end;margin-top:12px">
          <div class="field" style="margin:0;flex:1;min-width:120px"><label>Hotkey</label><select id="mk-hotkey"><option value="">Keine</option><option value="F6">F6</option><option value="F7">F7</option><option value="F8">F8</option><option value="F9">F9</option></select></div>
          <div class="field" style="margin:0;flex:1;min-width:150px"><label>Tasten (kommagetrennt)</label><input id="mk-keys" type="text" placeholder="z.B. A,B,C oder W,A,S,D"></div>
          <button class="btn" onclick="mkCreate()">Makro erstellen</button>
        </div>
        <div class="out" id="mk-out" style="margin-top:12px"></div>
      </div>
      <div class="panelbox" style="margin-top:14px">
        <h3>Gespeicherte Makros</h3>
        <button class="btn ghost sm" onclick="mkRefresh()">Aktualisieren</button>
        <div id="mk-list" style="margin-top:12px"></div>
      </div>
    </section>

    <!-- ===== PAGE: TRAINING-TOOL ===== -->
    <section class="page" id="page-training">
      <div class="panelbox">
        <h3>&#128465; TRAINING-TOOL - Dateien Ausmisten</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Waehle Dateien und Ordner zum Loeschen aus &ndash; einfaches Aufraeum-System fuer schnelles Ausmisten des PCs.</p>
        <div class="row" style="gap:10px;flex-wrap:wrap;align-items:flex-end">
          <div class="field" style="margin:0;flex:1;min-width:200px"><label>Pfad zur Datei oder Ordner</label><input id="train-path" type="text" placeholder="z.B. C:\Users\Downloads\alte_datei.zip"></div>
          <button class="btn" onclick="trainAdd()">Zur Liste hinzufuegen</button>
        </div>
        <div class="out" id="train-out" style="margin-top:8px"></div>
      </div>
      <div class="panelbox" style="margin-top:14px">
        <h3>Zu loeschende Dateien</h3>
        <button class="btn danger" id="train-del-btn" onclick="trainDeleteSelected()" style="display:none">Markierte loeschen</button>
        <button class="btn ghost sm" onclick="trainRefresh()">Aktualisieren</button>
        <div id="train-list" style="margin-top:12px"></div>
      </div>
    </section>

    <!-- ===== PAGE: HARDWARE-ID ===== -->
    <section class="page" id="page-hardwareid">
      <div class="panelbox">
        <h3>&#128512; HARDWARE-ID & SYSTEM-INFOS</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Zeige und aendere deine Hardware-ID, verwalte IP-Adresse und l&ouml;sche Caches.</p>
        <div class="row" style="gap:10px;flex-wrap:wrap;align-items:center">
          <button class="btn" onclick="hwGetID()">Hardware-ID abrufen</button>
          <button class="btn" onclick="hwGetIP()">Oeffentliche IP abrufen</button>
          <button class="btn" onclick="hwClearCache()">Cache & Traces loeschen</button>
        </div>
        <div class="out" id="hw-out" style="margin-top:12px"></div>
      </div>
      <div class="panelbox" style="margin-top:14px">
        <h3>&#9999; Hardware-ID aendern</h3>
        <p class="card sub" style="border:none;padding:0;margin-bottom:12px">Aendere deine eindeutige Hardware-Kennung. <b>Warnung:</b> Dies erfordert Adminrechte und einen Neustart!</p>
        <div class="field"><label>Neue Hardware-ID</label><input id="hw-newid" type="text" placeholder="Neue ID eingeben"></div>
        <button class="btn danger" onclick="hwSetID()">Hardware-ID aendern (Neustart erforderlich)</button>
        <div class="out" id="hw-set-out" style="margin-top:8px"></div>
      </div>
    </section>

  </main>
</div>

<script>
const $ = id => document.getElementById(id);
const hist = {cpu:[], gpu:[]};
let hwLoaded=false, procTimer=null;

function ringColor(v){ return v<50 ? 'var(--green)' : v<80 ? 'var(--yellow)' : 'var(--red)'; }
const esc = s => (''+(s==null?'':s)).replace(/[&<>]/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));
function octile(label,val){ return '<div class="card"><div class="head"><span class="lbl">'+label+'</span></div><div class="mono" style="font-size:22px;font-weight:700">'+(val==null?'--':val)+'</div></div>'; }

/* -------- Navigation -------- */
const PAGES = {
  overview:{t:'Uebersicht', s:'Systemstatus und Hardware auf einen Blick.'},
  monitor:{t:'Live Monitor', s:'Temps, Auslastung, Netzwerk &amp; Vibe-Score.'},
  hardware:{t:'Hardware', s:'CPU, GPU, RAM, Mainboard und Laufwerke.'},
  gaming:{t:'Gaming & Tuning', s:'Gaming-Session, Energieplan und System-Tweaks.'},
  overclock:{t:'Overclocker', s:'Live-Monitor + sicheres GPU-Power-Limit-Tuning.'},
  personalize:{t:'Personalisierung', s:'Windows anpassen: Taskleiste, Explorer, Optik, Maus, Leistung.'},
  fixes:{t:'Fixes', s:'Ein-Klick-Reparaturen fuer haeufige Probleme.'},
  autotools:{t:'Eigene Tools', s:'Auto-Klicker, Tasten-Wiederholer und Makro-Editor.'},
  toolbox:{t:'Toolbox', s:'Fenster-Manager, Screenshot, Farb-Picker, Hash, Passwort-Generator, Notizen.'},
  passwords:{t:'Passwort-Manager', s:'Verschluesselter lokaler Passwort-Tresor (AES-256).'},
  network:{t:'Netzwerk', s:'Adapter, Latenz und Werkzeuge.'},
  tools:{t:'Schnellstart', s:'Windows-Werkzeuge mit einem Klick oeffnen.'},
  prozesse:{t:'Prozesse', s:'Was laeuft gerade und wie viel RAM braucht es.'},
  health:{t:'PC-Check', s:'Gesundheits-Score mit konkreten Problemen und Sofort-Fixes.'},
  scanner:{t:'Virenscan', s:'Eigener Heuristik-Scan: Autostart, Prozesse, hosts, Downloads, Miner.'},
  opsec:{t:'OPSEC-Check', s:'Angriffsflaeche &amp; Privatsphaere haerten (Fernzugriff, Dienste, Tracking).'},
  tracking:{t:'Anti-Tracking', s:'Privatsphaere-Haertung: weniger Tracking & Telemetrie.'},
  cleanup:{t:'Aufraeumen', s:'Autostart, Bloatware und Speicher freigeben.'},
  backup:{t:'Backup', s:'Wiederherstellungspunkt als Sicherheitsnetz.'},
  maxperf:{t:'Max-Leistung', s:'Das Maximum aus PC &amp; Zubehoer holen (umkehrbar).'},
  power:{t:'Energie', s:'Sperren, Energiesparen, Neustart &amp; Herunterfahren (mit Timer).'},
  settings:{t:'Einstellungen', s:'PC Boost personalisieren: Farbe, Groesse, Hintergrund-Effekte.'},
  programs:{t:'Programme', s:'Installierte Programme ansehen und deinstallieren.'},
  events:{t:'Absturz-Analyse', s:'Die letzten kritischen Windows-Fehler &amp; Abstuerze.'},
  admin:{t:'Admin', s:'Zugang und Login-Verlauf dieser Instanz verwalten.'},
  makros:{t:'Makro-Studio', s:'Eigene Makros erstellen, Tasten-Wiederholer, Automation.'},
  training:{t:'Training-Tool', s:'Dateien zum Loeschen auswaehlen - einfaches PC-Ausmisten.'},
  hardwareid:{t:'Hardware-ID', s:'Hardware-ID verwalten, Cache-Bereinigung, IP-Adresse.'},
  tweaklog:{t:'Aenderungen', s:'Was wurde umgestellt - einzeln oder komplett zuruecknehmen.'},
  profil:{t:'Profil', s:'Alle Schalterstellungen sichern und auf einen anderen PC uebertragen.'},
  verlauf:{t:'Verlauf', s:'Auslastung und Temperaturen der letzten Stunden und Tage.'},
  selbsttest:{t:'Selbsttest', s:'Prueft Umgebung und alle Schnittstellen - zeigt sofort, was klemmt.'}
};
/* ===== Kategorie- & Unter-Tab-Navigation (jede Funktion genau 1x) ===== */
const CATS={
  overview:{subs:[]},
  monitor:{subs:[['monitor','Live-Monitor'],['hardware','Hardware'],['prozesse','Prozesse'],['verlauf','Verlauf']]},
  leistung:{subs:[['gaming','Gaming & Tuning'],['maxperf','Max-Leistung'],['overclock','Overclocker'],['power','Energie'],['tweaklog','Aenderungen']]},
  anpassen:{subs:[['personalize','Personalisierung'],['cleanup','Aufraeumen'],['programs','Programme'],['settings','Design & App']]},
  sicherheit:{subs:[['scanner','Virenscan'],['opsec','OPSEC'],['tracking','Anti-Tracking'],['health','PC-Check']]},
  netzwerk:{subs:[['network','Netzwerk'],['fixes','Fixes']]},
  werkzeuge:{subs:[['tools','Schnellstart'],['toolbox','Toolbox'],['makros','Makro-Studio'],['passwords','Passwort-Manager']]},
  system:{subs:[['backup','Backup'],['events','Absturz-Analyse'],['training','Training-Tool'],['hardwareid','Hardware-ID'],['profil','Profil'],['selbsttest','Selbsttest'],['admin','Admin']]}
};
const PAGE2CAT={overview:'overview'};
Object.keys(CATS).forEach(c=>CATS[c].subs.forEach(s=>PAGE2CAT[s[0]]=c));
let curCat='overview'; const lastSub={};
window.isAdminUser=false;
function showCat(cat, target){
  if(!CATS[cat]) return;
  curCat=cat;
  document.querySelectorAll('.nav').forEach(n=>n.classList.toggle('active', n.dataset.cat===cat));
  let subs=CATS[cat].subs.filter(s=> s[0]!=='admin' || window.isAdminUser);
  $('subtabs').innerHTML=subs.map(s=>'<div class="subtab" data-sub="'+s[0]+'" onclick="showSub(\''+s[0]+'\')">'+s[1]+'</div>').join('');
  let sub;
  if(target && subs.some(s=>s[0]===target)) sub=target;
  else if(lastSub[cat] && subs.some(s=>s[0]===lastSub[cat])) sub=lastSub[cat];
  else if(subs.length) sub=subs[0][0];
  else sub=cat;
  showSub(sub);
}
function showSub(p){
  const cat=PAGE2CAT[p]||curCat; curCat=cat; lastSub[cat]=p;
  document.querySelectorAll('.nav').forEach(n=>n.classList.toggle('active', n.dataset.cat===cat));
  document.querySelectorAll('.subtab').forEach(t=>t.classList.toggle('active', t.dataset.sub===p));
  document.querySelectorAll('.page').forEach(s=>s.classList.remove('active'));
  const sec=$('page-'+p); if(sec) sec.classList.add('active');
  if(PAGES[p]){ $('pageTitle').textContent=PAGES[p].t; $('pageSub').innerHTML=PAGES[p].s; }
  if(procTimer){clearInterval(procTimer);procTimer=null;}
  if(watchTimer){clearInterval(watchTimer);watchTimer=null;}
  loadPage(p);
}
function show(p){ const cat=PAGE2CAT[p]; if(cat) showCat(cat,p); else showSub(p); }
function loadPage(p){
  if(p==='overview'){ loadOverview(); }
  if(p==='hardware'){ loadHardware(); }
  if(p==='gaming'){ loadGaming(); ovLoadCfg(); }
  if(p==='personalize'){ loadPersonalize(); }
  if(p==='fixes'){ loadFixes(); }
  if(p==='autotools'){ renderMac(); }
  if(p==='toolbox'){ loadWindows(); genPw(); loadNotes(); ucInit(); }
  if(p==='passwords'){ pmInit(); }
  if(p==='overclock'){ loadGpuTune(); loadGpuOc(); loadRefresh(); }
  if(p==='scanner'){ loadQuarantine(); loadWatcher(); watchTimer=setInterval(loadWatcher,4000); }
  if(p==='tracking'){ loadTracking(); }
  if(p==='network'){ loadNetwork(); }
  if(p==='prozesse'){ loadProcesses(); procTimer=setInterval(loadProcesses,2000); }
  if(p==='cleanup'){ loadCleanup(); }
  if(p==='settings'){ renderSettingsUI(); }
  if(p==='programs'){ loadPrograms(); }
  if(p==='events'){ loadEvents(); }
  if(p==='admin'){ loadAdmin(); }
  if(p==='tweaklog'){ loadTweaklog(); }
  if(p==='verlauf'){ vlLoad(24); }
  if(p==='profil'){ $('prof-out').style.display='none'; $('prof-imp-out').style.display='none'; }
  if(p==='selbsttest'){ stRun(); }
}

/* -------- Live-Stats (Monitor + Kopfzeile) -------- */
function draw(){
  const c=$('chart'),x=c.getContext('2d'),W=c.width,H=c.height;
  x.clearRect(0,0,W,H); x.strokeStyle='rgba(255,255,255,.05)';
  for(let i=0;i<=4;i++){const y=H*i/4;x.beginPath();x.moveTo(0,y);x.lineTo(W,y);x.stroke();}
  const plot=(a,col)=>{if(a.length<2)return;x.strokeStyle=col;x.lineWidth=2;x.beginPath();
    a.forEach((v,i)=>{const px=W*i/Math.max(a.length-1,1),py=H-(v/100*H);i?x.lineTo(px,py):x.moveTo(px,py);});x.stroke();};
  const acc=getComputedStyle(document.documentElement).getPropertyValue('--accent').trim()||'#ff4172';
  plot(hist.gpu,'#35e0a1'); plot(hist.cpu,acc);
}
async function tick(){
  try{
    const d=await (await fetch('/api/stats',{cache:'no-store'})).json();
    $('hClock').textContent=d.time; $('hCpu').textContent=d.cpuLoad+'%';
    $('hGpu').textContent=(d.gpuLoad!=null?d.gpuLoad+'%':'n/a');
    $('cpuPct').textContent=d.cpuLoad+'%'; $('cpuRing').style.setProperty('--p',d.cpuLoad);
    $('cpuRing').style.setProperty('--rc',ringColor(d.cpuLoad));
    $('cpuName').textContent=d.cpuName||'Prozessor';
    $('cpuCores').textContent=(d.cores||'--')+' Kerne / '+(d.threads||'--')+' Threads';
    if(d.cpuTemp!=null){$('cpuTemp').textContent=d.cpuTemp+String.fromCharCode(176);}
    else{$('cpuTemp').textContent='n/a';$('cputempwarn').style.display='block';}
    $('ramPct').textContent=d.ramPct+'%';$('ramRing').style.setProperty('--p',d.ramPct);
    $('ramGB').textContent=d.ramUsedGB+'G';$('ramUsed').textContent=d.ramUsedGB+' GB';
    $('ramTotal').textContent='von '+d.ramTotalGB+' GB';$('ramBar').style.width=d.ramPct+'%';
    if(d.gpuLoad!=null){$('gpuPct').textContent=d.gpuLoad+'%';$('gpuRing').style.setProperty('--p',d.gpuLoad);
      $('gpuRing').style.setProperty('--rc',ringColor(d.gpuLoad));$('bGpu').textContent=d.gpuLoad+'%';}
    else{$('gpuPct').textContent='n/a';$('bGpu').textContent='n/a';}
    $('gpuTemp').textContent=d.gpuTemp!=null?d.gpuTemp+String.fromCharCode(176):'--';
    taCheck(d.cpuTemp,d.gpuTemp);
    $('gpuName').textContent=d.gpuName||'Grafikkarte';
    $('gpuMem').textContent=(d.gpuMemUsed!=null)?d.gpuMemUsed+' / '+d.gpuMemTot+' GB':'';
    $('gpuExtra').innerHTML=[(d.gpuClock!=null?d.gpuClock+' MHz':null),(d.gpuPower!=null?d.gpuPower+' W':null),(d.gpuFan!=null?'Luefter '+d.gpuFan+'%':null)].filter(Boolean).join(' &middot; ');
    (function(){ const sb=(id,v)=>{const b=$(id);if(b)b.style.width=(v||0)+'%';const t=$(id+'-v');if(t)t.textContent=(v!=null?v+'%':'n/a');};
      sb('ovl-cpu',d.cpuLoad); sb('ovl-ram',Math.round(d.ramPct)); if(d.gpuLoad!=null){sb('ovl-gpu',d.gpuLoad);}else{const g=$('ovl-gpu-v');if(g)g.textContent='n/a';} })();
    $('cores').innerHTML=(d.coresArr||[]).map((v,i)=>{const c=v<50?'var(--green)':v<80?'var(--yellow)':'var(--red)';
      return '<div class="core"><div class="cl"><span>Kern '+i+'</span><span class="mono">'+v+'%</span></div><div class="cbar"><i style="width:'+v+'%;background:'+c+'"></i></div></div>';}).join('');
    // Hardware-Seite: Live-Status
    if($('hw-cpu-load')){
      const D=String.fromCharCode(176);
      $('hw-cpu-load').textContent=d.cpuLoad; $('hw-cpu-bar').style.width=d.cpuLoad+'%';
      $('hw-cpu-temp').textContent=d.cpuTemp!=null?d.cpuTemp+D+'C':'n/a';
      $('hw-gpu-load').textContent=d.gpuLoad!=null?d.gpuLoad:'n/a'; $('hw-gpu-bar').style.width=(d.gpuLoad||0)+'%';
      $('hw-gpu-temp').textContent=d.gpuTemp!=null?d.gpuTemp+D+'C':'n/a';
      $('hw-ram-load').textContent=Math.round(d.ramPct); $('hw-ram-bar').style.width=d.ramPct+'%';
      $('hw-ram-gb').textContent=d.ramUsedGB+' / '+d.ramTotalGB+' GB';
    }
    // Overclocker-Monitor (nur Anzeige) live befuellen
    if($('oc-gpu')){
      const D=String.fromCharCode(176);
      $('oc-gpuname').textContent=d.gpuName||'--';
      $('oc-gpu').innerHTML=[
        ['Auslastung', d.gpuLoad!=null?d.gpuLoad+'%':null],['Temperatur', d.gpuTemp!=null?d.gpuTemp+D:null],
        ['Hot Spot', d.gpuHotspot!=null?d.gpuHotspot+D:null],['Core-Takt', d.gpuClock!=null?d.gpuClock+' MHz':null],
        ['Speicher-Takt', d.gpuMemClock!=null?d.gpuMemClock+' MHz':null],['Verbrauch', d.gpuPower!=null?d.gpuPower+' W':null],
        ['Luefter', d.gpuFan!=null?d.gpuFan+'%':null],['VRAM', d.gpuMemUsed!=null?d.gpuMemUsed+' / '+d.gpuMemTot+' GB':null]
      ].map(t=>octile(t[0],t[1])).join('');
      $('oc-cpu').innerHTML=[['Auslastung', d.cpuLoad+'%'],['Temperatur', d.cpuTemp!=null?d.cpuTemp+D:'n/a']].map(t=>octile(t[0],t[1])).join('');
    }
    $('rx').textContent=d.rxRate;$('tx').textContent=d.txRate;
    $('vibe').textContent=d.vibe;$('mood').textContent=d.mood;
    $('bUp').innerHTML='Laufzeit <b class="mono">'+d.uptime+'</b>';
    const col=d.vibe>=85?'#35e0a1':d.vibe>=60?'#ffd24b':d.vibe>=35?'#ff9a4b':'#ff5b6e';
    $('scoreRing').style.background='conic-gradient('+col+' '+d.vibe+'%, rgba(255,255,255,.06) 0)';
    $('pulseText').innerHTML=d.vibe>=85?'Kein Thermal Throttle in Sicht. Respekt.':d.vibe>=60?'Laeuft rund. Alles im gruenen Bereich.':d.vibe>=35?'Etwas Last drauf &ndash; noch okay.':'System schwitzt. Vielleicht Programme schliessen.';
    $('disks').innerHTML=(d.disks||[]).map(dk=>{const c=dk.usedPct<70?'var(--green)':dk.usedPct<90?'var(--yellow)':'var(--red)';
      return '<div style="margin-bottom:14px"><div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:5px"><b>'+dk.drive+'</b><span style="color:var(--muted)">'+dk.freeGB+' / '+dk.totalGB+' GB frei</span></div><div class="bar"><i style="width:'+dk.usedPct+'%;background:'+c+'"></i></div></div>';}).join('');
    hist.cpu.push(d.cpuLoad);hist.gpu.push(d.gpuLoad||0);
    if(hist.cpu.length>90){hist.cpu.shift();hist.gpu.shift();}
    draw();
  }catch(e){}
}

/* -------- Hardware -------- */
async function loadHardware(){
  if(hwLoaded) return;
  try{
    const d=await (await fetch('/api/hardware',{cache:'no-store'})).json();
    $('hw-cpu').innerHTML=kv('Modell',d.cpuName)+kv('Kerne / Threads',d.cpuCores+' / '+d.cpuThreads)+kv('Basistakt',d.cpuClock+' GHz')+kv('Sockel',d.cpuSocket);
    $('hw-gpu').innerHTML=(d.gpus&&d.gpus.length? d.gpus.map(g=>kv('Modell',g.name)+kv('Treiber',g.driver)+(g.vramGB?kv('VRAM',g.vramGB+' GB'):'')+(g.res?kv('Aufloesung',g.res+(g.hz?' @ '+g.hz+' Hz':'')):'')).join('<div style="height:8px"></div>') : '<div class="kv"><span>Keine dedizierte GPU erkannt</span></div>');
    $('hw-ram').innerHTML=kv('Gesamt',d.ramTotal+' GB')+(d.ramMods||[]).map((m,i)=>kv('Modul '+(i+1),m.cap+' GB @ '+m.speed+' MHz'+(m.mfr?' ('+m.mfr+')':''))).join('');
    $('hw-sys').innerHTML=kv('Betriebssystem',d.osName)+kv('Build',d.osBuild)+(d.osInstall?kv('Installiert',d.osInstall):'')+kv('PC',d.pc||'-')+kv('Mainboard',d.board||'-');
    $('hw-disks').innerHTML=(d.drives&&d.drives.length? d.drives.map(dr=>kv(dr.model||'Laufwerk',dr.sizeGB+' GB')).join('') : '<div class="kv"><span>-</span></div>');
    $('hw-vols').innerHTML=(d.volumes&&d.volumes.length? d.volumes.map(v=>{
      const col=v.pct>=90?'var(--red)':v.pct>=75?'var(--yellow)':'var(--accent)';
      return '<div style="margin-bottom:14px"><div class="row" style="justify-content:space-between;margin-bottom:6px"><b>'+esc(v.letter)+(v.label?' '+esc(v.label):'')+'</b>'+
        '<span style="color:var(--muted);font-size:13px">'+v.freeGB+' GB frei von '+v.totalGB+' GB</span></div>'+
        '<div style="height:10px;background:var(--panel2);border-radius:6px;overflow:hidden"><div style="height:100%;width:'+v.pct+'%;background:'+col+'"></div></div>'+
        '<div style="text-align:right;font-size:11px;color:var(--muted);margin-top:3px">'+v.pct+'% belegt</div></div>';
    }).join('') : '<div class="kv"><span>-</span></div>');
    hwLoaded=true;
  }catch(e){ $('hw-cpu').innerHTML='<div class="kv"><span>Konnte Hardware-Infos nicht laden.</span></div>'; }
}
function kv(k,v){ return '<div class="kv"><span>'+esc(k)+'</span><b>'+esc(v)+'</b></div>'; }

/* -------- Netzwerk -------- */
async function loadNetwork(){
  try{
    const d=await (await fetch('/api/network',{cache:'no-store'})).json();
    $('net-info').innerHTML=kv('Adapter',d.adapter||d.desc||'-')+kv('IPv4',d.ipv4||'-')+kv('Gateway',d.gateway||'-')+kv('DNS',d.dns||'-')+kv('MAC',d.mac||'-')+(d.speed?kv('Verbindung',d.speed+' Mbit/s'):'');
  }catch(e){}
  loadDns();
}
async function loadDns(){
  const el=$('dns-cur'); if(!el) return;
  try{
    const d=JSON.parse(await runToEnd('dnsget'));
    const srv=(d.dns||[]).filter(x=>x);
    const map={'1.1.1.1':'Cloudflare','8.8.8.8':'Google','9.9.9.9':'Quad9','208.67.222.222':'OpenDNS'};
    let name=''; for(const ip of srv){ if(map[ip]){ name=map[ip]; break; } }
    el.textContent = srv.length ? (srv.join(', ')+(name?' ('+name+')':'')) : 'automatisch (DHCP)';
  }catch(e){ el.textContent='nicht lesbar'; }
}
async function setDns(preset,btn){
  const names={cloudflare:'Cloudflare',google:'Google',quad9:'Quad9',opendns:'OpenDNS',auto:'Automatisch'};
  const o=$('dns-out'); o.style.display='block'; o.textContent='Setze DNS auf '+names[preset]+' ...';
  const old=btn.textContent; btn.disabled=true;
  o.textContent=await runToEnd('dnsset',JSON.stringify({preset:preset}));
  btn.disabled=false; btn.textContent=old;
  setTimeout(loadDns,500);
}
async function loadWifi(){
  const b=$('wifi-btn'); const old=b.textContent; b.disabled=true; b.innerHTML='<span class="spin"></span>Lese WLAN-Profile &hellip;';
  const list=$('wifi-list'); list.innerHTML='';
  try{
    const d=JSON.parse(await runToEnd('wifikeys'));
    if(!d.nets||!d.nets.length){ list.innerHTML='<div class="kv"><span>Keine WLAN-Profile gefunden (oder Adminrechte noetig).</span></div>'; }
    else{
      list.innerHTML=d.nets.map((n,i)=>{
        const pw=n.key?('<span class="mono" id="wf-'+i+'" style="color:var(--accent)">'+esc(n.key)+'</span> <button class="btn ghost sm" onclick="wifiCopy(\''+i+'\')">Kopieren</button>')
                       :'<span style="color:var(--muted)">offen / kein Passwort</span>';
        return '<div class="tw"><div style="min-width:0"><b>'+esc(n.name)+'</b><br><span style="color:var(--muted);font-size:12px">'+esc(n.auth||'')+'</span></div><div style="text-align:right">'+pw+'</div></div>';
      }).join('');
    }
  }catch(e){ list.innerHTML='<div class="kv"><span>Konnte WLAN-Profile nicht lesen.</span></div>'; }
  b.disabled=false; b.textContent=old;
}
function wifiCopy(i){ const el=$('wf-'+i); if(el){ navigator.clipboard.writeText(el.textContent).catch(()=>{}); } }
async function measureLatency(){
  const b=$('btnLat'); b.disabled=true; b.innerHTML='<span class="spin"></span>Messe &hellip;';
  $('latResults').innerHTML='';
  const out=await runToEnd('latenz',null);
  try{
    const r=JSON.parse(out);
    const keys=Object.keys(r);
    let best=null,bestV=Infinity; keys.forEach(k=>{const v=r[k]; if(v!=null&&v<bestV){bestV=v;best=k;}});
    $('latResults').innerHTML=keys.map(k=>{const v=r[k];const c=v==null?'var(--muted)':v<20?'var(--green)':v<60?'var(--yellow)':'var(--red)';
      const win=(k===best)?' <span style="color:var(--accent);font-size:11px">&#9733; schnellster</span>':'';
      return '<div class="l"><div class="n">'+esc(k)+win+'</div><div class="v mono" style="color:'+c+'">'+(v==null?'-':v+' ms')+'</div></div>';}).join('');
  }catch(e){ $('latResults').innerHTML='<div class="l"><div class="n">Fehler</div></div>'; }
  b.disabled=false; b.textContent='Latenz messen';
}

/* -------- Gaming & Tuning -------- */
function renderTweaks(list, reload){
  return (list||[]).map(t=>{const on=t.state==='an';
    return '<div class="tw"><div><b>'+esc(t.label)+'</b><br><span style="color:var(--muted);font-size:12px">'+esc(t.hint)+(t.reboot?' (Neustart noetig)':'')+'</span></div>'+
      '<button class="btn sm '+(on?'':'ghost')+'" onclick="toggleTweak(\''+t.key+'\',\''+reload+'\')">'+(on?'An':'Aus')+'</button></div>';}).join('');
}
async function loadGaming(){
  try{
    const d=await (await fetch('/api/tweakstatus',{cache:'no-store'})).json();
    $('plans').innerHTML=(d.plans||[]).map(p=>'<button class="btn '+(p.active?'':'ghost')+'" onclick="setPlan(\''+p.guid+'\')">'+esc(p.name)+(p.active?' &#10003;':'')+'</button>').join('');
    $('tweaks').innerHTML=renderTweaks((d.tweaks||[]).filter(t=>t.group==='gaming'),'gaming');
    $('fps-tweaks').innerHTML=renderTweaks((d.tweaks||[]).filter(t=>t.group==='fps'),'gaming');
    $('lat-tweaks').innerHTML=renderTweaks((d.tweaks||[]).filter(t=>t.group==='latency'),'gaming');
    $('win-tweaks').innerHTML=renderTweaks((d.tweaks||[]).filter(t=>t.group==='windows'),'gaming');
    $('perf-tweaks').innerHTML=renderTweaks((d.tweaks||[]).filter(t=>t.group==='perf'),'gaming');
  }catch(e){ $('tweaks').innerHTML='<div class="kv"><span>Konnte Status nicht laden.</span></div>'; }
}
async function setPlan(g){ try{ await fetch('/api/run?a=powerplan&guid='+encodeURIComponent(g),{cache:'no-store'}); }catch(e){} loadGaming(); }
async function toggleTweak(k,reload){ try{ await fetch('/api/run?a=toggle&key='+encodeURIComponent(k),{cache:'no-store'}); }catch(e){} if(reload==='tracking'){loadTracking();}else if(reload==='cleanup'){loadCleanup();}else if(reload==='personalize'){loadPersonalize();}else{loadGaming();} }
async function loadPersonalize(){
  try{
    const d=await (await fetch('/api/tweakstatus',{cache:'no-store'})).json();
    $('pers-tweaks').innerHTML=renderTweaks((d.tweaks||[]).filter(t=>t.group==='personalize'),'personalize');
  }catch(e){ $('pers-tweaks').innerHTML='<div class="kv"><span>Konnte Status nicht laden.</span></div>'; }
}
async function runAsyncP(action,btn,busy){
  const o=$('pers-out'); o.style.display='block'; o.textContent='';
  const old=btn.style.opacity; btn.style.opacity='0.5';
  o.textContent=await runToEnd(action,null);
  btn.style.opacity=old||'1';
}
async function runAsyncP2(action,mode,btn){
  const o=$('pers-out2'); o.style.display='block'; o.textContent='Bitte warten ...';
  o.textContent=await runToEnd(action,mode);
}
async function runAsyncMax(action,btn,busy){
  const o=$('max-out'); o.style.display='block'; o.textContent='';
  const old=btn.textContent; btn.disabled=true; btn.innerHTML='<span class="spin"></span>'+busy+' &hellip;';
  o.textContent=await runToEnd(action,null);
  btn.disabled=false; btn.textContent=old;
}
async function runAsyncMaxT(action,tile){
  const o=$('max-out2'); o.style.display='block'; o.textContent='Bitte warten ...';
  tile.style.opacity='0.5'; o.textContent=await runToEnd(action,null); tile.style.opacity='1';
}
async function runAsyncMaxT2(action,mode,tile){
  const o=$('max-out2'); o.style.display='block'; o.textContent='Bitte warten ...';
  tile.style.opacity='0.5'; o.textContent=await runToEnd(action,mode); tile.style.opacity='1';
}

/* -------- Admin-Panel -------- */
async function loadAdmin(){
  let d={};
  try{ d=await (await fetch('/api/admin/data',{cache:'no-store'})).json(); }catch(e){}
  if(!d.ok){ $('admin-me').innerHTML='<span>Kein Admin-Zugriff auf dieser Instanz.</span>'; return; }
  const me=d.me;
  const meLoc = me && String(me.id).indexOf('local:')===0;
  $('admin-me').innerHTML = me
    ? '<span>Angemeldet als <b>'+esc(me.name)+'</b> ('+(meLoc?'lokales Konto':'Discord')+') &ndash; seit '+esc(me.loginTime||'')+'</span>'
    : '<span>Owner-Modus: du bist automatisch Admin auf diesem PC.</span>';
  const st=d.stats||{};
  const tile=(lbl,val)=>'<div class="card"><div class="head"><span class="lbl">'+lbl+'</span></div><div style="font-size:26px;font-weight:700">'+val+'</div></div>';
  $('admin-stats').innerHTML = tile('ANMELDUNGEN GESAMT', st.totalLogins||0)+tile('VERSCHIEDENE NUTZER', st.uniqueUsers||0)+tile('LOKALE KONTEN', st.accounts||0)+tile('ADMINS', st.adminCount||0);
  const acc=d.access||{allowed:[],admins:[],blocked:[],allowRegister:true};
  const reg = acc.allowRegister!==false;
  const rb=$('adm-reg-btn'); rb.textContent = reg?'An':'Aus'; rb.className='btn sm '+(reg?'':'ghost'); rb.dataset.on = reg?'1':'0';
  const accts=d.accounts||[];
  /* Namen werden ueber den Index referenziert statt in den onclick-String
     eingebaut - so gehen Apostrophe & Co. nicht mehr verloren. */
  window.__admAccounts = accts;
  $('adm-accounts').innerHTML = accts.length
    ? accts.map((a,i)=>'<div class="tw" style="padding:7px 8px;margin-bottom:6px"><span class="mono" style="font-size:13px">'+esc(a)+'</span><button class="btn danger sm" onclick="admDelUser('+i+')">Konto loeschen</button></div>').join('')
    : '<span style="color:var(--muted);font-size:12px">Noch keine lokalen Konten.</span>';
  admIdList('adm-allowed', acc.allowed, 'unallow', 'Freischaltung entfernen');
  admIdList('adm-admins', acc.admins, 'unadmin', 'Admin-Recht entfernen');
  admIdList('adm-blocked', acc.blocked, 'unblock', 'Sperre aufheben');
  loadGlobal();  // zentrale Anmeldungen ueber den Bot mitladen
  const logs=d.logins||[];
  window.__admLogins = logs;
  $('admin-logins').innerHTML = logs.length
    ? '<table class="ptbl"><thead><tr><th>Zeitpunkt</th><th>Name</th><th>Methode</th><th>PC</th><th>Windows-Konto</th></tr></thead><tbody>'+
      logs.map(l=>'<tr><td>'+esc(l.time)+'</td><td>'+esc(l.name)+'</td><td>'+esc(l.method||'—')+'</td>'+
        '<td class="mono">'+esc(l.pc||'—')+'</td><td class="mono">'+esc(l.winuser||'—')+'</td></tr>').join('')+'</tbody></table>'
    : '<div class="kv"><span>Noch keine Anmeldungen auf diesem PC protokolliert.</span></div>';

  /* Webhook-Status */
  const wh=d.webhook||{};
  $('wh-status').innerHTML = wh.gesetzt
    ? '<div style="border-left:3px solid var(--green);padding:8px 12px;background:var(--panel2);border-radius:8px"><b style="color:var(--green)">Aktiv</b> &ndash; Anmeldungen werden gemeldet an <span class="mono" style="font-size:12px">'+esc(wh.vorschau)+'</span></div>'
    : '<div style="border-left:3px solid var(--muted);padding:8px 12px;background:var(--panel2);border-radius:8px">Kein Webhook eingerichtet &ndash; du siehst nur die Anmeldungen dieses PCs.</div>';

  /* Zusammenfassung je Benutzer */
  const sum=d.summary||[];
  $('admin-summary').innerHTML = sum.length
    ? '<table class="ptbl"><thead><tr><th>Benutzer</th><th>Anmeldungen</th><th>zuletzt</th><th>seit</th><th>PCs</th></tr></thead><tbody>'+
      sum.map(s=>'<tr><td><b>'+esc(s.name)+'</b></td><td>'+s.anzahl+'</td><td>'+esc(s.zuletzt)+'</td><td>'+esc(s.zuerst)+'</td>'+
        '<td class="mono" style="font-size:12px">'+esc((s.pcs||[]).join(', ')||'—')+'</td></tr>').join('')+'</tbody></table>'
    : '<div class="kv"><span>Noch keine Anmeldungen.</span></div>';

  /* Balken der letzten 7 Tage */
  const pt=d.proTag||[];
  const maxT=Math.max(1,...pt.map(x=>x.anzahl));
  $('admin-pertag').innerHTML = '<div style="display:flex;align-items:flex-end;gap:8px;height:120px">'+
    pt.map(x=>{ const h=Math.round(x.anzahl/maxT*96);
      return '<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:4px">'+
        '<div style="font-size:12px;font-weight:600">'+x.anzahl+'</div>'+
        '<div style="width:100%;height:'+Math.max(2,h)+'px;background:linear-gradient(180deg,var(--purple),var(--accent));border-radius:4px 4px 0 0"></div>'+
        '<div style="font-size:11px;color:var(--muted)">'+esc(x.tag)+'</div></div>';
    }).join('')+'</div>';

  /* Instanz-Info */
  const ap=d.app||{};
  $('admin-appinfo').innerHTML='<table class="ptbl"><tbody>'+
    '<tr><td>Version</td><td class="mono">'+esc(ap.version||'—')+'</td></tr>'+
    '<tr><td>PC-Name</td><td class="mono">'+esc(ap.pc||'—')+'</td></tr>'+
    '<tr><td>Datenordner</td><td class="mono" style="font-size:12px">'+esc(ap.ordner||'—')+'</td></tr>'+
    '</tbody></table>';
}

/* -------- Zentrale Anmeldungen ueber den Bot -------- */
async function loadGlobal(){
  const stat=$('global-status'), sum=$('global-summary'), lst=$('global-list');
  stat.innerHTML='<span style="color:var(--muted)">Frage Bot ab &hellip;</span>';
  sum.innerHTML=''; lst.innerHTML='';
  let d={};
  try{ d=await (await fetch('/api/admin/globallogins',{cache:'no-store'})).json(); }catch(e){ d={ok:false}; }
  if(!d.ok){ stat.innerHTML='<span>Kein Admin-Zugriff.</span>'; return; }
  if(!d.connected){
    stat.innerHTML='<div style="border-left:3px solid var(--yellow);padding:8px 12px;background:var(--panel2);border-radius:8px">'+
      'Bot nicht erreichbar. Starte deinen Discord-Bot (Dashboard auf <span class="mono">127.0.0.1:5000</span>) &ndash; dann erscheinen hier die Anmeldungen von allen PCs.</div>';
    return;
  }
  const logs=d.logins||[], s=d.summary||[];
  stat.innerHTML='<div style="border-left:3px solid var(--green);padding:8px 12px;background:var(--panel2);border-radius:8px">'+
    '<b style="color:var(--green)">Bot verbunden</b> &ndash; '+logs.length+' Anmeldung'+(logs.length===1?'':'en')+' zentral gesammelt.</div>';
  sum.innerHTML = s.length
    ? '<table class="ptbl"><thead><tr><th>Benutzer</th><th>Anmeldungen</th><th>zuletzt</th><th>PCs</th></tr></thead><tbody>'+
      s.map(x=>'<tr><td><b>'+esc(x.name)+'</b> <span class="mono" style="font-size:11px;color:var(--muted)">'+esc(x.winuser)+'</span></td><td>'+x.anzahl+'</td><td>'+esc(x.zuletzt)+'</td>'+
        '<td class="mono" style="font-size:12px">'+esc((x.pcs||[]).join(', ')||'—')+'</td></tr>').join('')+'</tbody></table>'
    : '<div class="kv"><span>Noch keine zentralen Anmeldungen. Sobald sich jemand (auch du) anmeldet, taucht es hier auf.</span></div>';
  if(logs.length){
    lst.innerHTML='<div style="color:var(--muted);font-size:12px;margin-bottom:6px">Einzelne Anmeldungen (neueste zuerst):</div>'+
      '<table class="ptbl"><thead><tr><th>Zeit</th><th>Benutzer</th><th>Methode</th><th>PC</th><th>Windows-Konto</th></tr></thead><tbody>'+
      logs.slice(0,100).map(l=>'<tr><td>'+esc(l.time)+'</td><td>'+esc(l.name)+'</td><td>'+esc(l.method)+'</td><td class="mono">'+esc(l.pc)+'</td><td class="mono">'+esc(l.winuser)+'</td></tr>').join('')+'</tbody></table>';
  }
}

/* -------- Webhook-Verwaltung -------- */
async function whSave(){
  const url=$('wh-url').value.trim();
  const o=$('wh-out'); o.style.display='block';
  if(!url){ o.textContent='Bitte eine Webhook-URL eingeben (oder auf Entfernen klicken).'; return; }
  o.textContent='Speichere …';
  try{ const d=await (await fetch('/api/admin/webhook?op=set&url='+encodeURIComponent(url),{cache:'no-store'})).json();
    o.textContent=d.msg; if(d.ok){ $('wh-url').value=''; loadAdmin(); }
  }catch(e){ o.textContent='Fehler: '+e.message; }
}
async function whTest(){
  const o=$('wh-out'); o.style.display='block'; o.textContent='Sende Testnachricht …';
  try{ const d=await (await fetch('/api/admin/webhook?op=test',{cache:'no-store'})).json(); o.textContent=d.msg; }
  catch(e){ o.textContent='Fehler: '+e.message; }
}
async function whClear(){
  if(!confirm('Webhook entfernen? Es werden dann keine Anmeldungen mehr an Discord gemeldet.')) return;
  const o=$('wh-out'); o.style.display='block'; o.textContent='Entferne …';
  try{ const d=await (await fetch('/api/admin/webhook?op=set&url=',{cache:'no-store'})).json(); o.textContent=d.msg; loadAdmin(); }
  catch(e){ o.textContent='Fehler: '+e.message; }
}
function admExportLog(){
  const logs=window.__admLogins||[];
  if(!logs.length){ alert('Noch keine Anmeldungen zum Exportieren.'); return; }
  let txt='PC BOOST - Anmeldeverlauf ('+new Date().toLocaleString()+')\n\n';
  txt+='Zeitpunkt\tName\tMethode\tPC\tWindows-Konto\n';
  logs.forEach(l=>{ txt+=[l.time,l.name,l.method||'',l.pc||'',l.winuser||''].join('\t')+'\n'; });
  const a=document.createElement('a');
  a.href=URL.createObjectURL(new Blob([txt],{type:'text/plain'}));
  a.download='pcboost-anmeldungen.txt';
  document.body.appendChild(a); a.click(); document.body.removeChild(a);
  setTimeout(function(){ try{ URL.revokeObjectURL(a.href); }catch(e){} },2000);
}
function admIdList(elId, arr, op, title){
  const el=$(elId); if(!el) return; arr=arr||[];
  el.innerHTML = arr.length
    ? arr.map(id=>'<div class="tw" style="padding:6px 8px;margin-bottom:6px"><span class="mono" style="font-size:12px">'+esc(id)+'</span><button class="btn danger sm" title="'+title+'" onclick="admRemove(\''+op+'\',\''+esc(id)+'\')">Entfernen</button></div>').join('')
    : '<span style="color:var(--muted);font-size:12px">&ndash; leer &ndash;</span>';
}
async function admAccess(op){
  const id=$('adm-id').value.trim(); const o=$('adm-out'); o.style.display='block';
  if(!/^[0-9]{5,25}$/.test(id)){ o.textContent='Bitte eine gueltige Discord-User-ID (nur Zahlen) eingeben.'; return; }
  o.textContent=await runToEndRaw('/api/run?a=access&op='+op+'&id='+encodeURIComponent(id));
  $('adm-id').value=''; loadAdmin();
}
async function admRemove(op,id){
  await runToEndRaw('/api/run?a=access&op='+op+'&id='+encodeURIComponent(id)); loadAdmin();
}
async function admClearLog(){ await runToEnd('clearlog'); loadAdmin(); }
async function admToggleReg(){
  const cur=$('adm-reg-btn').dataset.on==='1'; const nv=cur?'0':'1';
  await runToEndRaw('/api/run?a=access&op=setreg&id='+nv); loadAdmin();
}
async function admDelUser(i){
  const name=(window.__admAccounts||[])[i];
  if(!name){ return; }
  /* Erst fragen, dann das Ausgabefeld zeigen - sonst bleibt bei "Abbrechen"
     ein leerer Kasten stehen. */
  if(!confirm('Konto "'+name+'" wirklich loeschen? Die Person kann sich dann nicht mehr mit diesem Konto anmelden.')) return;
  const o=$('adm-acc-out'); o.style.display='block'; o.textContent='Loesche '+name+' ...';
  o.textContent=await runToEndRaw('/api/run?a=deluser&arg='+encodeURIComponent(name)); loadAdmin();
}

/* ========== App beenden ========== */
async function appBeenden(){
  if(!confirm('PC Boost jetzt beenden?\n\nDer Hintergrunddienst wird gestoppt und das Overlay geschlossen. Zum Weiterarbeiten startest du die App einfach neu.')) return;
  try{
    /* Antwort kommt noch, danach faehrt der Server herunter */
    await fetch('/api/quit',{cache:'no-store'});
  }catch(e){ /* Verbindungsabbruch ist hier normal */ }
  document.body.innerHTML =
    '<div style="display:flex;align-items:center;justify-content:center;height:100vh;text-align:center;font-family:Segoe UI,sans-serif">'+
    '<div><div style="font-size:42px;margin-bottom:14px">&#9209;&#65039;</div>'+
    '<h2 style="margin-bottom:8px">PC Boost wurde beendet</h2>'+
    '<p style="color:#8b8794">Der Hintergrunddienst laeuft nicht mehr. Dieses Fenster kannst du schliessen.</p>'+
    '<p style="color:#8b8794;font-size:13px;margin-top:14px">Zum Neustarten: Doppelklick auf &bdquo;PC Boost starten&ldquo;.</p></div></div>';
}

/* ========== Empfohlene Grundeinstellung ========== */
async function empfohlenAnwenden(btn){
  if(!confirm('Empfohlene Einstellungen anwenden?\n\n11 Schalter werden auf eine vorsichtige Grundeinstellung gesetzt.\nKein Neustart noetig. Alles steht danach im Aenderungsprotokoll und ist umkehrbar.')) return;
  const o=$('empf-out'); o.style.display='block'; o.textContent='Stelle um …';
  const alt=btn.style.opacity; btn.style.opacity='0.5';
  o.textContent=await runToEndRaw('/api/run?a=empfohlen');
  btn.style.opacity=alt||'1';
  if(typeof loadGaming==='function'){ loadGaming(); }
}

/* ========== Selbsttest ========== */
const ST_APIS=[
  ['/api/version','Versionskennung'],
  ['/api/stats','Live-Messwerte'],
  ['/api/hardware','Hardware-Infos'],
  ['/api/network','Netzwerk'],
  ['/api/processes','Prozessliste'],
  ['/api/tweakstatus','Schalter & Energieplan'],
  ['/api/startup','Autostart-Verwaltung'],
  ['/api/bloat','Bloatware-Liste'],
  ['/api/cmdlib','Befehls-Bibliothek'],
  ['/api/peripherals','Peripheriegeraete'],
  ['/api/auth','Anmeldestatus'],
  ['/api/authmode','Anmeldeverfahren'],
  ['/api/hoststatus','hosts-Blockade'],
  ['/api/watcher','Waechter'],
  ['/api/admin/status','Admin-Status'],
  ['/api/admin/data','Admin-Daten'],
  ['/api/tweaklog','Aenderungsprotokoll'],
  ['/api/profile','Profil-Export'],
  ['/api/history?h=6','Langzeit-Verlauf'],
  ['/api/findings?h=24','Auffaelligkeiten'],
  ['/api/selftest','Selbsttest-Daten']
];
/* Bewusst nicht automatisch getestet - mit Begruendung, damit die Liste ehrlich bleibt */
const ST_SKIP=[
  ['/api/quit','wuerde die App beenden'],
  ['/api/run','fuehrt echte Aktionen aus'],
  ['/api/profile/import','veraendert Schalter (POST)'],
  ['/api/discord/login','ruft einen externen Dienst'],
  ['/api/result','braucht eine laufende Aktion'],
  ['/api/effect','braucht einen Protokolleintrag'],
  ['/api/bigfiles','durchsucht Ordner, kann dauern'],
  ['/api/winget','fragt den Paketmanager, kann dauern']
];
let stLetztes='';
async function stRun(){
  $('st-summary').innerHTML='<div class="kv"><span>Pruefe …</span></div>';
  $('st-env').innerHTML='<div class="kv"><span>…</span></div>';
  $('st-api').innerHTML='<div class="kv"><span>…</span></div>';
  let bericht=['PC BOOST SELBSTTEST  '+new Date().toLocaleString(),''];

  /* --- Umgebung --- */
  let envOk=0, envBad=0;
  try{
    const d=await (await fetch('/api/selftest',{cache:'no-store'})).json();
    const rows=(d.pruefungen||[]).map(function(p){
      if(p.ok){envOk++;}else{envBad++;}
      bericht.push((p.ok?'[ok]   ':'[FEHL] ')+p.name+' - '+p.info);
      return '<tr><td style="width:26px">'+(p.ok?'<span style="color:var(--green)">&#10003;</span>':'<span style="color:var(--accent)">&#10007;</span>')+'</td>'+
             '<td><b>'+esc(p.name)+'</b></td><td style="color:var(--muted);font-size:12px">'+esc(p.info)+'</td></tr>';
    }).join('');
    $('st-env').innerHTML='<table class="ptbl"><tbody>'+rows+'</tbody></table>';
  }catch(e){
    $('st-env').innerHTML='<div class="kv"><span>Umgebungspruefung nicht erreichbar.</span></div>';
    envBad++; bericht.push('[FEHL] Umgebungspruefung nicht erreichbar');
  }

  /* --- Schnittstellen --- */
  bericht.push('');
  let apiOk=0, apiBad=0;
  const zeilen=[];
  for(const a of ST_APIS){
    const pfad=a[0], name=a[1];
    const t0=performance.now();
    let ok=false, info='';
    try{
      const r=await fetch(pfad,{cache:'no-store'});
      const txt=await r.text();
      if(r.status!==200){ info='HTTP '+r.status; }
      else if(txt.trim().charAt(0)==='<'){ info='liefert HTML statt JSON - Endpunkt fehlt in dieser Fassung'; }
      else { try{ JSON.parse(txt); ok=true; info=Math.round(performance.now()-t0)+' ms, '+txt.length+' Zeichen'; }
             catch(x){ info='Antwort ist kein gueltiges JSON'; } }
    }catch(e){ info='nicht erreichbar: '+e.message; }
    if(ok){apiOk++;}else{apiBad++;}
    bericht.push((ok?'[ok]   ':'[FEHL] ')+pfad+' - '+info);
    zeilen.push('<tr><td style="width:26px">'+(ok?'<span style="color:var(--green)">&#10003;</span>':'<span style="color:var(--accent)">&#10007;</span>')+'</td>'+
      '<td><b>'+esc(name)+'</b><br><span class="mono" style="font-size:11px;color:var(--muted)">'+esc(pfad)+'</span></td>'+
      '<td style="color:'+(ok?'var(--muted)':'var(--accent)')+';font-size:12px">'+esc(info)+'</td></tr>');
  }
  const uebersprungen=ST_SKIP.map(function(s){
    return '<tr><td style="width:26px;color:var(--muted)">&ndash;</td><td><span class="mono" style="font-size:11px">'+esc(s[0])+'</span></td>'+
           '<td style="color:var(--muted);font-size:12px">nicht automatisch geprueft: '+esc(s[1])+'</td></tr>';
  }).join('');
  $('st-api').innerHTML='<table class="ptbl"><tbody>'+zeilen.join('')+uebersprungen+'</tbody></table>';

  /* --- Zusammenfassung --- */
  const gesamtBad=envBad+apiBad;
  const farbe = gesamtBad===0 ? 'var(--green)' : (gesamtBad<=2 ? 'var(--yellow)' : 'var(--accent)');
  const txt = gesamtBad===0
    ? 'Alles in Ordnung &ndash; '+envOk+' Umgebungspruefungen und '+apiOk+' Schnittstellen fehlerfrei.'
    : gesamtBad+' Problem'+(gesamtBad===1?'':'e')+' gefunden ('+envBad+' Umgebung, '+apiBad+' Schnittstellen). Details unten.';
  $('st-summary').innerHTML='<div style="border-left:3px solid '+farbe+';padding:10px 14px;background:var(--panel2);border-radius:8px">'+
    '<b style="color:'+farbe+'">'+txt+'</b><div style="color:var(--muted);font-size:12px;margin-top:4px">'+
    ST_SKIP.length+' Endpunkte wurden bewusst ausgelassen, siehe unten.</div></div>';
  bericht.splice(1,0,'Ergebnis: '+(gesamtBad===0?'ohne Befund':gesamtBad+' Problem(e)'));
  stLetztes=bericht.join('\n');
}
/* Bewusst KEIN Kopieren in die Zwischenablage.
   Ein verstecktes textarea plus document.execCommand('copy') ist exakt das
   Muster der FakeCaptcha-Schadsoftware - Windows Defender erkennt die ganze
   Datei dann als Trojan:HTML/FakeCaptcha und blockiert den Start. Ein
   Download tut dasselbe, ohne verdaechtig auszusehen. */
function stCopy(){
  if(!stLetztes){ alert('Bitte erst den Selbsttest starten.'); return; }
  try{
    const a=document.createElement('a');
    a.href=URL.createObjectURL(new Blob([stLetztes],{type:'text/plain'}));
    a.download='pcboost-selbsttest.txt';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(function(){ try{ URL.revokeObjectURL(a.href); }catch(e){} },2000);
    alert('Ergebnis gespeichert als pcboost-selbsttest.txt (im Download-Ordner).\n\nDiese Datei kannst du weiterschicken.');
  }catch(e){ alert('Speichern nicht moeglich: '+e.message); }
}

/* ========== Auffaelligkeiten aus dem Verlauf ========== */
async function vlFunde(h){
  const box=$('vl-funde');
  box.innerHTML='<div class="kv"><span>Werte werden ausgewertet …</span></div>';
  try{
    const d=await (await fetch('/api/findings?h='+h,{cache:'no-store'})).json();
    if(!d.ok){ box.innerHTML='<div class="kv"><span>'+esc(d.msg||'Keine Auswertung moeglich.')+'</span></div>'; return; }
    const f=d.funde||[];
    if(!f.length){ box.innerHTML='<div class="kv"><span>Keine auswertbaren Messwerte im gewaehlten Zeitraum.</span></div>'; return; }
    box.innerHTML=f.map(function(x){
      const farbe = x.auffaellig ? 'var(--yellow)' : 'var(--green)';
      const zeichen = x.auffaellig ? '&#9888;' : '&#10003;';
      return '<div style="display:flex;gap:10px;padding:9px 0;border-bottom:1px solid var(--line)">'+
        '<span style="color:'+farbe+'">'+zeichen+'</span>'+
        '<div><div>'+esc(x.text)+'</div>'+
        '<div style="color:var(--muted);font-size:11px;margin-top:2px">Durchschnitt '+x.mittel+x.einheit+
        ', Spitze '+x.spitze+x.einheit+' am '+esc(x.spitzeZeit)+'</div></div></div>';
    }).join('')+'<div style="color:var(--muted);font-size:11px;margin-top:10px">Grundlage: '+d.punkte+' Messpunkte der letzten '+d.stunden+' Stunden.</div>';
  }catch(e){ box.innerHTML='<div class="kv"><span>Auswertung fehlgeschlagen.</span></div>'; }
}

/* ========== Aenderungsprotokoll ========== */
async function loadTweaklog(){
  const box=$('tl-list');
  box.innerHTML='<div class="kv"><span>Lade &hellip;</span></div>';
  try{
    const d=await (await fetch('/api/tweaklog',{cache:'no-store'})).json();
    const e=d.eintraege||[];
    if(!e.length){ box.innerHTML='<div class="kv"><span>Noch nichts geaendert &ndash; das Protokoll ist leer.</span></div>'; return; }
    box.innerHTML='<table class="ptbl"><thead><tr><th>Zeitpunkt</th><th>Schalter</th><th>vorher</th><th>nachher</th><th></th></tr></thead><tbody>'+
      e.map(x=>'<tr><td>'+esc(x.zeit)+'</td><td>'+esc(x.label||x.key)+'</td>'+
        '<td class="mono">'+((x.alt===null||x.alt===undefined)?'<span style="color:var(--muted)">nicht gesetzt</span>':esc(String(x.alt)))+'</td>'+
        '<td class="mono">'+esc(String(x.neu))+'</td>'+
        '<td style="white-space:nowrap"><button class="btn sm" onclick="tlEffect('+x.idx+')">Wirkung</button> '+
        '<button class="btn sm ghost" onclick="tlUndo('+x.idx+')">Zurueck</button></td></tr>').join('')+
      '</tbody></table>';
  }catch(err){ box.innerHTML='<div class="kv"><span>Protokoll konnte nicht geladen werden.</span></div>'; }
}

/* Wirkungsnachweis: Messwerte vor und nach einer Umstellung vergleichen */
async function tlEffect(i){
  const o=$('tl-effect'); o.style.display='block';
  o.innerHTML='<div class="kv"><span>Messwerte werden verglichen &hellip;</span></div>';
  const sel=$('tl-fenster');
  const w=(sel&&parseInt(sel.value))||30;
  try{
    const d=await (await fetch('/api/effect?i='+i+'&w='+w,{cache:'no-store'})).json();
    if(!d.ok){ o.innerHTML='<div class="kv"><span>'+esc(d.msg||'Vergleich nicht moeglich.')+'</span></div>'; return; }
    let h='<div style="font-weight:600;font-size:15px;margin-bottom:3px">'+esc(d.label)+'</div>'+
          '<div style="color:var(--muted);font-size:12px;margin-bottom:12px">Umgestellt am '+esc(d.zeit)+
          ' &ndash; verglichen werden je '+d.fenster+' Minuten davor und danach.</div>';
    let hatWerte=false;
    const zeilen=(d.werte||[]).map(function(m){
      if(!m.genug){
        return '<tr><td>'+esc(m.name)+'</td><td colspan="4" style="color:var(--muted);font-size:12px">zu wenig Messwerte ('+m.nVor+' davor, '+m.nNach+' danach) &ndash; mindestens 5 je Seite noetig</td></tr>';
      }
      hatWerte=true;
      const pfeil = m.diff>0?'&#9650;':(m.diff<0?'&#9660;':'&ndash;');
      let farbe='var(--muted)';
      if(m.urteil==='deutlicher Unterschied'){ farbe = (m.diff<0?'var(--green)':'var(--accent)'); }
      else if(m.urteil==='schwacher Hinweis'){ farbe='var(--yellow)'; }
      return '<tr><td>'+esc(m.name)+'</td>'+
        '<td class="mono">'+m.vor+m.einheit+' <span style="color:var(--muted);font-size:11px">&plusmn;'+m.streuungVor+'</span></td>'+
        '<td class="mono">'+m.nach+m.einheit+' <span style="color:var(--muted);font-size:11px">&plusmn;'+m.streuungNach+'</span></td>'+
        '<td class="mono" style="color:'+farbe+'">'+pfeil+' '+(m.diff>0?'+':'')+m.diff+m.einheit+'</td>'+
        '<td style="color:'+farbe+';font-size:12px">'+esc(m.urteil)+'</td></tr>';
    }).join('');
    h+='<table class="ptbl"><thead><tr><th>Messwert</th><th>davor</th><th>danach</th><th>Differenz</th><th>Bewertung</th></tr></thead><tbody>'+zeilen+'</tbody></table>';
    if(hatWerte){
      h+='<div class="note" style="margin-top:14px">&#9432; Der Vergleich zeigt, <b>was sich zeitgleich veraendert hat</b> &ndash; nicht zwingend, was der Schalter bewirkt hat. '+
         'Hast du zwischendurch ein Spiel gestartet oder beendet, steckt das mit in den Zahlen. '+
         'Die Angabe hinter &plusmn; ist die normale Schwankung; als Unterschied gilt nur, was deutlich darueber liegt. '+
         'Verlaesslich wird es erst, wenn du dieselbe Umstellung mehrfach bei aehnlicher Nutzung siehst.</div>';
    }
    o.innerHTML=h;
  }catch(e){ o.innerHTML='<div class="kv"><span>Vergleich fehlgeschlagen: '+esc(e.message)+'</span></div>'; }
}
async function tlUndo(i){
  const o=$('tl-out'); o.style.display='block'; o.textContent='Setze zurueck &hellip;';
  o.textContent=await runToEndRaw('/api/run?a=tweakundo&i='+i);
  loadTweaklog(); if(typeof loadGaming==='function'){ loadGaming(); }
}
async function tlUndoAll(){
  if(!confirm('Wirklich ALLE protokollierten Aenderungen zuruecknehmen?\n\nJeder Schalter geht auf den Wert zurueck, den er vor deiner ersten Aenderung hatte.')) return;
  const o=$('tl-out'); o.style.display='block'; o.textContent='Setze alles zurueck &hellip;';
  o.textContent=await runToEndRaw('/api/run?a=tweakundoall');
  loadTweaklog(); if(typeof loadGaming==='function'){ loadGaming(); }
}
async function tlClear(){
  if(!confirm('Nur das Protokoll leeren?\n\nDie Schalter bleiben so wie sie jetzt sind - du kannst sie danach aber nicht mehr automatisch zuruecksetzen.')) return;
  const o=$('tl-out'); o.style.display='block';
  o.textContent=await runToEndRaw('/api/run?a=tweaklogclear');
  loadTweaklog();
}

/* ========== Profil sichern / uebernehmen ========== */
async function profExport(){
  const o=$('prof-out'); o.style.display='block'; o.textContent='Erstelle Profil &hellip;';
  try{
    const txt=await (await fetch('/api/profile',{cache:'no-store'})).text();
    const a=document.createElement('a');
    a.href=URL.createObjectURL(new Blob([txt],{type:'application/json'}));
    a.download='pcboost-profil.json';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(()=>{ try{ URL.revokeObjectURL(a.href); }catch(e){} },2000);
    o.textContent='Gespeichert als pcboost-profil.json (im Download-Ordner).';
  }catch(e){ o.textContent='Fehler: '+e.message; }
}
async function profShow(){
  const o=$('prof-out'); o.style.display='block';
  try{ o.textContent=await (await fetch('/api/profile',{cache:'no-store'})).text(); }
  catch(e){ o.textContent='Fehler: '+e.message; }
}
function profFile(inp){
  const f=inp.files&&inp.files[0]; if(!f) return;
  const r=new FileReader();
  r.onload=()=>{ $('prof-text').value=r.result; };
  r.readAsText(f);
}
async function profImport(){
  const txt=$('prof-text').value.trim();
  const o=$('prof-imp-out'); o.style.display='block';
  if(!txt){ o.textContent='Bitte erst eine Profildatei waehlen oder den Inhalt einfuegen.'; return; }
  if(!confirm('Profil jetzt uebernehmen?\n\nAbweichende Schalter werden umgestellt. Alles landet im Aenderungsprotokoll und bleibt umkehrbar.')) return;
  o.textContent='Uebernehme &hellip;';
  try{
    const d=await (await fetch('/api/profile/import',{method:'POST',cache:'no-store',body:txt})).json();
    o.textContent=(d.ok?'Fertig. ':'Fehlgeschlagen. ')+(d.msg||'');
    if(d.ok && typeof loadGaming==='function'){ loadGaming(); }
  }catch(e){ o.textContent='Fehler: '+e.message; }
}

/* ========== Langzeit-Verlauf ========== */
async function vlLoad(h){
  const box=$('vl-chart'); box.innerHTML='<div class="kv"><span>Lade &hellip;</span></div>';
  try{
    const d=await (await fetch('/api/history?h='+h,{cache:'no-store'})).json();
    const p=d.punkte||[];
    if(p.length<2){
      box.innerHTML='<div class="kv"><span>Noch zu wenig aufgezeichnet. Der Verlauf fuellt sich mit jeder Minute Laufzeit &ndash; schau spaeter nochmal rein.</span></div>';
      $('vl-info').textContent=''; return;
    }
    box.innerHTML =
      vlChart('Auslastung in Prozent', p, [[1,'CPU','#ff4172'],[2,'RAM','#35e0a1'],[3,'GPU','#2bb3fb']], 100) +
      vlChart('Temperaturen in Grad',  p, [[4,'CPU','#ffd24b'],[5,'GPU','#a78bfa']], 0);
    const von=new Date(p[0][0]*60000), bis=new Date(p[p.length-1][0]*60000);
    $('vl-info').textContent=p.length+' Messpunkte, von '+von.toLocaleString()+' bis '+bis.toLocaleString();
  }catch(e){ box.innerHTML='<div class="kv"><span>Verlauf konnte nicht geladen werden.</span></div>'; }
  vlFunde(h);
}
function vlChart(titel, p, reihen, fixMax){
  const W=900, H=190, padL=34, n=p.length;
  const xs=i=>padL+(W-padL-10)*(i/(n-1));
  let max=fixMax;
  if(!max){
    max=0; reihen.forEach(r=>p.forEach(q=>{ if(q[r[0]]>max) max=q[r[0]]; }));
    max=Math.max(60, Math.ceil((max+5)/10)*10);
  }
  const ys=v=>H-22-(H-30)*(Math.max(0,Math.min(max,v))/max);
  let g='';
  for(let k=0;k<=4;k++){
    const v=max*k/4, y=ys(v);
    g+='<line x1="'+padL+'" y1="'+y+'" x2="'+(W-10)+'" y2="'+y+'" stroke="rgba(255,255,255,.08)"/>'+
       '<text x="4" y="'+(y+4)+'" fill="#8b8794" font-size="11">'+Math.round(v)+'</text>';
  }
  let leg='', hatDaten=false;
  reihen.forEach(r=>{
    const idx=r[0], name=r[1], farbe=r[2];
    const pts=[];
    for(let i=0;i<n;i++){ if(p[i][idx]>=0){ pts.push(xs(i).toFixed(1)+','+ys(p[i][idx]).toFixed(1)); } }
    if(pts.length>1){ hatDaten=true; g+='<polyline fill="none" stroke="'+farbe+'" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" points="'+pts.join(' ')+'"/>'; }
    const letzt=p[n-1][idx];
    leg+='<span style="display:inline-flex;align-items:center;gap:6px;margin-right:16px;font-size:12px">'+
         '<span style="width:10px;height:10px;border-radius:2px;background:'+farbe+'"></span>'+name+
         (letzt>=0?' <b style="margin-left:2px">'+letzt+'</b>':' <span style="color:var(--muted)">n/a</span>')+'</span>';
  });
  if(!hatDaten){ g+='<text x="'+(W/2)+'" y="'+(H/2)+'" fill="#8b8794" font-size="13" text-anchor="middle">keine Messwerte vorhanden</text>'; }
  return '<div style="margin-bottom:20px">'+
    '<div style="font-size:13px;font-weight:600;margin-bottom:6px">'+titel+'</div>'+
    '<div style="margin-bottom:8px">'+leg+'</div>'+
    '<svg viewBox="0 0 '+W+' '+H+'" preserveAspectRatio="none" style="width:100%;height:190px;background:var(--panel2);border-radius:10px">'+g+'</svg></div>';
}

/* -------- GPU-Power-Limit-Tuning -------- */
async function loadGpuTune(){
  const box=$('oc-tune');
  try{
    const d=JSON.parse(await runToEnd('gpupinfo'));
    if(!d.supported){ box.innerHTML='<div class="kv"><span>'+(d.name?esc(d.name):'Keine NVIDIA-GPU')+' &ndash; Power-Limit-Regelung nicht verfuegbar.</span></div>'; return; }
    box.innerHTML='<div class="row" style="gap:14px;flex-wrap:wrap;align-items:center">'+
      '<input id="oc-pl" type="range" min="'+d.min+'" max="'+d.max+'" value="'+(d.cur||d.default)+'" step="1" style="flex:1;min-width:200px" oninput="$(\'oc-plv\').textContent=this.value+\' W\'">'+
      '<b id="oc-plv" style="min-width:64px;font-size:18px">'+(d.cur||d.default)+' W</b>'+
      '<button class="btn" onclick="gpuSetPl()">Anwenden</button>'+
      '<button class="btn ghost" onclick="gpuResetPl()">Zuruecksetzen ('+d.default+' W)</button>'+
      '</div>'+
      '<div class="kv" style="margin-top:10px"><span>Erlaubter Bereich</span><b>'+d.min+' &ndash; '+d.max+' W &nbsp;|&nbsp; Werk: '+d.default+' W</b></div>';
  }catch(e){ box.innerHTML='<div class="kv"><span>GPU-Status nicht lesbar.</span></div>'; }
}
async function gpuSetPl(){
  const w=$('oc-pl').value; const o=$('oc-tune-out'); o.style.display='block'; o.textContent='Setze Power-Limit ...';
  o.textContent=await runToEnd('gpupl',w); loadGpuTune();
}
async function gpuResetPl(){
  const o=$('oc-tune-out'); o.style.display='block'; o.textContent='Setze zurueck ...';
  o.textContent=await runToEnd('gpuplreset'); loadGpuTune();
}
/* -------- GPU Uebertakten (UNSICHER) -------- */
let gpuOcInfo={};
async function loadGpuOc(){
  const box=$('oc-oc'); if(!box) return;
  let d={};
  try{ d=JSON.parse(await runToEnd('gpuocinfo')); }catch(e){ box.innerHTML='<div class="kv"><span>GPU-Status nicht lesbar.</span></div>'; return; }
  gpuOcInfo=d;
  if(!d.supported){ box.innerHTML='<div class="kv"><span>'+(d.name?esc(d.name):'Keine NVIDIA-GPU')+' &ndash; Uebertakten hier nicht verfuegbar (nur NVIDIA).</span></div>'; return; }
  const gmax=d.maxGr||3000, gdef=Math.min(gmax, Math.round(gmax*0.97));
  const mmax=d.maxMem||10000, mdef=Math.min(mmax, d.curMem||Math.round(mmax*0.9)), mmin=Math.round(mmax*0.4);
  box.innerHTML=
    '<div class="field" style="margin-bottom:12px"><label>GPU-Kerntakt sperren auf: <b id="oc-g-lbl">'+gdef+' MHz</b> <span style="color:var(--muted)">(max '+gmax+')</span></label><input id="oc-g" type="range" min="500" max="'+gmax+'" value="'+gdef+'" step="15" oninput="$(\'oc-g-lbl\').textContent=this.value+\' MHz\'" style="width:100%"></div>'+
    '<div class="field" style="margin-bottom:12px"><label>Speichertakt sperren auf: <b id="oc-m-lbl">'+mdef+' MHz</b> <span style="color:var(--muted)">(max '+mmax+')</span></label><input id="oc-m" type="range" min="'+mmin+'" max="'+mmax+'" value="'+mdef+'" step="15" oninput="$(\'oc-m-lbl\').textContent=this.value+\' MHz\'" style="width:100%"></div>'+
    '<label style="font-size:13px;display:flex;align-items:center;gap:6px;margin:6px 0 12px"><input id="oc-pmax" type="checkbox" checked> Power-Limit auf Maximum ('+d.plMax+' W)</label>'+
    '<div class="row" style="gap:10px;flex-wrap:wrap"><button class="btn danger" onclick="applyGpuOc()">&#9888;&#65039; UNSICHER anwenden</button><button class="btn ghost" onclick="resetGpuOc()">Zuruecksetzen (Werk)</button></div>'+
    '<div class="kv" style="margin-top:12px"><span>Aktuell</span><b>Kern '+d.curGr+' MHz &middot; Speicher '+d.curMem+' MHz &middot; '+d.plCur+' W</b></div>';
}
async function applyGpuOc(){
  if(!confirm('UEBERTAKTEN ist UNSICHER - Abstuerze oder Grafikfehler sind moeglich.\n\nAlles ist umkehrbar (Zuruecksetzen). Fortfahren?')) return;
  const o=$('oc-oc-out'); o.style.display='block'; o.textContent='Wende an ...';
  const cfg={ gclock:parseInt($('oc-g').value)||0, mclock:parseInt($('oc-m').value)||0, powerMax:$('oc-pmax').checked, powerMaxW:(gpuOcInfo.plMax||0) };
  o.textContent=await runToEnd('gpuoc',JSON.stringify(cfg)); loadGpuOc();
}
async function resetGpuOc(){
  const o=$('oc-oc-out'); o.style.display='block'; o.textContent='Setze zurueck ...';
  o.textContent=await runToEnd('gpuocreset'); loadGpuOc();
}
async function ocCpuMax(btn){
  const o=$('oc-cpu2-out'); o.style.display='block'; o.textContent='Bitte warten ...';
  o.textContent=await runToEnd('cpumax');
}
async function loadRefresh(){
  const box=$('oc-refresh'); if(!box) return;
  let d={};
  try{ d=JSON.parse(await runToEnd('refreshinfo')); }catch(e){ box.innerHTML='<div class="kv"><span>Bildschirm nicht lesbar.</span></div>'; return; }
  if(!d.cur){ box.innerHTML='<div class="kv"><span>Aktualisierungsrate nicht lesbar.</span></div>'; return; }
  let rates=[60,75,90,100,120,144,165,180,240,360].filter(hz=>hz<=d.max);
  if(!rates.includes(d.max)) rates.push(d.max); if(!rates.includes(d.cur)) rates.push(d.cur);
  const uniq=[...new Set(rates)].sort((a,b)=>a-b);
  box.innerHTML='<div class="kv"><span>Aktuell</span><b>'+d.cur+' Hz</b></div><div class="kv"><span>Maximal moeglich</span><b style="color:var(--accent)">'+d.max+' Hz</b> <span style="color:var(--muted)">('+d.w+'x'+d.h+')</span></div>'+
    '<div class="row" style="gap:8px;flex-wrap:wrap;margin-top:12px">'+uniq.map(hz=>'<button class="btn '+(hz===d.cur?'':'ghost')+' sm" onclick="setRefreshHz('+hz+')">'+hz+' Hz'+(hz===d.max?' (max)':'')+'</button>').join('')+'</div>'+
    (d.cur<d.max?'<button class="btn" style="margin-top:12px" onclick="setRefreshHz('+d.max+')">&#9889; Auf Maximum ('+d.max+' Hz)</button>':'');
}
async function setRefreshHz(hz){
  const o=$('oc-refresh-out'); o.style.display='block'; o.textContent='Setze '+hz+' Hz ...';
  o.textContent=await runToEnd('setrefresh',String(hz)); setTimeout(loadRefresh,600);
}

/* -------- PC-Check (Gesundheits-Score) -------- */
async function loadHealth(){
  const btn=$('health-btn'), list=$('health-list'), out=$('health-out');
  out.style.display='none'; out.textContent='';
  const old=btn.textContent; btn.disabled=true; btn.innerHTML='<span class="spin"></span>Pruefe &hellip;';
  list.innerHTML='<div class="kv"><span>Scanne dein System &hellip;</span></div>';
  let d={};
  try{ d=JSON.parse(await runToEnd('healthscan')); }catch(e){ list.innerHTML='<div class="kv"><span>Konnte nicht pruefen (Adminrechte noetig).</span></div>'; btn.disabled=false; btn.textContent=old; return; }
  btn.disabled=false; btn.textContent='Erneut pruefen';
  const score=d.score||0;
  const col = score>=80?'var(--green)':(score>=55?'var(--yellow)':'var(--red)');
  $('health-score').textContent=score;
  $('health-ring').style.background='conic-gradient('+col+' '+(score*3.6)+'deg,var(--line) 0deg)';
  const bad=(d.checks||[]).filter(c=>c.status!=='ok').length;
  $('health-title').textContent = score>=80?'Alles im gruenen Bereich':(score>=55?'Ein paar Baustellen':'Handlungsbedarf');
  $('health-sub').textContent = bad? (bad+' Punkt(e) koennen verbessert werden.') : 'Keine Probleme gefunden.';
  const ico={ok:'&#9989;',warn:'&#9888;&#65039;',bad:'&#10060;'};
  const scol={ok:'var(--green)',warn:'var(--yellow)',bad:'var(--red)'};
  list.innerHTML=(d.checks||[]).map(c=>{
    let action='';
    if(c.fix){ action='<button class="btn sm" onclick="healthFix(\''+c.fix+'\',this)">Beheben</button>'; }
    else if(c.page){ action='<button class="btn ghost sm" onclick="show(\''+c.page+'\')">Oeffnen</button>'; }
    return '<div class="tw"><div style="display:flex;align-items:center;gap:10px"><span style="font-size:18px">'+ico[c.status]+'</span><div><b style="color:'+scol[c.status]+'">'+esc(c.label)+'</b><br><span style="color:var(--muted);font-size:12px">'+esc(c.detail)+'</span></div></div>'+action+'</div>';
  }).join('');
}
async function healthFix(action,btn){
  const out=$('health-out'); out.style.display='block';
  const old=btn.textContent; btn.disabled=true; btn.innerHTML='<span class="spin"></span>';
  out.textContent=await runToEnd(action);
  btn.disabled=false; btn.textContent=old; loadHealth();
}

/* -------- Virenscan (eigener Waechter) -------- */
let avFindings=[];
async function runAvScan(){
  const btn=$('scan-btn'), list=$('scan-list'), out=$('scan-out');
  out.style.display='none'; out.textContent='';
  const old=btn.textContent; btn.disabled=true; btn.innerHTML='<span class="spin"></span>Scanne &hellip;';
  list.innerHTML='<div class="kv"><span>Durchsuche Autostart, Prozesse, hosts-Datei und Downloads &hellip;</span></div>';
  let d={};
  try{ d=JSON.parse(await runToEnd('avscan')); }catch(e){ list.innerHTML='<div class="kv"><span>Scan fehlgeschlagen.</span></div>'; btn.disabled=false; btn.textContent=old; return; }
  btn.disabled=false; btn.textContent='Erneut scannen';
  const score=d.score||0;
  const col = score>=90?'var(--green)':(score>=60?'var(--yellow)':'var(--red)');
  $('scan-score').textContent=score;
  $('scan-ring').style.background='conic-gradient('+col+' '+(score*3.6)+'deg,var(--line) 0deg)';
  avFindings = d.findings||[];
  $('scan-title').textContent = (d.danger>0)?'Verdaechtiges gefunden!':(d.warn>0?'Ein paar Hinweise':'Nichts Verdaechtiges gefunden');
  $('scan-sub').textContent = 'Geprueft: '+((d.scanned&&d.scanned.autoruns)||0)+' Autostarts, '+((d.scanned&&d.scanned.processes)||0)+' Prozesse. '+(avFindings.length?(d.danger+' kritisch, '+d.warn+' Hinweis(e).'):'Alles sauber.');
  if(!avFindings.length){ list.innerHTML='<div class="tw"><div style="display:flex;align-items:center;gap:10px"><span style="font-size:18px">&#9989;</span><b style="color:var(--green)">Keine verdaechtigen Autostarts, Prozesse oder Manipulationen gefunden.</b></div></div>'; return; }
  const ico={danger:'&#10060;',warn:'&#9888;&#65039;'};
  const scol={danger:'var(--red)',warn:'var(--yellow)'};
  list.innerHTML=avFindings.map((f,i)=>{
    const isFile=f.path&&/\.[a-z0-9]{2,4}$/i.test(f.path);
    const hashLine=f.hash?'<br><span class="mono" style="font-size:10px;color:var(--muted);word-break:break-all">SHA256: '+esc(f.hash)+'</span>':'';
    const entLine=(f.entropy!=null)?'<br><span style="font-size:11px;color:'+(f.packed?'var(--red)':'var(--muted)')+'">Entropie: '+f.entropy+'/8'+(f.packed?' &ndash; wahrscheinlich gepackt/verschleiert':'')+'</span>':'';
    const vtLine='<span id="vt-'+i+'" style="font-size:12px"></span>';
    return '<div class="tw"><div style="display:flex;align-items:center;gap:10px;min-width:0"><span style="font-size:18px">'+ico[f.sev]+'</span><div style="min-width:0"><b style="color:'+scol[f.sev]+'">['+esc(f.cat)+'] '+esc(f.title)+'</b><br><span style="color:var(--muted);font-size:12px">'+esc(f.detail)+'</span><br><span class="mono" style="font-size:11px;color:var(--muted);word-break:break-all">'+esc(f.path||'')+'</span>'+hashLine+entLine+'<br>'+vtLine+'</div></div><div style="display:flex;gap:6px;flex-wrap:wrap;flex:none">'+(f.hash?'<button class="btn sm" onclick="vtCheck('+i+')">VirusTotal</button>':'')+(f.path?'<button class="btn ghost sm" onclick="avReveal('+i+')">Ordner</button>':'')+(isFile?'<button class="btn danger sm" onclick="avQuar('+i+')">Quarant&auml;ne</button>':'')+(f.path?'<button class="btn ghost sm" onclick="avTrust('+i+')">Vertrauen</button>':'')+'</div></div>';
  }).join('');
}
async function vtCheck(i){
  const f=avFindings[i]; if(!f||!f.hash) return;
  const el=$('vt-'+i); if(el){ el.innerHTML='<span class="spin"></span> VirusTotal &hellip;'; }
  let d={};
  try{ d=JSON.parse(await runToEnd('vtcheck',f.hash)); }catch(e){ if(el)el.textContent='Fehler.'; return; }
  if(!el) return;
  if(!d.ok){ el.innerHTML='<span style="color:var(--yellow)">'+esc(d.msg||'Fehler')+'</span>'; return; }
  if(d.notfound){ el.innerHTML='<span style="color:var(--muted)">'+esc(d.msg)+'</span>'; return; }
  const bad=(d.malicious||0)+(d.suspicious||0);
  const col = d.malicious>0?'var(--red)':(bad>0?'var(--yellow)':'var(--green)');
  el.innerHTML='<b style="color:'+col+'">VirusTotal: '+d.malicious+' von '+d.total+' Engines melden Malware</b>'+(d.suspicious?(' (+'+d.suspicious+' verdaechtig)'):'')+' &ndash; <a href="'+d.link+'" target="_blank" style="color:var(--accent)">Details</a>';
}

/* -------- Echtzeit-Waechter & Auto-Scan -------- */
let watchTimer=null;
async function loadWatcher(){
  let d={};
  try{ d=await (await fetch('/api/watcher',{cache:'no-store'})).json(); }catch(e){ return; }
  const wb=$('watch-btn'); if(wb){ wb.textContent=d.on?'An':'Aus'; wb.className='btn sm '+(d.on?'':'ghost'); }
  const ab=$('auto-btn'); if(ab){ ab.textContent=d.autoOn?'An':'Aus'; ab.className='btn sm '+(d.autoOn?'':'ghost'); }
  const asub=$('auto-sub'); if(asub){ asub.textContent = d.lastAuto ? ('Letzter Auto-Scan: '+d.lastAuto.time+' - Score '+d.lastAuto.score+', '+d.lastAuto.danger+' kritisch') : ('Scannt automatisch im Hintergrund (alle '+(d.interval||6)+'h).'); }
  const al=d.alerts||[];
  const scol={danger:'var(--red)',warn:'var(--yellow)',ok:'var(--green)'};
  const ico={danger:'&#10060;',warn:'&#9888;&#65039;',ok:'&#9989;'};
  const el=$('watch-alerts'); if(!el) return;
  el.innerHTML = al.length ? al.map(a=>'<div class="tw" style="padding:8px 0"><div style="min-width:0"><b style="color:'+(scol[a.sev]||'var(--muted)')+'">'+(ico[a.sev]||'')+' '+esc(a.name)+'</b><br><span style="color:var(--muted);font-size:12px">'+esc(a.time)+' &ndash; '+esc(a.msg||'')+'</span>'+(a.path?'<br><span class="mono" style="font-size:10px;color:var(--muted);word-break:break-all">'+esc(a.path)+'</span>':'')+'</div></div>').join('') : '<div class="kv"><span>Noch keine Meldungen.</span></div>';
}
async function toggleWatcher(){ const on=$('watch-btn').textContent==='An'?0:1; await runToEndRaw('/api/run?a=watcher&on='+on); loadWatcher(); }
async function toggleAutoscan(){ const on=$('auto-btn').textContent==='An'?0:1; await runToEndRaw('/api/run?a=autoscan&on='+on); loadWatcher(); }
async function clearAlerts(){ await runToEnd('clearalerts'); loadWatcher(); }
async function avTrust(i){ const f=avFindings[i]; if(!f||!f.path) return; const o=$('scan-out'); o.style.display='block'; o.textContent=await runToEnd('avtrust',f.path); setTimeout(runAvScan,500); }
async function avQuar(i){
  const f=avFindings[i]; if(!f||!f.path) return;
  if(!confirm('Diese Datei in Quarantaene verschieben (isolieren, laeuft dann nicht mehr)?\n\n'+f.path)) return;
  const o=$('scan-out'); o.style.display='block'; o.textContent=await runToEnd('quarantine',f.path);
  loadQuarantine(); setTimeout(runAvScan,600);
}
let quarItems=[];
async function loadQuarantine(){
  const el=$('quar-list'); if(!el) return;
  let d={};
  try{ d=JSON.parse(await runToEnd('quarlist')); }catch(e){ return; }
  quarItems=d.items||[];
  $('quar-box').style.display = quarItems.length? 'block':'none';
  el.innerHTML = quarItems.map((q,i)=>'<div class="tw"><div style="min-width:0"><b style="word-break:break-all">'+esc(q.orig.split(/[\\\/]/).pop())+'</b><br><span style="color:var(--muted);font-size:11px">'+esc(q.time)+' &ndash; '+esc(q.orig)+'</span></div><div style="display:flex;gap:6px;flex:none"><button class="btn ghost sm" onclick="quarRestore('+i+')">Wiederherstellen</button><button class="btn danger sm" onclick="quarDelete('+i+')">Endgueltig loeschen</button></div></div>').join('');
}
async function quarRestore(i){ const q=quarItems[i]; if(!q)return; const o=$('scan-out'); o.style.display='block'; o.textContent=await runToEnd('quarrestore',q.quar); loadQuarantine(); }
async function quarDelete(i){ const q=quarItems[i]; if(!q)return; if(!confirm('Endgueltig aus der Quarantaene loeschen?'))return; const o=$('scan-out'); o.style.display='block'; o.textContent=await runToEnd('quardelete',q.quar); loadQuarantine(); }
async function avReveal(i){
  const f=avFindings[i]; if(!f||!f.path) return;
  const out=$('scan-out'); out.style.display='block';
  out.textContent=await runToEndRaw('/api/run?a=reveal&path='+encodeURIComponent(f.path));
}

/* -------- OPSEC-Check (Absicherung) -------- */
async function loadOpsec(){
  const btn=$('opsec-btn'), list=$('opsec-list'), out=$('opsec-out');
  out.style.display='none'; out.textContent='';
  const old=btn.textContent; btn.disabled=true; btn.innerHTML='<span class="spin"></span>Pruefe &hellip;';
  list.innerHTML='<div class="kv"><span>Pruefe Fernzugriff, Dienste und Privatsphaere &hellip;</span></div>';
  let d={};
  try{ d=JSON.parse(await runToEnd('opsecscan')); }catch(e){ list.innerHTML='<div class="kv"><span>Konnte nicht pruefen.</span></div>'; btn.disabled=false; btn.textContent=old; return; }
  btn.disabled=false; btn.textContent='Erneut pruefen';
  const score=d.score||0;
  const col = score>=85?'var(--green)':(score>=60?'var(--yellow)':'var(--red)');
  $('opsec-score').textContent=score;
  $('opsec-ring').style.background='conic-gradient('+col+' '+(score*3.6)+'deg,var(--line) 0deg)';
  const bad=(d.checks||[]).filter(c=>c.status!=='ok').length;
  $('opsec-title').textContent = score>=85?'Gut abgesichert':(score>=60?'Ein paar Luecken':'Angriffsflaeche zu gross');
  $('opsec-sub').textContent = bad? (bad+' Punkt(e) verbessern deine OPSEC.') : 'Alles gut abgesichert.';
  const ico={ok:'&#9989;',warn:'&#9888;&#65039;',bad:'&#10060;'};
  const scol={ok:'var(--green)',warn:'var(--yellow)',bad:'var(--red)'};
  list.innerHTML=(d.checks||[]).map(c=>{
    let action='';
    if(c.fix){ action='<button class="btn sm" onclick="opsecFix(\''+c.fix+'\',this)">Beheben</button>'; }
    else if(c.page){ action='<button class="btn ghost sm" onclick="show(\''+c.page+'\')">Oeffnen</button>'; }
    return '<div class="tw"><div style="display:flex;align-items:center;gap:10px"><span style="font-size:18px">'+ico[c.status]+'</span><div><b style="color:'+scol[c.status]+'">'+esc(c.label)+'</b><br><span style="color:var(--muted);font-size:12px">'+esc(c.detail)+'</span></div></div>'+action+'</div>';
  }).join('');
}
async function opsecFix(action,btn){
  const out=$('opsec-out'); out.style.display='block';
  const old=btn.textContent; btn.disabled=true; btn.innerHTML='<span class="spin"></span>';
  out.textContent=await runToEnd(action);
  btn.disabled=false; btn.textContent=old; loadOpsec();
}
async function hardenAll(){
  if(!confirm('Empfohlene sichere Haertung anwenden?\n\nFirewall an, SMBv1/LLMNR/NetBIOS/AutoRun aus, SmartScreen & UAC an.\nAlles umkehrbar. (Fernzugriff/RDP wird NICHT angetastet.)')) return;
  const btn=$('opsec-harden'), out=$('opsec-out'); out.style.display='block';
  const old=btn.textContent; btn.disabled=true; btn.innerHTML='<span class="spin"></span>Haerte ...';
  out.textContent=await runToEnd('hardenall');
  btn.disabled=false; btn.textContent=old; loadOpsec();
}

/* -------- Anti-Tracking -------- */
async function loadTracking(){
  try{
    const d=await (await fetch('/api/tweakstatus',{cache:'no-store'})).json();
    $('tracking-tweaks').innerHTML=renderTweaks((d.tweaks||[]).filter(t=>t.group==='privacy'),'tracking');
    $('sec-tweaks').innerHTML=renderTweaks((d.tweaks||[]).filter(t=>t.group==='security'),'tracking');
  }catch(e){}
  try{
    const h=await (await fetch('/api/hoststatus',{cache:'no-store'})).json();
    const on=h.blocked;
    $('hosts-box').innerHTML='<div class="tw"><div><b>Telemetrie-Blockierung</b><br><span style="color:var(--muted);font-size:12px">'+(on?'Aktiv &ndash; '+h.count+' Domains blockiert.':'Inaktiv.')+'</span></div>'+
      '<button class="btn sm '+(on?'ghost':'')+'" onclick="toggleHosts('+(on?0:1)+')">'+(on?'Aus':'An')+'</button></div>';
  }catch(e){}
}
async function toggleHosts(on){
  const o=$('hosts-out'); o.style.display='block'; o.textContent='Bitte warten ...';
  try{ const r=await (await fetch('/api/run?a=blockhosts&on='+on,{cache:'no-store'})).json(); o.textContent=r.output||''; }catch(e){ o.textContent='Fehler.'; }
  loadTracking();
}
async function runAsyncT(action,btn,busy){
  const o=$('tracking-out'); o.style.display='block'; o.textContent='';
  const old=btn.textContent; btn.disabled=true; btn.innerHTML='<span class="spin"></span>'+busy+' ...';
  o.textContent=await runToEnd(action,null);
  btn.disabled=false; btn.textContent=old;
}
async function runAsyncG(action,btn,busy){
  const o=$('gaming-out'); o.style.display='block'; o.textContent='';
  const old=btn.innerHTML; btn.disabled=true; btn.innerHTML='<span class="spin"></span>'+busy+' ...';
  o.textContent=await runToEnd(action,null);
  btn.disabled=false; btn.innerHTML=old; loadGaming();
}

/* -------- Aufraeumen (Privatsphaere / Autostart / Bloat) -------- */
async function loadCleanup(){
  try{
    const s=await (await fetch('/api/startup',{cache:'no-store'})).json();
    $('startup-list').innerHTML=(s.items||[]).map(it=>{const on=it.enabled;
      return '<div class="tw"><div style="min-width:0"><b>'+esc(it.name)+'</b><br><span style="color:var(--muted);font-size:12px;word-break:break-all">'+esc((it.cmd||'').slice(0,70))+'</span></div>'+
        '<button class="btn sm '+(on?'':'ghost')+'" onclick="toggleStartup(\''+it.scope+'\',\''+esc(it.name).replace(/\x27/g,"")+'\','+(on?0:1)+')">'+(on?'An':'Aus')+'</button></div>';}).join('') || '<div class="kv"><span>Keine Autostart-Eintraege gefunden.</span></div>';
  }catch(e){}
  try{
    const b=await (await fetch('/api/bloat',{cache:'no-store'})).json();
    $('bloat-list').innerHTML=(b.apps||[]).map(a=>
      '<div class="tw"><div><b>'+esc(a.label)+'</b>'+(a.risky?' <span style="color:var(--yellow);font-size:11px">(Vorsicht)</span>':'')+'<br><span style="color:var(--muted);font-size:12px">'+esc(a.pkg)+'</span></div>'+
      '<button class="btn danger sm" onclick="removeApp(\''+esc(a.pkg)+'\',\''+esc(a.label).replace(/\x27/g,"")+'\')">Entfernen</button></div>').join('') || '<div class="kv"><span>Keine der kuratierten Apps installiert. Sauber!</span></div>';
  }catch(e){}
}
async function toggleStartup(scope,name,on){
  try{ await fetch('/api/run?a=startuptoggle&scope='+scope+'&name='+encodeURIComponent(name)+'&on='+on,{cache:'no-store'}); }catch(e){}
  loadCleanup();
}
async function removeApp(pkg,label){
  if(!confirm('App "'+label+'" wirklich entfernen?\n\n('+pkg+')\nBei Bedarf im Microsoft Store neu installierbar.')) return;
  const o=$('cleanup-out'); o.style.display='block'; o.textContent='Entferne '+label+' ...';
  o.textContent=await runToEnd('removeapp',pkg);
  loadCleanup();
}
async function runAsyncC(action,btn,busy){
  const o=$('freeup-out'); o.style.display='block'; o.textContent='';
  const old=btn.textContent; btn.disabled=true; btn.innerHTML='<span class="spin"></span>'+busy+' ...';
  o.textContent=await runToEnd(action,null);
  btn.disabled=false; btn.textContent=old;
}

/* -------- Schnellstart-Werkzeuge -------- */
const TOOLS=[
  {t:'taskmgr',n:'Task-Manager',i:'&#128202;'},{t:'devmgmt',n:'Geraete-Manager',i:'&#128268;'},
  {t:'diskmgmt',n:'Datentraeger',i:'&#128190;'},{t:'services',n:'Dienste',i:'&#9881;&#65039;'},
  {t:'resmon',n:'Ressourcen',i:'&#128200;'},{t:'cleanmgr',n:'Datentraeger-Bereinigung',i:'&#129529;'},
  {t:'msconfig',n:'Systemkonfig',i:'&#128295;'},{t:'control',n:'Systemsteuerung',i:'&#127918;'},
  {t:'regedit',n:'Registry-Editor',i:'&#128273;'},{t:'powercfg',n:'Energieoptionen',i:'&#9889;'},
  {t:'display',n:'Anzeige',i:'&#128421;&#65039;'},{t:'sound',n:'Sound',i:'&#128266;'},
  {t:'update',n:'Windows Update',i:'&#128260;'},{t:'gaming',n:'Game Mode',i:'&#127918;'},
  {t:'startup',n:'Autostart',i:'&#128640;'},{t:'apps',n:'Apps',i:'&#128230;'}
];
$('toolTiles').innerHTML=TOOLS.map(t=>'<div class="tile" onclick="launch(\''+t.t+'\')"><div class="ti">'+t.i+'</div><div class="tn">'+t.n+'</div></div>').join('');
async function launch(t){
  const o=$('tool-out'); o.style.display='block'; o.textContent='Oeffne '+t+' ...';
  try{ const r=await (await fetch('/api/run?a=launch&t='+encodeURIComponent(t),{cache:'no-store'})).json();
    o.textContent=r.output||('Geoeffnet: '+t); }
  catch(e){ o.textContent='Fehler beim Oeffnen.'; }
}

/* -------- Prozesse -------- */
let procData=[], procSortKey='ram';
async function loadProcesses(){
  try{ const d=await (await fetch('/api/processes',{cache:'no-store'})).json(); procData=d.procs||[]; renderProcs(); }catch(e){}
}
function procSort(k){ procSortKey=k; renderProcs(); }
function renderProcs(){
  const q=($('proc-search')?$('proc-search').value:'').toLowerCase().trim();
  let list=procData.slice();
  if(q) list=list.filter(p=>String(p.name).toLowerCase().includes(q));
  list.sort((a,b)=> procSortKey==='name' ? String(a.name).localeCompare(String(b.name)) : (parseFloat(b[procSortKey])||0)-(parseFloat(a[procSortKey])||0));
  const maxRam=Math.max(1,...procData.map(p=>parseFloat(p.ram)||0));
  const cnt=$('proc-count'); if(cnt) cnt.textContent='('+list.length+(q?(' / '+procData.length):'')+')';
  ['ram','cpu','name'].forEach(k=>{ const b=$('proc-sort-'+k); if(b){ b.className='btn sm '+(procSortKey===k?'':'ghost'); } });
  $('procBody').innerHTML=list.map(p=>{
    const ramPct=Math.min(100,(parseFloat(p.ram)||0)/maxRam*100);
    const hot=ramPct>60;
    return '<tr><td><b style="'+(hot?'color:var(--accent)':'')+'">'+esc(p.name)+'</b></td><td class="mono">'+p.pid+'</td>'+
      '<td class="mono"><div style="display:flex;align-items:center;gap:8px"><span style="min-width:64px">'+p.ram+' MB</span><span style="flex:1;height:5px;border-radius:5px;background:rgba(255,255,255,.06);overflow:hidden;min-width:50px"><i style="display:block;height:100%;width:'+ramPct+'%;background:linear-gradient(90deg,var(--accent),var(--accent2))"></i></span></div></td>'+
      '<td class="mono">'+p.cpu+'</td>'+
      '<td style="text-align:right"><button class="btn danger sm" onclick="killProc('+p.pid+',\''+esc(p.name).replace(/\x27/g,"")+'\')">Beenden</button></td></tr>';
  }).join('') || '<tr><td colspan="5"><div class="kv"><span>Keine Treffer.</span></div></td></tr>';
}
async function killProc(pid,name){
  if(!confirm('Prozess "'+name+'" (PID '+pid+') wirklich beenden?')) return;
  try{ await fetch('/api/run?a=kill&pid='+pid,{cache:'no-store'}); }catch(e){}
  setTimeout(loadProcesses,400);
}

/* -------- Uebersicht -------- */
async function loadOverview(){
  try{
    const s=await (await fetch('/api/stats',{cache:'no-store'})).json();
    const h=await (await fetch('/api/hardware',{cache:'no-store'})).json();
    const gpuShort = (h.gpus&&h.gpus[0]) ? h.gpus[0].name.replace('NVIDIA GeForce ','').replace('AMD Radeon ','') : (s.gpuName||'-');
    const tiles=[
      ['RAM', s.ramUsedGB+' / '+s.ramTotalGB+' GB', s.ramPct+'% belegt','var(--accent2)'],
      ['CPU', (h.cpuCores||s.cores)+' Kerne', s.cpuLoad+'% Auslastung','var(--accent)'],
      ['GPU', gpuShort, (s.gpuLoad!=null?s.gpuLoad+'% Auslastung':'-'),'var(--green)'],
      ['Laufzeit', s.uptime, 'seit letztem Start','var(--blue)']
    ];
    $('ov-tiles').innerHTML=tiles.map(t=>'<div class="card"><div class="head"><span class="lbl">'+t[0]+'</span></div><div style="font-size:22px;font-weight:700;color:'+t[3]+'">'+esc(t[1])+'</div><div class="sub" style="margin-top:4px">'+esc(t[2])+'</div></div>').join('');
    $('ov-cpu').innerHTML=kv('Modell',h.cpuName)+kv('Kerne / Threads',h.cpuCores+' / '+h.cpuThreads)+kv('Takt',h.cpuClock+' GHz')+kv('Auslastung',s.cpuLoad+'%')+(s.cpuTemp!=null?kv('Temperatur',s.cpuTemp+String.fromCharCode(176)+'C'):'');
    $('ov-gpu').innerHTML=((h.gpus&&h.gpus[0])?kv('Modell',h.gpus[0].name)+kv('VRAM',h.gpus[0].vramGB+' GB')+kv('Treiber',h.gpus[0].driver):kv('Modell',s.gpuName||'-'))+(s.gpuTemp!=null?kv('Temperatur',s.gpuTemp+String.fromCharCode(176)+'C'):'')+(s.gpuClock!=null?kv('Takt',s.gpuClock+' MHz'):'');
    $('ov-setup').innerHTML=kv('Betriebssystem',h.osName+' (Build '+h.osBuild+')')+(h.osInstall?kv('Windows installiert',h.osInstall):'')+(h.osDays!=null?kv('Im Einsatz seit',h.osDays+' Tagen'):'')+kv('PC',h.pc||'-')+kv('Mainboard',h.board||'-');
  }catch(e){}
}

/* -------- Fixes -------- */
let cmdData={};
var fixData=[]; var fixCat='Alle';
async function loadFixes(){
  try{ const d=await (await fetch('/api/cmdlib',{cache:'no-store'})).json();
    fixData=d.fixes||[];
    const cats=['Alle',...new Set(fixData.map(f=>f.cat))];
    $('fix-cats').innerHTML=cats.map(c=>'<button class="btn sm '+(c===fixCat?'':'ghost')+'" data-fc="'+esc(c)+'" onclick="fixSetCat(\''+esc(c)+'\')">'+esc(c)+'</button>').join('');
    renderFixes();
  }catch(e){}
}
function fixSetCat(c){ fixCat=c; document.querySelectorAll('#fix-cats button').forEach(b=>b.className='btn sm '+(b.dataset.fc===c?'':'ghost')); renderFixes(); }
function renderFixes(){
  const q=($('fix-search').value||'').toLowerCase().trim();
  let list=fixData.filter(f=>fixCat==='Alle'||f.cat===fixCat);
  if(q) list=list.filter(f=>(f.label+' '+f.desc+' '+f.cat).toLowerCase().includes(q));
  $('fix-count').textContent='('+list.length+')';
  if(!list.length){ $('fix-list').innerHTML='<div class="kv"><span>Keine Reparatur gefunden.</span></div>'; return; }
  $('fix-list').innerHTML=list.map(f=>
    '<div class="tw"><div style="min-width:0"><b>'+esc(f.label)+'</b> <span style="color:var(--accent);font-size:11px">'+esc(f.cat)+'</span>'+(f.reboot?' <span style="color:var(--yellow);font-size:11px">(Neustart)</span>':'')+(f.slow?' <span style="color:var(--muted);font-size:11px">(dauert)</span>':'')+'<br><span style="color:var(--muted);font-size:12px">'+esc(f.desc)+'</span></div>'+
    '<button class="btn sm" onclick="runCmd(\''+f.id+'\',\'fix-out\',this,\'Repariere\')">Reparieren</button></div>').join('');
}
async function runCmd(id,outId,btn,busy){
  const o=$(outId); o.style.display='block'; o.textContent='';
  const old=btn.textContent; btn.disabled=true; btn.innerHTML='<span class="spin"></span>'+(busy||'Laeuft')+' ...';
  o.textContent=await runToEndRaw('/api/run?a=cmd&id='+encodeURIComponent(id));
  btn.disabled=false; btn.textContent=old;
}
/* -------- Async-Aktionen (mit Polling) -------- */
async function runToEndRaw(runUrl){
  let r=await (await fetch(runUrl,{cache:'no-store'})).json();
  if(r.done) return r.output||'';
  const id=r.id;
  for(let i=0;i<1800;i++){
    await new Promise(s=>setTimeout(s,500));
    r=await (await fetch('/api/result?id='+id,{cache:'no-store'})).json();
    if(r.done) return r.output||'';
  }
  return 'Zeitueberschreitung.';
}
async function runToEnd(action,arg){
  return runToEndRaw('/api/run?a='+encodeURIComponent(action)+(arg!=null?'&arg='+encodeURIComponent(arg):''));
}
async function runAsync(action,arg,btn,busyText){
  const outMap={flushdns:'net-out',renewip:'net-out',pingtest:'net-out',restorepoint:'backup-out'};
  const o=$(outMap[action]||'net-out'); o.style.display='block'; o.textContent='';
  const old=btn.textContent; btn.disabled=true; btn.innerHTML='<span class="spin"></span>'+busyText+' &hellip;';
  const out=await runToEnd(action,arg);
  o.textContent=out||'Fertig.';
  btn.disabled=false; btn.textContent=old;
}

/* -------- Eigene Tools: Auto-Klicker / Tasten-Wiederholer -------- */
function acInterval(){
  const h=parseInt($('ac-h').value)||0, m=parseInt($('ac-m').value)||0, s=parseInt($('ac-s').value)||0, ms=parseInt($('ac-ms').value)||0;
  return Math.max(1, ((h*3600+m*60+s)*1000)+ms);
}
function acPosMode(){
  const fix=document.querySelector('input[name="ac-pos"]:checked').value==='fix';
  ['ac-x','ac-y','ac-pick'].forEach(id=>$(id).disabled=!fix);
}
async function acPick(){
  const o=$('ac-status'); o.style.display='block'; o.textContent='Bewege die Maus an die Zielstelle ... (3s)';
  const btn=$('ac-pick'); btn.disabled=true;
  try{ const d=JSON.parse(await runToEnd('pickpos','3')); $('ac-x').value=d.x; $('ac-y').value=d.y; o.textContent='Position gesetzt: X '+d.x+', Y '+d.y; }catch(e){ o.textContent='Konnte Position nicht lesen.'; }
  btn.disabled=false;
}
function autoStart(){
  const cfg={ interval:acInterval(), button:$('ac-btn').value, doubleClick:$('ac-type').value==='double',
    limit:parseInt($('ac-limit').value)||0, delay:(parseInt($('ac-delay').value)||0)*1000,
    randomOffset: $('ac-rndon').checked ? (parseInt($('ac-rnd').value)||0) : 0 };
  if(document.querySelector('input[name="ac-pos"]:checked').value==='fix'){ cfg.posX=parseInt($('ac-x').value)||0; cfg.posY=parseInt($('ac-y').value)||0; }
  fetch('/api/run?a=autoclick&arg='+encodeURIComponent(JSON.stringify(cfg)),{cache:'no-store'});
  const o=$('ac-status'); o.style.display='block';
  const posTxt = cfg.posX!=null ? ('an X '+cfg.posX+', Y '+cfg.posY) : 'an der aktuellen Mausposition';
  o.textContent='Laeuft '+posTxt+' ... Start in '+(cfg.delay/1000)+'s. Stopp mit dem roten Knopf.';
}
function keyStart(){
  const cfg={ vk:parseInt($('kr-key').value), interval:Math.max(10,parseInt($('kr-interval').value)||100), limit:parseInt($('kr-limit').value)||0, delay:(parseInt($('kr-delay').value)||0)*1000 };
  fetch('/api/run?a=keyrepeat&arg='+encodeURIComponent(JSON.stringify(cfg)),{cache:'no-store'});
  const o=$('kr-status'); o.style.display='block';
  o.textContent='Laeuft ... Start in '+(cfg.delay/1000)+'s. Stopp mit dem roten Knopf.';
}
async function stopInput(){
  try{ await fetch('/api/run?a=stopinput',{cache:'no-store'}); }catch(e){}
  ['ac-status','kr-status','mac-status'].forEach(id=>{const e=$(id); if(e){e.style.display='block';e.textContent='Gestoppt.';}});
}

/* -------- Makro-Editor -------- */
let macroSteps=[];
const KEYLABEL={32:'Leertaste',87:'W',65:'A',83:'S',68:'D',69:'E',81:'Q',82:'R',70:'F',16:'Shift',17:'Strg',13:'Enter',9:'Tab',37:'Pfeil links',38:'Pfeil hoch',39:'Pfeil rechts',40:'Pfeil runter',49:'1',50:'2',51:'3',112:'F1'};
function macAdd(){
  const v=$('mac-key').value; const delay=Math.max(0,parseInt($('mac-delay').value)||0);
  let step;
  if(v==='cl'){ step={type:'click',button:'left',delay,label:'Linksklick'}; }
  else if(v==='cr'){ step={type:'click',button:'right',delay,label:'Rechtsklick'}; }
  else { const vk=parseInt(v); step={type:'key',vk,delay,label:'Taste '+(KEYLABEL[vk]||vk)}; }
  macroSteps.push(step); renderMac();
}
function renderMac(){
  const el=$('mac-steps'); if(!el) return;
  el.innerHTML=macroSteps.length? macroSteps.map((s,i)=>'<div class="tw"><div><b>'+(i+1)+'.</b> '+esc(s.label)+' <span style="color:var(--muted);font-size:12px">(Pause '+s.delay+' ms)</span></div><button class="btn danger sm" onclick="macDel('+i+')">Entfernen</button></div>').join('') : '<div class="kv"><span>Noch keine Schritte &ndash; oben hinzufuegen.</span></div>';
}
function macDel(i){ macroSteps.splice(i,1); renderMac(); }
function macClear(){ macroSteps=[]; renderMac(); }
function macStart(){
  const o=$('mac-status'); o.style.display='block';
  if(!macroSteps.length){ o.textContent='Bitte zuerst Schritte hinzufuegen.'; return; }
  const cfg={ steps:macroSteps.map(s=>({type:s.type,vk:s.vk,button:s.button,delay:s.delay})), loops:parseInt($('mac-loops').value)||0, startDelay:(parseInt($('mac-start').value)||0)*1000 };
  fetch('/api/run?a=macro&arg='+encodeURIComponent(JSON.stringify(cfg)),{cache:'no-store'});
  o.textContent='Makro laeuft ... Start in '+(cfg.startDelay/1000)+'s. Stopp mit dem roten Knopf.';
}
function macArm(){
  const o=$('mac-status'); o.style.display='block';
  if(!macroSteps.length){ o.textContent='Bitte zuerst Schritte hinzufuegen.'; return; }
  const vk=parseInt($('mac-hotkey').value);
  const cfg={ vk, steps:macroSteps.map(s=>({type:s.type,vk:s.vk,button:s.button,delay:s.delay})) };
  fetch('/api/run?a=armmacro&arg='+encodeURIComponent(JSON.stringify(cfg)),{cache:'no-store'});
  const label=$('mac-hotkey').options[$('mac-hotkey').selectedIndex].text;
  o.textContent='Hotkey aktiv: Druecke ['+label+'], um das Makro abzuspielen. "Hotkey aus" beendet es.';
}
async function macDisarm(){
  try{ await fetch('/api/run?a=disarmmacro',{cache:'no-store'}); }catch(e){}
  const o=$('mac-status'); o.style.display='block'; o.textContent='Hotkey deaktiviert.';
}
/* Hotkey per Tastendruck/Mausklick festlegen */
const VKNAMES={1:'Linksklick',2:'Rechtsklick',4:'Mittelklick',5:'Maus X1',6:'Maus X2',8:'Rueck',9:'Tab',13:'Enter',16:'Shift',17:'Strg',18:'Alt',19:'Pause',20:'Feststell',27:'Esc',32:'Leertaste',33:'Bild auf',34:'Bild ab',35:'Ende',36:'Pos1',45:'Einfg',46:'Entf',37:'Pfeil links',38:'Pfeil hoch',39:'Pfeil rechts',40:'Pfeil runter',112:'F1',113:'F2',114:'F3',115:'F4',116:'F5',117:'F6',118:'F7',119:'F8',120:'F9',121:'F10',122:'F11',123:'F12'};
function vkLabel(vk){ if(VKNAMES[vk])return VKNAMES[vk]; if((vk>=65&&vk<=90)||(vk>=48&&vk<=57))return String.fromCharCode(vk); return 'Taste '+vk; }
function captureHotkey(selId,btn){
  const sel=$(selId); if(!sel) return;
  const old=btn.textContent; btn.disabled=true; btn.textContent='Druecke Taste/Maustaste ...';
  const finish=(vk)=>{
    document.removeEventListener('keydown',onKey,true); document.removeEventListener('mousedown',onMouse,true);
    btn.disabled=false; btn.textContent=old;
    let opt=[...sel.options].find(o=>parseInt(o.value)===vk);
    if(!opt){ opt=document.createElement('option'); opt.value=vk; opt.textContent=vkLabel(vk); sel.appendChild(opt); }
    sel.value=vk;
    if(btn.dataset.echo){ const e=$(btn.dataset.echo); if(e){ e.textContent='Gesetzt: '+vkLabel(vk); } }
  };
  const onKey=(e)=>{ e.preventDefault(); e.stopPropagation(); finish(e.keyCode||e.which); };
  const onMouse=(e)=>{ e.preventDefault(); e.stopPropagation(); const map={0:1,1:4,2:2,3:5,4:6}; finish(map[e.button]!=null?map[e.button]:1); };
  setTimeout(()=>{ document.addEventListener('keydown',onKey,true); document.addEventListener('mousedown',onMouse,true); },50);
}

/* -------- Toolbox: Fenster-Manager -------- */
let winTopState={};
async function loadWindows(){
  const el=$('win-list'); if(!el) return;
  el.innerHTML='<div class="kv"><span>Lade Fenster &hellip;</span></div>';
  let d={};
  try{ d=JSON.parse(await runToEnd('winlist')); }catch(e){ el.innerHTML='<div class="kv"><span>Konnte Fenster nicht laden.</span></div>'; return; }
  const ws=(d.windows||[]).filter(w=>w.title && w.proc!=='PC-Boost');
  el.innerHTML = ws.length? ws.map(w=>{
    const top=winTopState[w.hwnd]?1:0;
    return '<div class="tw"><div style="min-width:0"><b style="word-break:break-all">'+esc(w.title)+'</b><br><span style="color:var(--muted);font-size:11px">'+esc(w.proc||'')+'</span></div><div style="display:flex;gap:6px;flex-wrap:wrap;flex:none">'+
      '<button class="btn ghost sm" onclick="winAct(\'winfocus\',\''+w.hwnd+'\')">Vordergrund</button>'+
      '<button class="btn '+(top?'':'ghost')+' sm" onclick="winTop(\''+w.hwnd+'\')">'+(top?'Oben &#10003;':'Immer oben')+'</button>'+
      '<button class="btn danger sm" onclick="winAct(\'winclose\',\''+w.hwnd+'\')">Schliessen</button></div></div>';
  }).join('') : '<div class="kv"><span>Keine Fenster gefunden.</span></div>';
}
async function winAct(a,hwnd){ await runToEnd(a,String(hwnd)); if(a==='winclose'){ setTimeout(loadWindows,500); } }
async function winTop(hwnd){ const on=winTopState[hwnd]?0:1; winTopState[hwnd]=on; await runToEnd('wintop',hwnd+','+on); loadWindows(); }

/* Screenshot */
let shotPath='';
async function takeShot(){
  const btn=$('shot-btn'), o=$('shot-out'); o.style.display='block'; o.textContent='';
  const old=btn.textContent; btn.disabled=true; btn.innerHTML='<span class="spin"></span>Nehme auf &hellip;';
  const r=await runToEnd('screenshot');
  btn.disabled=false; btn.textContent=old;
  if(r.indexOf('PATH:')===0){ shotPath=r.slice(5); o.innerHTML='Gespeichert: <span class="mono">'+esc(shotPath)+'</span> &nbsp;<button class="btn ghost sm" onclick="revealPath()">Ordner oeffnen</button>'; }
  else { o.textContent=r; }
}
async function revealPath(){ if(shotPath){ await runToEndRaw('/api/run?a=reveal&path='+encodeURIComponent(shotPath)); } }

/* Farb-Picker */
let cpHex='';
async function pickColor(){
  const btn=$('cp-btn'); const delay=parseInt($('cp-delay').value)||0;
  const old=btn.textContent; btn.disabled=true; btn.innerHTML='<span class="spin"></span>'+delay+'s &hellip;';
  let d={};
  try{ d=JSON.parse(await runToEnd('colorpick',String(delay))); }catch(e){ btn.disabled=false; btn.textContent=old; return; }
  btn.disabled=false; btn.textContent=old; cpHex=d.hex;
  $('cp-result').style.display='flex';
  $('cp-swatch').style.background=d.hex;
  $('cp-hex').textContent=d.hex;
  $('cp-rgb').textContent='RGB '+d.r+', '+d.g+', '+d.b+'  (Pos '+d.x+','+d.y+')';
}
function cpCopy(){ if(cpHex){ try{ navigator.clipboard.writeText(cpHex); }catch(e){} } }

/* Datei-Shredder */
async function shredFile(){
  const path=$('shred-path').value.trim(), o=$('shred-out'); o.style.display='block';
  if(!path){ o.textContent='Bitte einen Dateipfad eingeben.'; return; }
  if(!confirm('Diese Datei wird UNWIDERRUFLICH ueberschrieben und geloescht:\n\n'+path+'\n\nWirklich fortfahren?')) return;
  const btn=$('shred-btn'); const old=btn.textContent; btn.disabled=true; btn.innerHTML='<span class="spin"></span>Schreddere &hellip;';
  o.textContent=await runToEnd('shred',path);
  btn.disabled=false; btn.textContent=old; $('shred-path').value='';
}
/* Passwort-Generator */
function genPw(){
  let chars=''; if($('pw-upper').checked)chars+='ABCDEFGHJKLMNPQRSTUVWXYZ'; if($('pw-lower').checked)chars+='abcdefghijkmnpqrstuvwxyz'; if($('pw-num').checked)chars+='23456789'; if($('pw-sym').checked)chars+='!@#$%&*-_=+?';
  if(!chars){ $('pw-result').value=''; $('pw-strength').textContent=''; return; }
  const n=parseInt($('pw-len').value)||16; const arr=new Uint32Array(n); crypto.getRandomValues(arr);
  let out=''; for(let i=0;i<n;i++) out+=chars[arr[i]%chars.length];
  $('pw-result').value=out;
  const bits=Math.round(n*Math.log2(chars.length));
  const lvl=bits<50?'schwach':bits<80?'gut':'sehr stark'; const col=bits<50?'var(--red)':bits<80?'var(--yellow)':'var(--green)';
  $('pw-strength').innerHTML='Staerke: <b style="color:'+col+'">'+lvl+'</b> (~'+bits+' Bit Entropie)';
}
function copyPw(){ const v=$('pw-result').value; if(!v)return; try{ navigator.clipboard.writeText(v); }catch(e){ $('pw-result').select(); document.execCommand('copy'); } }
/* Datei-Hash */
async function calcFileHash(){
  const path=$('fh-path').value.trim(), el=$('fh-result'); if(!path){ el.innerHTML='<div class="kv"><span>Bitte einen Dateipfad eingeben.</span></div>'; return; }
  const btn=$('fh-btn'); const old=btn.textContent; btn.disabled=true; btn.innerHTML='<span class="spin"></span>Berechne &hellip;';
  let d={}; try{ d=JSON.parse(await runToEnd('filehash',path)); }catch(e){ d={ok:false,msg:'Fehler.'}; }
  btn.disabled=false; btn.textContent=old;
  if(!d.ok){ el.innerHTML='<div class="kv"><span>'+esc(d.msg||'Fehler')+'</span></div>'; return; }
  const row=(l,v)=>'<div class="tw" style="padding:8px 0"><div style="min-width:66px"><b>'+l+'</b></div><span class="mono" style="font-size:11px;word-break:break-all;flex:1">'+esc(v)+'</span></div>';
  el.innerHTML='<div class="kv"><span>'+esc(d.name)+'</span><b>'+d.sizeKB+' KB</b></div>'+row('MD5',d.md5)+row('SHA1',d.sha1)+row('SHA256',d.sha256);
}
/* Notizblock */
function loadNotes(){ const t=$('notes'); if(t){ try{ t.value=localStorage.getItem('pcb_notes')||''; }catch(e){} } }
function saveNotes(){ try{ localStorage.setItem('pcb_notes',$('notes').value); }catch(e){} const s=$('notes-saved'); if(s) s.textContent='Automatisch gespeichert.'; }
var srText='';
async function makeReport(){
  const b=$('sr-btn'); const old=b.textContent; b.disabled=true; b.innerHTML='<span class="spin"></span>Sammle Daten &hellip;';
  try{
    const d=JSON.parse(await runToEnd('sysreport'));
    srText=d.text||'';
    $('sr-text').textContent=srText; $('sr-text').style.display='block'; $('sr-copy').style.display='inline-block';
    $('sr-path').textContent=d.path?('Gespeichert unter: '+d.path):'';
  }catch(e){ $('sr-text').textContent='Konnte Bericht nicht erstellen.'; $('sr-text').style.display='block'; }
  b.disabled=false; b.textContent=old;
}
function copyReport(){ if(srText){ navigator.clipboard.writeText(srText).catch(()=>{}); const b=$('sr-copy'); const o=b.textContent; b.textContent='Kopiert!'; setTimeout(()=>b.textContent=o,1200); } }

/* -------- Programme deinstallieren -------- */
var progData=[], progSortMode='name';
async function loadPrograms(){
  $('prog-list').innerHTML='<div class="kv"><span>Lade Programmliste &hellip;</span></div>';
  try{ const d=JSON.parse(await runToEnd('proglist')); progData=d.apps||[]; renderPrograms(); }
  catch(e){ $('prog-list').innerHTML='<div class="kv"><span>Konnte Programmliste nicht laden.</span></div>'; }
}
function progToggleSort(){ progSortMode=progSortMode==='name'?'size':'name'; $('prog-sort').textContent=progSortMode==='name'?'Nach Groesse':'Nach Name'; renderPrograms(); }
function renderPrograms(){
  const q=($('prog-search').value||'').toLowerCase().trim();
  let list=progData.slice();
  if(q) list=list.filter(a=>((a.name||'')+' '+(a.pub||'')).toLowerCase().includes(q));
  if(progSortMode==='size') list.sort((a,b)=>(b.sizeMB||0)-(a.sizeMB||0));
  else list.sort((a,b)=>(a.name||'').localeCompare(b.name||''));
  $('prog-count').textContent='('+list.length+')';
  if(!list.length){ $('prog-list').innerHTML='<div class="kv"><span>Nichts gefunden.</span></div>'; return; }
  $('prog-list').innerHTML=list.map(a=>{
    const idx=progData.indexOf(a);
    const size=a.sizeMB?(a.sizeMB>1024?(a.sizeMB/1024).toFixed(1)+' GB':a.sizeMB+' MB'):'';
    return '<div class="tw"><div style="min-width:0"><b>'+esc(a.name)+'</b>'+(a.ver?' <span style="color:var(--muted);font-size:11px">'+esc(a.ver)+'</span>':'')+'<br><span style="color:var(--muted);font-size:12px">'+esc(a.pub||'')+(size?' &middot; '+size:'')+'</span></div>'+
      '<button class="btn danger sm" onclick="uninstallProg('+idx+')">Deinstallieren</button></div>';
  }).join('');
}
async function uninstallProg(i){
  const a=progData[i]; if(!a) return;
  if(!confirm('"'+a.name+'" deinstallieren?\n\nDer Uninstaller des Programms wird gestartet - folge dann seinem Fenster.')) return;
  const o=$('prog-out'); o.style.display='block'; o.textContent='Starte Deinstallation von '+a.name+' &hellip;';
  o.textContent=await runToEnd('uninstall',a.uninstall);
}

/* -------- Absturz- & Fehler-Analyse -------- */
async function loadEvents(){
  $('ev-list').innerHTML='<div class="kv"><span>Lese Ereignisprotokoll &hellip;</span></div>';
  try{
    const d=JSON.parse(await runToEnd('eventlog')); const evs=d.events||[];
    $('ev-count').textContent='('+evs.length+')';
    if(!evs.length){ $('ev-list').innerHTML='<div class="kv"><span>Keine kritischen Fehler in den letzten 7 Tagen. Sauber!</span></div>'; return; }
    $('ev-list').innerHTML=evs.map(e=>{
      const crit=e.lvl===1; const col=crit?'var(--red)':'var(--yellow)'; const badge=crit?'Kritisch':'Fehler';
      return '<div class="tw" style="align-items:flex-start"><div style="min-width:0"><b>'+esc(e.src)+'</b> <span style="color:'+col+';font-size:11px">'+badge+'</span> <span style="color:var(--muted);font-size:11px">ID '+e.id+' &middot; '+esc(e.log)+'</span><br><span style="color:var(--muted);font-size:12px">'+esc(e.msg)+'</span></div><span class="mono" style="color:var(--muted);font-size:12px;white-space:nowrap;margin-left:10px">'+esc(e.time)+'</span></div>';
    }).join('');
  }catch(e){ $('ev-list').innerHTML='<div class="kv"><span>Konnte Ereignisprotokoll nicht lesen (evtl. Adminrechte noetig).</span></div>'; }
}

/* -------- Treiber-Uebersicht -------- */
async function loadDrivers(){
  const b=$('drv-btn'); const old=b.textContent; b.disabled=true; b.innerHTML='<span class="spin"></span>Pruefe &hellip;';
  $('drv-list').innerHTML='<div class="kv"><span>Lese Treiber &hellip;</span></div>';
  try{
    const d=JSON.parse(await runToEnd('drivers')); const dr=d.drivers||[];
    if(!dr.length){ $('drv-list').innerHTML='<div class="kv"><span>Keine Treiber gefunden.</span></div>'; }
    else $('drv-list').innerHTML=dr.map(x=>{
      const alt=x.ageY!=null&&x.ageY>=2; const col=alt?'var(--yellow)':'var(--muted)';
      return '<div class="tw"><div style="min-width:0"><b>'+esc(x.name)+'</b><br><span style="color:var(--muted);font-size:12px">v'+esc(x.ver||'?')+(x.date?' &middot; '+esc(x.date):'')+'</span></div>'+
        '<span style="color:'+col+';font-size:12px;white-space:nowrap">'+(x.ageY!=null?x.ageY+' Jahre'+(alt?' (alt)':''):'')+'</span></div>';
    }).join('');
  }catch(e){ $('drv-list').innerHTML='<div class="kv"><span>Konnte Treiber nicht lesen.</span></div>'; }
  b.disabled=false; b.textContent=old;
}

/* -------- Gaming-Overlay -------- */
var ovRunning=false;
function ovConfig(mode){
  return {
    mode: mode||'on',
    metrics:{ cpu:$('ovm-cpu').checked, cpuTemp:$('ovm-cpuTemp').checked, gpu:$('ovm-gpu').checked, gpuTemp:$('ovm-gpuTemp').checked, vram:$('ovm-vram').checked, ram:$('ovm-ram').checked, gpuClock:$('ovm-gpuClock').checked, gpuPower:$('ovm-gpuPower').checked, net:$('ovm-net').checked, clock:$('ovm-clock').checked, input:$('ovm-input').checked },
    accent:$('ov-accent').value, opacity:parseInt($('ov-op').value)||85, scale:parseInt($('ov-scale').value)||100, pos:$('ov-pos').value,
    graph: $('ov-graph') ? $('ov-graph').checked : true
  };
}
function ovLoadCfg(){
  let c={}; try{ c=JSON.parse(localStorage.getItem('pcb_overlay')||'{}'); }catch(e){}
  if(c.metrics){ ['cpu','cpuTemp','gpu','gpuTemp','vram','ram','gpuClock','gpuPower','net','clock','input'].forEach(k=>{ if($('ovm-'+k)) $('ovm-'+k).checked=!!c.metrics[k]; }); }
  if(c.accent&&$('ov-accent')) $('ov-accent').value=c.accent;
  if(c.opacity&&$('ov-op')){ $('ov-op').value=c.opacity; $('ov-op-lbl').textContent=c.opacity; }
  if(c.scale&&$('ov-scale')){ $('ov-scale').value=c.scale; $('ov-scale-lbl').textContent=c.scale; }
  if(c.pos&&$('ov-pos')) $('ov-pos').value=c.pos;
  if($('ov-graph')) $('ov-graph').checked = (c.graph!==false);
}
function ovSaveCfg(){ try{ localStorage.setItem('pcb_overlay',JSON.stringify(ovConfig('on'))); }catch(e){} }
async function ovApply(){
  ovSaveCfg();
  if(ovRunning){ try{ await runToEnd('overlay',JSON.stringify(ovConfig('on'))); }catch(e){} }
}
async function overlayToggle(mode,btn){
  const o=$('overlay-out'); o.style.display='block'; o.textContent=mode==='on'?'Starte Overlay ...':'Schliesse Overlay ...';
  const old=btn.textContent; btn.disabled=true;
  o.textContent=await runToEnd('overlay',JSON.stringify(ovConfig(mode)));
  ovRunning=(mode==='on');
  btn.disabled=false; btn.textContent=old;
}

/* -------- Einheiten-Umrechner -------- */
var UC={
  'Datengroesse':{Byte:1,KB:1024,MB:1048576,GB:1073741824,TB:1099511627776},
  'Laenge':{mm:0.001,cm:0.01,m:1,km:1000,Zoll:0.0254,Fuss:0.3048,Meile:1609.344},
  'Gewicht':{mg:0.001,g:1,kg:1000,Tonne:1000000,Unze:28.3495,Pfund:453.592},
  'Temperatur':{'Celsius':'C','Fahrenheit':'F','Kelvin':'K'}
};
function ucInit(){ const c=$('uc-cat'); if(!c||c.options.length) return; c.innerHTML=Object.keys(UC).map(k=>'<option>'+k+'</option>').join(''); ucBuild(); }
function ucBuild(){
  const cat=$('uc-cat').value; const units=Object.keys(UC[cat]);
  $('uc-from').innerHTML=units.map(u=>'<option>'+u+'</option>').join('');
  $('uc-to').innerHTML=units.map(u=>'<option>'+u+'</option>').join('');
  if(units.length>1) $('uc-to').selectedIndex=1;
  ucCalc();
}
function ucCalc(){
  const cat=$('uc-cat').value, from=$('uc-from').value, to=$('uc-to').value;
  const v=parseFloat($('uc-val').value); const out=$('uc-result');
  if(isNaN(v)){ out.textContent='-'; return; }
  let res;
  if(cat==='Temperatur'){
    let c; const f=UC.Temperatur[from], t=UC.Temperatur[to];
    if(f==='C') c=v; else if(f==='F') c=(v-32)*5/9; else c=v-273.15;
    if(t==='C') res=c; else if(t==='F') res=c*9/5+32; else res=c+273.15;
  } else {
    res=v*UC[cat][from]/UC[cat][to];
  }
  const r=Math.round(res*1e6)/1e6;
  out.textContent=v+' '+from+' = '+r+' '+to;
}

/* -------- Passwort-Manager (lokal, AES-256 verschluesselt) -------- */
let pmKey=null, pmVault=[];
function pmB64(a){ let s=''; for(let i=0;i<a.length;i++) s+=String.fromCharCode(a[i]); return btoa(s); }
function pmUB64(s){ return Uint8Array.from(atob(s),c=>c.charCodeAt(0)); }
async function pmDeriveKey(pw,salt){ const base=await crypto.subtle.importKey('raw',new TextEncoder().encode(pw),'PBKDF2',false,['deriveKey']); return crypto.subtle.deriveKey({name:'PBKDF2',salt,iterations:200000,hash:'SHA-256'},base,{name:'AES-GCM',length:256},false,['encrypt','decrypt']); }
async function pmSave(){ const iv=crypto.getRandomValues(new Uint8Array(12)); const ct=await crypto.subtle.encrypt({name:'AES-GCM',iv},pmKey,new TextEncoder().encode(JSON.stringify(pmVault))); const store=JSON.parse(localStorage.getItem('pcb_vault')||'{}'); store.iv=pmB64(iv); store.ct=pmB64(new Uint8Array(ct)); localStorage.setItem('pcb_vault',JSON.stringify(store)); }
function pmGen(){ const chars='ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%&*-_=+?'; const n=16; const arr=new Uint32Array(n); crypto.getRandomValues(arr); let out=''; for(let i=0;i<n;i++)out+=chars[arr[i]%chars.length]; return out; }
function pmInit(){
  if(pmKey){ pmShowVault(); return; }
  const store=JSON.parse(localStorage.getItem('pcb_vault')||'null');
  const lock=$('pm-lock-body'), title=$('pm-lock-title');
  $('pm-vault').style.display='none'; $('pm-add').style.display='none'; $('pm-lock').style.display='block';
  if(!store){
    title.textContent='MASTER-PASSWORT FESTLEGEN';
    lock.innerHTML='<p class="card sub" style="border:none;padding:0;margin-bottom:12px">Waehle ein starkes Master-Passwort. Damit wird dein Tresor verschluesselt. <b>Merke es dir gut &ndash; es gibt keine Wiederherstellung.</b></p><div class="field"><label>Master-Passwort</label><input id="pm-mp1" type="password"></div><div class="field"><label>Wiederholen</label><input id="pm-mp2" type="password"></div><button class="btn" onclick="pmSetup()">Tresor erstellen</button>';
  } else {
    title.textContent='TRESOR ENTSPERREN';
    lock.innerHTML='<div class="field"><label>Master-Passwort</label><input id="pm-mp1" type="password" onkeydown="if(event.key===\'Enter\')pmUnlock()"></div><button class="btn" onclick="pmUnlock()">Entsperren</button>';
  }
}
async function pmSetup(){
  const a=$('pm-mp1').value, b=$('pm-mp2').value, o=$('pm-lock-out'); o.style.display='block';
  if(a.length<6){ o.textContent='Master-Passwort mindestens 6 Zeichen.'; return; }
  if(a!==b){ o.textContent='Passwoerter stimmen nicht ueberein.'; return; }
  const salt=crypto.getRandomValues(new Uint8Array(16));
  localStorage.setItem('pcb_vault',JSON.stringify({salt:pmB64(salt)}));
  pmKey=await pmDeriveKey(a,salt); pmVault=[]; await pmSave(); o.textContent=''; pmShowVault();
}
async function pmUnlock(){
  const pw=$('pm-mp1').value, o=$('pm-lock-out'); o.style.display='block'; o.textContent='Entsperre &hellip;';
  const store=JSON.parse(localStorage.getItem('pcb_vault'));
  try{ const key=await pmDeriveKey(pw,pmUB64(store.salt)); const pt=await crypto.subtle.decrypt({name:'AES-GCM',iv:pmUB64(store.iv)},key,pmUB64(store.ct)); pmVault=JSON.parse(new TextDecoder().decode(pt)); pmKey=key; o.textContent=''; pmShowVault(); }
  catch(e){ o.textContent='Falsches Master-Passwort.'; }
}
function pmLock(){ pmKey=null; pmVault=[]; if($('pm-search'))$('pm-search').value=''; pmInit(); }
function pmShowVault(){ $('pm-lock').style.display='none'; $('pm-vault').style.display='block'; $('pm-add').style.display='block'; pmRender(); }
function pmRender(){
  const q=($('pm-search')?$('pm-search').value:'').toLowerCase();
  const list=pmVault.map((e,i)=>({e,i})).filter(x=> !q || (x.e.title+' '+(x.e.user||'')+' '+(x.e.url||'')).toLowerCase().includes(q));
  $('pm-count').textContent='('+pmVault.length+')';
  $('pm-list').innerHTML=list.length? list.map(x=>{ const e=x.e,i=x.i;
    return '<div class="tw"><div style="min-width:0"><b>'+esc(e.title)+'</b>'+(e.url?' <span style="color:var(--muted);font-size:11px">'+esc(e.url)+'</span>':'')+'<br><span style="color:var(--muted);font-size:12px">'+esc(e.user||'')+'</span>'+(e.note?'<br><span style="color:var(--muted);font-size:11px">'+esc(e.note)+'</span>':'')+'<br><span class="mono" id="pmpw-'+i+'" style="font-size:13px;color:var(--muted)">********</span></div><div style="display:flex;gap:6px;flex-wrap:wrap;flex:none"><button class="btn ghost sm" onclick="pmToggle('+i+')">Zeigen</button><button class="btn ghost sm" onclick="pmCopy('+i+')">Kopieren</button><button class="btn danger sm" onclick="pmDel('+i+')">Loeschen</button></div></div>';
  }).join('') : '<div class="kv"><span>Noch keine Eintraege &ndash; unten hinzufuegen.</span></div>';
}
function pmToggle(i){ const el=$('pmpw-'+i); if(!el)return; if(el.dataset.shown){ el.textContent='********'; el.style.color='var(--muted)'; delete el.dataset.shown; } else { el.textContent=pmVault[i].pw||''; el.style.color='var(--txt)'; el.dataset.shown='1'; } }
function pmCopy(i){ try{ navigator.clipboard.writeText(pmVault[i].pw||''); }catch(e){} }
async function pmDel(i){ if(!confirm('Eintrag "'+pmVault[i].title+'" wirklich loeschen?'))return; pmVault.splice(i,1); await pmSave(); pmRender(); }
async function pmAdd(){
  const t=$('pm-title').value.trim(), o=$('pm-add-out'); o.style.display='block';
  if(!t){ o.textContent='Titel ist Pflicht.'; return; }
  pmVault.push({title:t,user:$('pm-user').value.trim(),pw:$('pm-pw').value,url:$('pm-url').value.trim(),note:$('pm-note').value.trim()});
  await pmSave();
  ['pm-title','pm-user','pm-pw','pm-url','pm-note'].forEach(id=>$(id).value='');
  o.textContent='Verschluesselt gespeichert.'; pmRender();
}

/* -------- PC ausmisten: grosse Dateien -------- */
let bigFiles=[];
async function scanBig(){
  const dir=$('big-dir').value; const o=$('big-list'); o.innerHTML='<div class="kv"><span>Scanne '+dir+' ...</span></div>';
  try{
    const d=await (await fetch('/api/bigfiles?dir='+dir,{cache:'no-store'})).json();
    bigFiles=d.files||[];
    o.innerHTML=bigFiles.length? bigFiles.map((fi,i)=>'<div class="tw"><div style="min-width:0"><b>'+esc(fi.name)+'</b> <span style="color:var(--muted);font-size:12px">'+fi.sizeMB+' MB &middot; '+esc(fi.modified)+'</span><br><span style="color:var(--muted);font-size:11px;word-break:break-all">'+esc(fi.path)+'</span></div><button class="btn danger sm" onclick="recycleFile('+i+')">In Papierkorb</button></div>').join('') : '<div class="kv"><span>Keine Dateien gefunden (oder Ordner leer).</span></div>';
  }catch(e){ o.innerHTML='<div class="kv"><span>Fehler beim Scannen.</span></div>'; }
}
async function recycleFile(i){
  const fi=bigFiles[i]; if(!fi) return;
  if(!confirm('"'+fi.name+'" ('+fi.sizeMB+' MB) in den Papierkorb legen?\n(Wiederherstellbar aus dem Papierkorb.)')) return;
  const r=await runToEnd('recyclefile', fi.path);
  alert(r); scanBig();
}

/* -------- Login / Zugangsschutz (E-Mail-Verifizierung oder Passwort) -------- */
let loginMode='login', appStarted=false, loginStep='email';
async function sha256(s){ const b=await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s)); return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join(''); }
function renderNavBadges(){
  document.querySelectorAll('.nav').forEach(n=>{
    const cat=n.dataset.cat; if(!cat||!CATS[cat]) return;
    const subs=CATS[cat].subs.filter(s=> s[0]!=='admin' || window.isAdminUser);
    let b=n.querySelector('.navbadge');
    if(!subs.length){ if(b) b.remove(); return; }
    if(!b){ b=document.createElement('span'); b.className='navbadge'; b.style.cssText='margin-left:auto;font-size:11px;color:var(--muted);background:var(--panel2);border-radius:8px;padding:1px 7px'; n.appendChild(b); }
    b.textContent=subs.length;
  });
}
function initApp(){ if(appStarted)return; appStarted=true; showCat('overview'); renderNavBadges(); tick(); setInterval(tick,1000); checkAdmin(); }
async function checkAdmin(){
  try{ const s=await (await fetch('/api/admin/status',{cache:'no-store'})).json();
    window.isAdminUser=!!s.isAdmin;
    renderNavBadges();
    if(curCat==='system') showCat('system'); }catch(e){}
}
function unlock(){ localStorage.setItem('pcb_unlocked','1'); $('login').style.display='none'; initApp(); }
async function logout(){ localStorage.removeItem('pcb_unlocked'); try{ await fetch('/api/run?a=logout',{cache:'no-store'}); }catch(e){} location.reload(); }
function setLocalMode(mode){
  loginMode=mode; $('login-err').textContent='';
  $('login-email').style.display='block'; $('login-pw').style.display='block';
  $('login-btn').style.display='block'; $('login-toggle').style.display='block';
  if(mode==='register'){
    $('login-sub').textContent='Neues Konto anlegen (nur auf diesem PC).';
    $('login-pw').placeholder='Passwort (min. 4 Zeichen)';
    $('login-btn').textContent='Konto erstellen';
    $('login-toggle').textContent='Schon ein Konto? Anmelden';
  } else {
    $('login-sub').textContent='Melde dich an oder erstelle ein Konto.';
    $('login-pw').placeholder='Passwort';
    $('login-btn').textContent='Anmelden';
    $('login-toggle').textContent='Noch kein Konto? Konto erstellen';
  }
  $('login-email').focus();
}
function toggleMode(){ setLocalMode(loginMode==='register' ? 'login' : 'register'); }
async function checkAuth(){
  if(localStorage.getItem('pcb_unlocked')==='1'){ unlock(); return; }
  try{
    const m=await (await fetch('/api/authmode',{cache:'no-store'})).json();
    $('login-discord').style.display = m.discord ? 'block' : 'none';
    $('login-or').style.display = m.discord ? 'block' : 'none';
    setLocalMode('login');
  }catch(e){ setTimeout(checkAuth,500); }   // Server noch nicht bereit
}
async function discordLogin(){
  const err=$('login-err'); err.textContent='';
  try{ const r=await (await fetch('/api/discord/login',{cache:'no-store'})).json();
    if(r.ok && r.url){ location.href=r.url; } else { err.textContent=r.msg||'Discord nicht verfuegbar.'; }
  }catch(e){ err.textContent='Server nicht erreichbar.'; }
}
function loginAction(){ if(loginMode==='register') doRegister(); else doUserLogin(); }
async function doUserLogin(){
  const name=$('login-email').value.trim(), pw=$('login-pw').value, err=$('login-err'); err.textContent='';
  if(!name||!pw){ return; }
  const h=await sha256(pw);
  try{ const r=await (await fetch('/api/run?a=userlogin&email='+encodeURIComponent(name)+'&h='+h,{cache:'no-store'})).json();
    if(r.ok){ unlock(); } else { err.textContent='Name oder Passwort falsch.'; }
  }catch(e){ err.textContent='Server nicht erreichbar.'; }
}
async function doRegister(){
  const name=$('login-email').value.trim(), pw=$('login-pw').value, err=$('login-err'); err.textContent='';
  if(!name){ err.textContent='Bitte einen Namen eingeben.'; return; }
  if(pw.length<4){ err.textContent='Passwort mindestens 4 Zeichen.'; return; }
  const h=await sha256(pw);
  const b=$('login-btn'); const old=b.textContent; b.disabled=true; b.innerHTML='<span class="spin"></span>Bitte warten ...';
  let r={};
  try{ r=await (await fetch('/api/run?a=localregister&email='+encodeURIComponent(name)+'&h='+h,{cache:'no-store'})).json(); }
  catch(e){ r={ok:false,msg:'Server nicht erreichbar.'}; }
  b.disabled=false; b.textContent=old;
  if(r.ok){ unlock(); } else { err.textContent=r.msg||'Fehler.'; }
}
function resendCode(){}

/* -------- Energie / Power -------- */
async function powerAct(mode){
  const sec=parseInt($('pw-sec')?$('pw-sec').value:0)||0;
  if(mode==='shutdown'||mode==='restart'){ if(!confirm((mode==='shutdown'?'Herunterfahren':'Neustart')+(sec>0?(' in '+sec+' Sekunden'):' JETZT')+'?')) return; }
  const o=$('pw-out'); if(o){ o.style.display='block'; o.textContent='...'; }
  const r=await runToEnd('power',JSON.stringify({mode,seconds:sec}));
  if(o) o.textContent=r;
}

/* -------- Einstellungen / Personalisierung -------- */
const THEMES=[
  {name:'Pink (Standard)',a:'#ff4172',b:'#ff2d78'},{name:'Lila-Pink',a:'#c04bff',b:'#ff4bd8'},
  {name:'Blau',a:'#4b8bff',b:'#4bd8ff'},{name:'Cyan',a:'#22d3ee',b:'#4bb8ff'},
  {name:'Gruen',a:'#35e0a1',b:'#6bffb0'},{name:'Gold',a:'#ffc23b',b:'#ff8a4b'}
];
let pcbSet={ accentA:'#ff4172', accentB:'#ff2d78', uiSize:100, reduceMotion:false, orbs:false, grid:false, snow:false };
function loadSettings(){ try{ pcbSet=Object.assign(pcbSet,JSON.parse(localStorage.getItem('pcb_settings')||'{}')); }catch(e){} }
function saveSettings(){ try{ localStorage.setItem('pcb_settings',JSON.stringify(pcbSet)); }catch(e){} }
function lighten(hex,amt){ let c=hex.replace('#',''); if(c.length===3)c=c.split('').map(x=>x+x).join(''); let r=parseInt(c.substr(0,2),16),g=parseInt(c.substr(2,2),16),b=parseInt(c.substr(4,2),16); r=Math.min(255,Math.round(r+(255-r)*amt)); g=Math.min(255,Math.round(g+(255-g)*amt)); b=Math.min(255,Math.round(b+(255-b)*amt)); return '#'+[r,g,b].map(x=>x.toString(16).padStart(2,'0')).join(''); }
function boltCursor(color){ const c=color.replace('#','%23'); return "url(\"data:image/svg+xml,%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20width='28'%20height='28'%20viewBox='0%200%2024%2024'%3E%3Cpath%20d='M13%202%203%2014%2010%2014%209%2022%2019%2010%2012%2010Z'%20fill='"+c+"'%20stroke='%23ffffff'%20stroke-width='1.3'%20stroke-linejoin='round'/%3E%3C/svg%3E\") 14 2, auto"; }
function applySettings(){
  const r=document.documentElement.style;
  r.setProperty('--accent',pcbSet.accentA); r.setProperty('--accent2',pcbSet.accentB); r.setProperty('--bolt',boltCursor(pcbSet.accentA));
  document.documentElement.style.zoom=(pcbSet.uiSize/100);
  document.body.classList.toggle('reduce-motion',!!pcbSet.reduceMotion);
  document.body.classList.toggle('bg-grid',!!pcbSet.grid);
  renderOrbs(!!pcbSet.orbs); renderSnow(!!pcbSet.snow);
}
function setAccent(a,b){ pcbSet.accentA=a; pcbSet.accentB=b; saveSettings(); applySettings(); renderSettingsUI(); }
function setAccentCustom(v){ setAccent(v, lighten(v,0.25)); }
function setUiSize(v){ pcbSet.uiSize=parseInt(v)||100; const l=$('ui-size-lbl'); if(l)l.textContent=pcbSet.uiSize+'%'; saveSettings(); applySettings(); }
function toggleSetting(key){ pcbSet[key]=!pcbSet[key]; saveSettings(); applySettings(); renderSettingsUI(); }
function resetSettings(){ pcbSet={ accentA:'#ff4172', accentB:'#ff2d78', uiSize:100, reduceMotion:false, orbs:false, grid:false, snow:false }; saveSettings(); applySettings(); renderSettingsUI(); }
function renderSettingsUI(){
  const sw=$('theme-swatches'); if(sw){ sw.innerHTML=THEMES.map(t=>'<div onclick="setAccent(\''+t.a+'\',\''+t.b+'\')" title="'+t.name+'" style="width:40px;height:40px;border-radius:10px;cursor:pointer;background:linear-gradient(135deg,'+t.a+','+t.b+');border:2px solid '+(pcbSet.accentA.toLowerCase()===t.a?'#fff':'transparent')+'"></div>').join(''); }
  const tc=$('theme-custom'); if(tc)tc.value=pcbSet.accentA;
  const us=$('ui-size'); if(us){ us.value=pcbSet.uiSize; const l=$('ui-size-lbl'); if(l)l.textContent=pcbSet.uiSize+'%'; }
  [['set-motion','reduceMotion'],['set-orbs','orbs'],['set-grid','grid'],['set-snow','snow']].forEach(function(p){ const b=$(p[0]); if(b){ b.textContent=pcbSet[p[1]]?'An':'Aus'; b.className='btn sm '+(pcbSet[p[1]]?'':'ghost'); } });
  renderTA();
}
/* -------- Temperatur-Alarm -------- */
var taState={on:false,cpu:85,gpu:85};
try{ taState=Object.assign(taState,JSON.parse(localStorage.getItem('pcb_tempalarm')||'{}')); }catch(e){}
function taSaveState(){ try{ localStorage.setItem('pcb_tempalarm',JSON.stringify(taState)); }catch(e){} }
function renderTA(){
  const b=$('ta-on'); if(!b) return;
  b.textContent=taState.on?'An':'Aus'; b.className='btn sm '+(taState.on?'':'ghost');
  const c=$('ta-cpu'), g=$('ta-gpu'); if(c){c.value=taState.cpu;$('ta-cpu-lbl').textContent=taState.cpu;} if(g){g.value=taState.gpu;$('ta-gpu-lbl').textContent=taState.gpu;}
}
function taToggle(){ taState.on=!taState.on; taSaveState(); renderTA(); if(!taState.on) taBanner(''); }
function taSet(){ taState.cpu=parseInt($('ta-cpu').value)||85; taState.gpu=parseInt($('ta-gpu').value)||85; $('ta-cpu-lbl').textContent=taState.cpu; $('ta-gpu-lbl').textContent=taState.gpu; taSaveState(); }
function taBanner(msg){
  let el=$('pcb-tempbanner');
  if(!msg){ if(el)el.remove(); return; }
  if(!el){ el=document.createElement('div'); el.id='pcb-tempbanner'; el.style.cssText='position:fixed;top:0;left:0;right:0;z-index:9999;background:linear-gradient(90deg,#de3b28,#ff5b6e);color:#fff;text-align:center;padding:9px 16px;font-weight:700;font-size:14px;box-shadow:0 2px 16px rgba(222,59,40,.5)'; document.body.appendChild(el); }
  el.textContent=msg;
}
function taCheck(cpuTemp,gpuTemp){
  if(!taState.on){ taBanner(''); return; }
  const hot=[];
  if(cpuTemp!=null && cpuTemp>=taState.cpu) hot.push('CPU '+cpuTemp+String.fromCharCode(176)+'C');
  if(gpuTemp!=null && gpuTemp>=taState.gpu) hot.push('GPU '+gpuTemp+String.fromCharCode(176)+'C');
  taBanner(hot.length?(String.fromCharCode(9888)+' Zu heiss: '+hot.join(', ')+' - Belastung reduzieren / Luefter pruefen!'):'');
}
function renderOrbs(on){ let el=$('pcb-orbs'); if(!on){ if(el)el.remove(); return; } if(!el){ el=document.createElement('div'); el.id='pcb-orbs'; el.innerHTML='<span></span><span></span><span></span>'; document.body.appendChild(el); } }
function renderSnow(on){ let el=$('pcb-snow'); if(!on){ if(el)el.remove(); return; } if(!el){ el=document.createElement('div'); el.id='pcb-snow'; for(let i=0;i<50;i++){ const f=document.createElement('span'); f.style.left=(Math.random()*100)+'%'; f.style.animationDuration=(4+Math.random()*6)+'s'; f.style.animationDelay=(-Math.random()*10)+'s'; f.style.opacity=(0.3+Math.random()*0.6); f.style.fontSize=(8+Math.random()*10)+'px'; f.textContent='\u2744'; el.appendChild(f); } document.body.appendChild(el); } }

/* ========== Makro-Studio ========== */
async function mkCreate(){
  const name=$('mk-name').value.trim(), keys=$('mk-keys').value.trim().split(',').filter(k=>k.trim()), delay=$('mk-delay').value, repeat=$('mk-repeat').value, hotkey=$('mk-hotkey').value;
  if(!name||name.length<2){alert('Makro-Name erforderlich'); return;}
  if(!keys.length){alert('Mindestens eine Taste eingeben'); return;}
  $('mk-out').style.display='block';
  try{
    const r=await(await fetch(`/api/run?a=macrocreate&name=${encodeURIComponent(name)}&keys=${encodeURIComponent(keys.join(','))}&delay=${delay}&repeat=${repeat}&hotkey=${hotkey}`,{cache:'no-store'})).json();
    $('mk-out').innerHTML=`<div class="card ${r.ok?'success':'error'}">${r.msg}</div>`;
    if(r.ok){ $('mk-name').value=''; $('mk-keys').value=''; mkRefresh(); }
  }catch(e){ $('mk-out').innerHTML=`<div class="card error">Fehler: ${e.message}</div>`; }
}
async function mkRefresh(){
  try{
    const r=await(await fetch('/api/run?a=macrolist',{cache:'no-store'})).json();
    const list=$('mk-list');
    if(!r.macros||!r.macros.length){ list.innerHTML='<div class="kv"><span>Keine Makros gespeichert</span></div>'; return; }
    list.innerHTML=r.macros.map(m=>`<div class="card"><div style="flex:1"><b>${esc(m.name)}</b><div style="font-size:12px;color:var(--muted)">Tasten: ${m.keys.join(', ')} | ${m.repeat}x wiederholt</div></div><div style="display:flex;gap:6px"><button class="btn sm" onclick="mkExec('${m.id}')">Ausfuehren</button><button class="btn danger sm" onclick="mkDelete('${m.id}')">Loeschen</button></div></div>`).join('');
  }catch(e){ $('mk-list').innerHTML=`<div class="card error">Fehler: ${e.message}</div>`; }
}
async function mkExec(id){
  try{ const r=await(await fetch(`/api/run?a=macroexec&id=${id}`,{cache:'no-store'})).json(); alert(r.msg); }catch(e){ alert('Fehler: '+e.message); }
}
async function mkDelete(id){
  if(!confirm('Makro wirklich loeschen?')) return;
  try{ const r=await(await fetch(`/api/run?a=macrodelete&id=${id}`,{cache:'no-store'})).json(); mkRefresh(); }catch(e){ alert('Fehler: '+e.message); }
}

/* ========== Training-Tool ========== */
async function trainAdd(){
  const path=$('train-path').value.trim();
  if(!path){ alert('Bitte einen Pfad eingeben'); return; }
  $('train-out').style.display='block';
  try{
    const r=await(await fetch(`/api/run?a=trainingadd&path=${encodeURIComponent(path)}`,{cache:'no-store'})).json();
    $('train-out').innerHTML=`<div class="card ${r.ok?'success':'error'}">${r.msg}</div>`;
    if(r.ok){ $('train-path').value=''; trainRefresh(); }
  }catch(e){ $('train-out').innerHTML=`<div class="card error">Fehler: ${e.message}</div>`; }
}
async function trainRefresh(){
  try{
    const r=await(await fetch('/api/run?a=traininglist',{cache:'no-store'})).json();
    const list=$('train-list');
    if(!r.items||!r.items.length){ list.innerHTML='<div class="kv"><span>Keine Dateien hinzugefuegt</span></div>'; $('train-del-btn').style.display='none'; return; }
    $('train-del-btn').style.display='';
    list.innerHTML=r.items.map(item=>`<div class="card" style="display:flex;gap:12px;align-items:center"><input type="checkbox" class="train-cb" value="${item.id}" style="width:20px;height:20px"><div style="flex:1;min-width:0"><b style="word-break:break-all">${esc(item.name)}</b><div style="font-size:12px;color:var(--muted)">${(item.size/1024/1024).toFixed(1)}MB | ${item.added}</div></div></div>`).join('');
  }catch(e){ $('train-list').innerHTML=`<div class="card error">Fehler: ${e.message}</div>`; }
}
async function trainDeleteSelected(){
  const checked=[...document.querySelectorAll('.train-cb:checked')].map(c=>c.value);
  if(!checked.length){ alert('Bitte Dateien auswaehlen'); return; }
  if(!confirm(`${checked.length} Datei(en) wirklich loeschen?`)) return;
  try{
    const r=await(await fetch(`/api/run?a=trainingdelete&ids=${checked.join(',')}`,{cache:'no-store'})).json();
    alert(`Geloescht: ${r.deleted}, Fehler: ${r.failed}`);
    trainRefresh();
  }catch(e){ alert('Fehler: '+e.message); }
}

/* ========== Hardware-ID & System ========== */
async function hwGetID(){
  $('hw-out').style.display='block';
  try{ const r=await(await fetch('/api/run?a=hardwareid',{cache:'no-store'})).json(); $('hw-out').innerHTML=`<div class="card"><b>Hardware-ID:</b><div class="mono">${r.id}</div></div>`; }catch(e){ $('hw-out').innerHTML=`<div class="card error">Fehler: ${e.message}</div>`; }
}
async function hwGetIP(){
  $('hw-out').style.display='block';
  try{ const r=await(await fetch('/api/run?a=publicip',{cache:'no-store'})).json(); $('hw-out').innerHTML=`<div class="card"><b>Oeffentliche IP:</b><div class="mono">${r.ok?r.ip:'Nicht erreichbar'}</div></div>`; }catch(e){ $('hw-out').innerHTML=`<div class="card error">Fehler: ${e.message}</div>`; }
}
async function hwClearCache(){
  $('hw-out').style.display='block';
  try{ const r=await(await fetch('/api/run?a=clearcaches',{cache:'no-store'})).json(); $('hw-out').innerHTML=`<div class="card success">${r.msg}</div>`; }catch(e){ $('hw-out').innerHTML=`<div class="card error">Fehler: ${e.message}</div>`; }
}
async function hwSetID(){
  const newID=$('hw-newid').value.trim();
  if(!newID||newID.length<10){ alert('Bitte eine gueltige Hardware-ID eingeben (min. 10 Zeichen)'); return; }
  if(!confirm('Hardware-ID wirklich aendern? Ein Neustart ist erforderlich!')){ return; }
  $('hw-set-out').style.display='block';
  try{
    const r=await(await fetch(`/api/run?a=sethardwareid&id=${encodeURIComponent(newID)}`,{cache:'no-store'})).json();
    $('hw-set-out').innerHTML=`<div class="card ${r.ok?'success':'error'}">${r.msg}</div>`;
  }catch(e){ $('hw-set-out').innerHTML=`<div class="card error">Fehler: ${e.message}</div>`; }
}

loadSettings(); applySettings();
checkAuth();
</script>
</body>
</html>
'@

# ------------------------------------------------------------
#  Server-Infrastruktur
# ------------------------------------------------------------

# Gemeinsamer Zwischenspeicher (Webserver liefert daraus SOFORT aus).
$shared = [hashtable]::Synchronized(@{
    json    = '{"time":"--"}'
    hwjson  = '{}'
    netjson = '{}'
    actions = [hashtable]::Synchronized(@{})
    codes   = [hashtable]::Synchronized(@{})
    pending = [hashtable]::Synchronized(@{})
    dstate  = [hashtable]::Synchronized(@{})
    currentUser = $null
    watcherOn = $false
    watcherAlerts = @()
    autoScanOn = $false
    autoScanInterval = 6
    autoScanResult = $null
})

# Einstellungen (Waechter/Auto-Scan) ueber Neustarts merken
$settingsFile = Join-Path $scriptDir 'pcboost-settings.json'
function Save-Settings { try { (@{ watcherOn=[bool]$shared.watcherOn; autoScanOn=[bool]$shared.autoScanOn; autoScanInterval=[double]$shared.autoScanInterval } | ConvertTo-Json) | Set-Content -Path $settingsFile -Encoding UTF8 } catch {} }
function Load-Settings { if (Test-Path $settingsFile) { try { $o = Get-Content $settingsFile -Raw | ConvertFrom-Json; $shared.watcherOn=[bool]$o.watcherOn; $shared.autoScanOn=[bool]$o.autoScanOn; if ($o.autoScanInterval) { $shared.autoScanInterval=[double]$o.autoScanInterval } } catch {} } }
Load-Settings

# Sitzung ueber Neustarts merken (fuer "angemeldet bleiben" + korrekten Admin-Status)
$sessionFile = Join-Path $scriptDir 'pcboost-session.json'
function Save-Session {
    try {
        if ($shared.currentUser) { ($shared.currentUser | ConvertTo-Json -Compress) | Set-Content -Path $sessionFile -Encoding UTF8 }
        else { Remove-Item $sessionFile -Force -ErrorAction SilentlyContinue }
    } catch {}
}
function Load-Session {
    if (Test-Path $sessionFile) {
        try { $o = Get-Content $sessionFile -Raw | ConvertFrom-Json
            if ($o.id) { $shared.currentUser = @{ id = "$($o.id)"; name = "$($o.name)"; admin = [bool](Test-IsAdmin $o.id); loginTime = "$($o.loginTime)" } }
        } catch {}
    }
}
Load-Session

# VirusTotal-API-Key beim Start laden (Pool-Aktionen lesen ihn via $env)
$vtConfigFile = Join-Path $scriptDir 'pcboost-virustotal.txt'
if (Test-Path $vtConfigFile) {
    foreach ($ln in (Get-Content $vtConfigFile)) {
        if ($ln -match '^\s*api_key\s*=\s*(.+)$') { $vk = $matches[1].Trim(); if ($vk -and $vk -notmatch 'HIER-') { $env:PCBOOST_VTKEY = $vk } }
    }
}

Write-Host ""
Write-Host "  Starte PC Boost, waerme Sensoren auf ..." -ForegroundColor DarkGray
try { $shared.json    = (Get-Stats        | ConvertTo-Json -Depth 5 -Compress) } catch {}
try { $shared.hwjson  = (Get-HardwareInfo | ConvertTo-Json -Depth 5 -Compress) } catch {}
try { $shared.netjson = (Get-NetworkInfo  | ConvertTo-Json -Depth 5 -Compress) } catch {}

# --- Hintergrund-Sammler (eigener Thread, entkoppelt vom Webserver) ---
$getStatsBody = (Get-Item function:Get-Stats).ScriptBlock.ToString()
$getNetBody   = (Get-Item function:Get-NetworkInfo).ScriptBlock.ToString()
$collectorScript = {
    param($shared, $getStatsBody, $getNetBody, $libDir)
    $ErrorActionPreference = 'SilentlyContinue'
    Set-Item function:Get-Stats       -Value ([ScriptBlock]::Create($getStatsBody))
    Set-Item function:Get-NetworkInfo -Value ([ScriptBlock]::Create($getNetBody))

    # LibreHardwareMonitor laden (echte CPU-/GPU-Temperaturen)
    $hwmon = $null
    try {
        $core = Join-Path $libDir 'LibreHardwareMonitorLib.dll'
        $hid  = Join-Path $libDir 'HidSharp.dll'
        if (Test-Path $core) {
            [System.Reflection.Assembly]::LoadFrom($hid)  | Out-Null
            [System.Reflection.Assembly]::LoadFrom($core) | Out-Null
            $hwmon = New-Object LibreHardwareMonitor.Hardware.Computer
            $hwmon.IsCpuEnabled = $true
            $hwmon.IsGpuEnabled = $true
            $hwmon.Open()
        }
    } catch { $hwmon = $null }

    $n = 0
    while ($true) {
        $global:cpuTempLHM = $null
        $global:gpuTempLHM = $null
        $global:gpuHotspotLHM = $null
        if ($hwmon) {
            try {
                foreach ($hw in $hwmon.Hardware) {
                    $ht = $hw.HardwareType.ToString()
                    if ($ht -eq 'Cpu') {
                        $hw.Update()
                        $temps = @($hw.Sensors | Where-Object { $_.SensorType.ToString() -eq 'Temperature' -and $null -ne $_.Value })
                        $sel = $temps | Where-Object { $_.Name -match 'Package|Tctl|Tdie' } | Select-Object -First 1
                        if (-not $sel) { $sel = $temps | Where-Object { $_.Name -match 'Average' } | Select-Object -First 1 }
                        if (-not $sel) { $sel = $temps | Sort-Object { [double]$_.Value } -Descending | Select-Object -First 1 }
                        if ($sel -and $sel.Value -gt 0) { $global:cpuTempLHM = [math]::Round([double]$sel.Value, 0) }
                    }
                    elseif ($ht -like 'Gpu*') {
                        $hw.Update()
                        $g = $hw.Sensors | Where-Object { $_.SensorType.ToString() -eq 'Temperature' -and $_.Name -match 'GPU Core' -and $null -ne $_.Value } | Select-Object -First 1
                        if ($g -and $g.Value -gt 0) { $global:gpuTempLHM = [math]::Round([double]$g.Value, 0) }
                        $hs = $hw.Sensors | Where-Object { $_.SensorType.ToString() -eq 'Temperature' -and $_.Name -match 'Hot Spot' -and $null -ne $_.Value } | Select-Object -First 1
                        if ($hs -and $hs.Value -gt 0) { $global:gpuHotspotLHM = [math]::Round([double]$hs.Value, 0) }
                    }
                }
            } catch {}
        }
        try { $shared.json = (Get-Stats | ConvertTo-Json -Depth 5 -Compress) } catch {}
        if ($n % 12 -eq 0) { try { $shared.netjson = (Get-NetworkInfo | ConvertTo-Json -Depth 5 -Compress) } catch {} }

        # Langzeit-Verlauf: eine kompakte CSV-Zeile pro Minute.
        # Format: Minute-seit-1970, CPU%, RAM%, GPU%, CPU-Temp, GPU-Temp  (-1 = kein Wert)
        if ($shared.histFile -and ($n % 200) -eq 0) {
            try {
                $o = $shared.json | ConvertFrom-Json
                $min = [int][math]::Floor(((Get-Date).ToUniversalTime() - [datetime]'1970-01-01').TotalMinutes)
                $gl = if ($null -ne $o.gpuLoad) { [int]$o.gpuLoad } else { -1 }
                $ct = if ($null -ne $o.cpuTemp) { [int]$o.cpuTemp } else { -1 }
                $gt = if ($null -ne $o.gpuTemp) { [int]$o.gpuTemp } else { -1 }
                Add-Content -Path $shared.histFile -Value "$min,$([int]$o.cpuLoad),$([int]$o.ramPct),$gl,$ct,$gt" -Encoding UTF8 -ErrorAction SilentlyContinue
            } catch {}
        }
        # Etwa alle 10 Minuten alles aelter als 7 Tage wegschneiden
        if ($shared.histFile -and ($n % 2000) -eq 0) {
            try {
                if (Test-Path $shared.histFile) {
                    $z = @(Get-Content $shared.histFile -ErrorAction SilentlyContinue)
                    if ($z.Count -gt 11000) { $z[($z.Count - 10080)..($z.Count - 1)] | Set-Content -Path $shared.histFile -Encoding UTF8 }
                }
            } catch {}
        }
        $n++
        Start-Sleep -Milliseconds 300
    }
}
# Pfad fuer den Langzeit-Verlauf an den Sammler durchreichen
$histFile = Join-Path $scriptDir 'pcboost-verlauf.csv'
$shared.histFile = $histFile

$collectorRs = [runspacefactory]::CreateRunspace([initialsessionstate]::CreateDefault())
$collectorRs.Open()
$collector = [powershell]::Create()
$collector.Runspace = $collectorRs
[void]$collector.AddScript($collectorScript).AddArgument($shared).AddArgument($getStatsBody).AddArgument($getNetBody).AddArgument($libDir)
[void]$collector.BeginInvoke()

# --- Aktions-Pool (langsame Aktionen laufen im Hintergrund, blockieren nie) ---
# Ohne $Host erstellen (funktioniert auch als Fenster-App ohne Konsole).
$actionPool = [runspacefactory]::CreateRunspacePool([initialsessionstate]::CreateDefault())
[void]$actionPool.SetMinRunspaces(1)
[void]$actionPool.SetMaxRunspaces(3)
$actionPool.Open()
$script:actId = 0

# Benannte Hintergrund-Aktionen
$ACT = @{
    'latenz' = {
        $res = [ordered]@{}
        foreach ($h in @(@{n='Google DNS';ip='8.8.8.8'}, @{n='Cloudflare';ip='1.1.1.1'}, @{n='Quad9';ip='9.9.9.9'})) {
            $p = Test-Connection -ComputerName $h.ip -Count 4 -ErrorAction SilentlyContinue
            if ($p) { $res[$h.n] = [math]::Round(($p | Measure-Object ResponseTime -Average).Average, 1) } else { $res[$h.n] = $null }
        }
        $res | ConvertTo-Json -Compress
    }
    'flushdns'     = { (ipconfig /flushdns | Out-String).Trim() }
    'renewip'      = { ((ipconfig /release | Out-String) + "`r`n" + (ipconfig /renew | Out-String)).Trim() }
    'pingtest'     = { (Test-Connection -ComputerName 8.8.8.8 -Count 4 | Format-Table -AutoSize | Out-String).Trim() }
    'dnsget' = {
        try {
            $c = Get-NetIPConfiguration -ErrorAction Stop | Where-Object { $_.IPv4DefaultGateway } | Select-Object -First 1
            if (-not $c) { return (@{ adapter = $null; dns = @() } | ConvertTo-Json -Compress) }
            $d = Get-DnsClientServerAddress -InterfaceIndex $c.InterfaceIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue
            $servers = @(); if ($d) { $servers = @($d.ServerAddresses) }
            @{ adapter = "$($c.InterfaceAlias)"; dns = $servers } | ConvertTo-Json -Compress
        } catch { @{ adapter = $null; dns = @(); error = $_.Exception.Message } | ConvertTo-Json -Compress }
    }
    'dnsset' = {
        param($cfg)
        $o = try { $cfg | ConvertFrom-Json } catch { $null }
        if (-not $o) { return 'Ungueltige Eingabe.' }
        $presets = @{
            cloudflare = @('1.1.1.1', '1.0.0.1')
            google     = @('8.8.8.8', '8.8.4.4')
            quad9      = @('9.9.9.9', '149.112.112.112')
            opendns    = @('208.67.222.222', '208.67.220.220')
        }
        try {
            $c = Get-NetIPConfiguration -ErrorAction Stop | Where-Object { $_.IPv4DefaultGateway } | Select-Object -First 1
            if (-not $c) { return 'Kein aktiver Netzwerkadapter gefunden.' }
            $idx = $c.InterfaceIndex; $alias = "$($c.InterfaceAlias)"
            if ("$($o.preset)" -eq 'auto') {
                Set-DnsClientServerAddress -InterfaceIndex $idx -ResetServerAddresses -ErrorAction Stop
                Clear-DnsClientCache -ErrorAction SilentlyContinue
                return "DNS von '$alias' auf automatisch (DHCP) zurueckgesetzt."
            }
            $srv = $presets[[string]$o.preset]
            if (-not $srv) { return 'Unbekanntes DNS-Preset.' }
            Set-DnsClientServerAddress -InterfaceIndex $idx -ServerAddresses $srv -ErrorAction Stop
            Clear-DnsClientCache -ErrorAction SilentlyContinue
            "DNS von '$alias' auf $($srv -join ', ') gesetzt. (DNS-Cache geleert)"
        } catch { 'Fehler: ' + $_.Exception.Message + ' - Adminrechte noetig.' }
    }
    'wifikeys' = {
        $tmp = Join-Path $env:TEMP ('pcbwifi_' + [guid]::NewGuid().ToString('N'))
        $res = @()
        try {
            [void][System.IO.Directory]::CreateDirectory($tmp)
            netsh wlan export profile key=clear folder="$tmp" | Out-Null
            foreach ($f in (Get-ChildItem $tmp -Filter *.xml -ErrorAction SilentlyContinue)) {
                try {
                    [xml]$x = Get-Content $f.FullName -Raw -ErrorAction Stop
                    $name = "$($x.WLANProfile.name)"
                    $key  = "$($x.WLANProfile.MSM.security.sharedKey.keyMaterial)"
                    $auth = "$($x.WLANProfile.MSM.security.authEncryption.authentication)"
                    $res += [ordered]@{ name = $name; key = $key; auth = $auth }
                } catch {}
            }
        } catch {}
        try { Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue } catch {}
        $res = @($res | Sort-Object { $_.name })
        (@{ count = $res.Count; nets = $res } | ConvertTo-Json -Compress)
    }
    'sysreport' = {
        $L = @()
        try {
            $os  = Get-CimInstance Win32_OperatingSystem
            $cs  = Get-CimInstance Win32_ComputerSystem
            $cpu = Get-CimInstance Win32_Processor | Select-Object -First 1
            $bb  = Get-CimInstance Win32_BaseBoard
            $mem = @(Get-CimInstance Win32_PhysicalMemory)
            $ramGB = if ($mem.Count) { [math]::Round((($mem | Measure-Object Capacity -Sum).Sum)/1GB,0) } else { 0 }
            $gpu = @(Get-CimInstance Win32_VideoController | Where-Object { $_.Name -notmatch 'Basic|Remote|Meta|Parsec|Virtual' })
            $up  = (Get-Date) - $os.LastBootUpTime
            $L += 'PC BOOST - SYSTEMBERICHT'
            $L += ('Erstellt am: ' + (Get-Date).ToString('dd.MM.yyyy HH:mm'))
            $L += ('=' * 44)
            $L += ''
            $L += ('PC-Modell:      ' + ("$($cs.Manufacturer) $($cs.Model)").Trim())
            $L += ('Mainboard:      ' + ("$($bb.Manufacturer) $($bb.Product)").Trim())
            $L += ('Betriebssystem: ' + "$($os.Caption)" + ' (Build ' + "$($os.BuildNumber)" + ')')
            $L += ('Laufzeit:       ' + [int]$up.TotalHours + ' h ' + $up.Minutes + ' min')
            $L += ''
            $L += ('Prozessor:      ' + ("$($cpu.Name)").Trim())
            $L += ('  Kerne/Threads:' + " $($cpu.NumberOfCores) / $($cpu.NumberOfLogicalProcessors)")
            $L += ('  Max-Takt:     ' + [math]::Round($cpu.MaxClockSpeed/1000,1) + ' GHz')
            $L += ('Arbeitsspeicher:' + " $ramGB GB")
            foreach ($m in $mem) { $L += ('  Modul:        ' + [math]::Round($m.Capacity/1GB,0) + ' GB @ ' + $m.Speed + ' MHz ' + ("$($m.Manufacturer)").Trim()) }
            foreach ($g in $gpu) { $L += ('Grafikkarte:    ' + ("$($g.Name)").Trim() + ' (Treiber ' + "$($g.DriverVersion)" + ')') }
            $L += ''
            $L += 'Laufwerke:'
            foreach ($d in (Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' | Where-Object { $_.Size -gt 0 })) {
                $tot=[math]::Round($d.Size/1GB,0); $free=[math]::Round($d.FreeSpace/1GB,0)
                $L += ('  ' + "$($d.DeviceID)" + '  ' + $free + ' GB frei von ' + $tot + ' GB')
            }
        } catch { $L += ('Fehler beim Sammeln: ' + $_.Exception.Message) }
        $text = ($L -join "`r`n")
        $path = ''
        try {
            $dir = Join-Path $env:USERPROFILE 'Desktop\PC-Boost'
            [void][System.IO.Directory]::CreateDirectory($dir)
            $path = Join-Path $dir 'systembericht.txt'
            [System.IO.File]::WriteAllText($path, $text, (New-Object System.Text.UTF8Encoding($false)))
        } catch { $path = '' }
        (@{ text = $text; path = $path } | ConvertTo-Json -Compress)
    }
    'proglist' = {
        $keys = @(
            'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
            'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*',
            'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*'
        )
        $seen = @{}; $apps = @()
        foreach ($k in $keys) {
            foreach ($e in (Get-ItemProperty $k -ErrorAction SilentlyContinue)) {
                $name = "$($e.DisplayName)"
                if (-not $name) { continue }
                if ($e.SystemComponent -eq 1) { continue }
                if ($e.ReleaseType -match 'Update|Hotfix|Security Update') { continue }
                if ($name -match '^(KB[0-9]{6,}|Update for|Security Update|Hotfix)') { continue }
                $un = "$($e.QuietUninstallString)"; if (-not $un) { $un = "$($e.UninstallString)" }
                if (-not $un) { continue }
                $key = $name.ToLower()
                if ($seen.ContainsKey($key)) { continue }
                $seen[$key] = $true
                $mb = $null; if ($e.EstimatedSize) { $mb = [math]::Round([double]$e.EstimatedSize/1024,1) }
                $apps += [ordered]@{ name = $name; pub = "$($e.Publisher)"; ver = "$($e.DisplayVersion)"; sizeMB = $mb; uninstall = $un }
            }
        }
        $apps = @($apps | Sort-Object { $_.name })
        (@{ count = $apps.Count; apps = $apps } | ConvertTo-Json -Compress)
    }
    'uninstall' = {
        param($cmd)
        if (-not $cmd) { return 'Kein Deinstallations-Befehl.' }
        try {
            if ($cmd -match '(?i)msiexec') {
                $args = ($cmd -replace '(?i)msiexec(\.exe)?\s*', '') -replace '/I', '/X'
                Start-Process 'msiexec.exe' -ArgumentList $args -ErrorAction Stop
            } else {
                Start-Process 'cmd.exe' -ArgumentList '/c', $cmd -ErrorAction Stop
            }
            'Deinstallation gestartet - folge dem Fenster des Programms. Danach die Liste aktualisieren.'
        } catch { 'Fehler: ' + $_.Exception.Message }
    }
    'eventlog' = {
        $out = @()
        $since = (Get-Date).AddDays(-7)
        foreach ($lg in @('System','Application')) {
            try {
                $evts = Get-WinEvent -FilterHashtable @{ LogName = $lg; Level = 1,2; StartTime = $since } -MaxEvents 40 -ErrorAction SilentlyContinue
                foreach ($ev in $evts) {
                    $msg = "$($ev.Message)"; if ($msg.Length -gt 300) { $msg = $msg.Substring(0,300) + '...' }
                    $msg = $msg -replace '\s+', ' '
                    $out += [ordered]@{
                        time = $ev.TimeCreated.ToString('dd.MM. HH:mm')
                        tick = $ev.TimeCreated.Ticks
                        lvl  = [int]$ev.Level
                        src  = "$($ev.ProviderName)"
                        id   = [int]$ev.Id
                        log  = $lg
                        msg  = $msg.Trim()
                    }
                }
            } catch {}
        }
        $out = @($out | Sort-Object { $_.tick } -Descending | Select-Object -First 40)
        (@{ count = $out.Count; events = $out } | ConvertTo-Json -Compress)
    }
    'drivers' = {
        $want = 'Display|VGA|nvidia|AMD|Radeon|GeForce|Intel.*Graphics|Net|Ethernet|Wi-?Fi|Wireless|WLAN|Realtek|Audio|Sound|High Definition|Storage|NVMe|SATA|Disk'
        $res = @()
        try {
            $drv = Get-CimInstance Win32_PnPSignedDriver -ErrorAction Stop | Where-Object {
                $_.DeviceName -and ("$($_.DeviceClass)" -match 'DISPLAY|NET|MEDIA|HDC|SCSIADAPTER|DISKDRIVE' -or "$($_.DeviceName)" -match $want)
            }
            $seen = @{}
            foreach ($d in $drv) {
                $nm = "$($d.DeviceName)"; if (-not $nm -or $seen.ContainsKey($nm)) { continue }
                $seen[$nm] = $true
                $dt = $null; $ageY = $null
                try { if ($d.DriverDate) { $dd = [Management.ManagementDateTimeConverter]::ToDateTime($d.DriverDate); $dt = $dd.ToString('dd.MM.yyyy'); $ageY = [math]::Round(((Get-Date) - $dd).TotalDays/365,1) } } catch {}
                $res += [ordered]@{ name = $nm; ver = "$($d.DriverVersion)"; date = $dt; ageY = $ageY; cls = "$($d.DeviceClass)" }
            }
        } catch {}
        $res = @($res | Sort-Object { $_.ageY } -Descending | Select-Object -First 40)
        (@{ count = $res.Count; drivers = $res } | ConvertTo-Json -Compress)
    }
    'overlay' = {
        param($cfgJson)
        $flag   = Join-Path $env:TEMP 'pcboost-overlay-off'
        $onflag = Join-Path $env:TEMP 'pcboost-overlay-on'
        $cfgFile = Join-Path $env:TEMP 'pcboost-overlay-cfg.json'
        $o = $null; try { if ($cfgJson) { $o = $cfgJson | ConvertFrom-Json } } catch {}
        if ($o -and "$($o.mode)" -eq 'off') {
            New-Item -ItemType File -Path $flag -Force | Out-Null
            Remove-Item $onflag -Force -ErrorAction SilentlyContinue
            return 'Overlay wird geschlossen.'
        }
        # Config fuer den Overlay-Prozess ablegen (er liest sie live -> Aenderungen sofort sichtbar)
        try { if ($cfgJson) { [System.IO.File]::WriteAllText($cfgFile, $cfgJson) } } catch {}
        Remove-Item $flag -Force -ErrorAction SilentlyContinue
        if (Test-Path $onflag) { return 'Overlay aktualisiert.' }
        New-Item -ItemType File -Path $onflag -Force | Out-Null
        $port = $env:PCBOOST_PORT; if (-not $port) { $port = '8777' }
        $formSb = {
            param($port)
            Add-Type -AssemblyName System.Windows.Forms
            Add-Type -AssemblyName System.Drawing
            $flag = Join-Path $env:TEMP 'pcboost-overlay-off'
            $cfgFile = Join-Path $env:TEMP 'pcboost-overlay-cfg.json'
            # hist = Messwert-Verlauf je Zeile fuer die Sparkline (wie Xbox Game Bar)
            $S = @{ cfg = $null; rows = @(); title = 'PC BOOST'; disp = @{}; pulseT = 0.0; hist = @{}; histMax = 46 }
            $readCfg = {
                $c = $null; try { if (Test-Path $cfgFile) { $c = Get-Content $cfgFile -Raw | ConvertFrom-Json } } catch {}
                if (-not $c) { $c = [pscustomobject]@{} }
                $c
            }
            $S.cfg = & $readCfg
            $hex2col = {
                param($h, $def)
                try { $h = "$h".TrimStart('#'); [System.Drawing.Color]::FromArgb([Convert]::ToInt32($h.Substring(0,2),16), [Convert]::ToInt32($h.Substring(2,2),16), [Convert]::ToInt32($h.Substring(4,2),16)) }
                catch { $def }
            }
            $f = New-Object System.Windows.Forms.Form
            $f.FormBorderStyle = 'None'; $f.TopMost = $true; $f.ShowInTaskbar = $false
            $f.StartPosition = 'Manual'
            $f.BackColor = [System.Drawing.Color]::FromArgb(8,7,11)
            try {
                $mi = [System.Windows.Forms.Control].GetMethod('SetStyle', [System.Reflection.BindingFlags]'Instance,NonPublic')
                $mi.Invoke($f, @([System.Windows.Forms.ControlStyles]'OptimizedDoubleBuffer, AllPaintingInWmPaint, UserPaint', $true))
            } catch {}
            $applyLayout = {
                $c = $S.cfg
                $scale = 1.0; try { if ($c.scale) { $scale = [double]$c.scale / 100.0 } } catch {}
                if ($scale -lt 0.6) { $scale = 0.6 }; if ($scale -gt 2.0) { $scale = 2.0 }
                $op = 0.85; try { if ($c.opacity) { $op = [double]$c.opacity / 100.0 } } catch {}
                if ($op -lt 0.2) { $op = 0.2 }; if ($op -gt 1.0) { $op = 1.0 }
                $f.Opacity = $op
                # Graph-Modus (Standard an) braucht hoehere Zeilen - wie bei Xbox Game Bar
                $graphOn = $true; try { if ($null -ne $c.graph) { $graphOn = [bool]$c.graph } } catch {}
                $rowH = if ($graphOn) { [int](37 * $scale) } else { [int](24 * $scale) }
                $w = [int](238 * $scale); $top = [int](32 * $scale)
                $nrows = $S.rows.Count; if ($nrows -lt 1) { $nrows = 1 }
                $h = $top + $nrows * $rowH + [int](10 * $scale)
                $f.Size = New-Object System.Drawing.Size($w, $h)
                $wa = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
                $m = [int](24 * $scale); $pos = "$($c.pos)"; if (-not $pos) { $pos = 'tl' }
                switch ($pos) {
                    'tr' { $f.Location = New-Object System.Drawing.Point(($wa.Right - $w - $m), ($wa.Top + $m)) }
                    'bl' { $f.Location = New-Object System.Drawing.Point(($wa.Left + $m), ($wa.Bottom - $h - $m)) }
                    'br' { $f.Location = New-Object System.Drawing.Point(($wa.Right - $w - $m), ($wa.Bottom - $h - $m)) }
                    default { $f.Location = New-Object System.Drawing.Point(($wa.Left + $m), ($wa.Top + $m)) }
                }
                try {
                    $gp = New-Object System.Drawing.Drawing2D.GraphicsPath
                    $r = [int](14 * $scale)
                    $gp.AddArc(0,0,$r,$r,180,90); $gp.AddArc($w-$r,0,$r,$r,270,90); $gp.AddArc($w-$r,$h-$r,$r,$r,0,90); $gp.AddArc(0,$h-$r,$r,$r,90,90); $gp.CloseAllFigures()
                    $f.Region = New-Object System.Drawing.Region($gp)
                } catch {}
            }
            # --- GDI-Objekte werden zwischengespeichert ---
            # Vorher entstanden bei jedem Neuzeichnen (30x pro Sekunde) neue Fonts
            # und Brushes, die nie freigegeben wurden. Das sind unmanaged
            # GDI-Handles, und Windows erlaubt davon nur rund 10.000 je Prozess.
            $S.gdi = @{ key=''; fTitle=$null; fLbl=$null; fVal=$null; fSub=$null; bg=$null; brushes=@{}; pens=@{}; fills=@{}; pen=$null }
            $getBrush = {
                param($hex)
                $k = "$hex"
                if (-not $S.gdi.brushes.ContainsKey($k)) {
                    $S.gdi.brushes[$k] = New-Object System.Drawing.SolidBrush (& $hex2col $k ([System.Drawing.Color]::White))
                }
                $S.gdi.brushes[$k]
            }
            # Linie fuer die Sparkline - ebenfalls zwischengespeichert
            $getPen = {
                param($hex, $wid)
                $k = "$hex|$wid"
                if (-not $S.gdi.pens.ContainsKey($k)) {
                    $S.gdi.pens[$k] = New-Object System.Drawing.Pen ((& $hex2col $hex ([System.Drawing.Color]::White)), [single]$wid)
                }
                $S.gdi.pens[$k]
            }
            # halbtransparente Fuellung unter der Sparkline
            $getFill = {
                param($hex)
                $k = "$hex"
                if (-not $S.gdi.fills.ContainsKey($k)) {
                    $c0 = & $hex2col $k ([System.Drawing.Color]::White)
                    $S.gdi.fills[$k] = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(70, $c0.R, $c0.G, $c0.B))
                }
                $S.gdi.fills[$k]
            }
            $ensureGdi = {
                param($scale, $W, $H)
                $key = "$scale|$W|$H"
                if ($S.gdi.key -eq $key) { return }
                foreach ($o in @($S.gdi.fTitle, $S.gdi.fLbl, $S.gdi.fVal, $S.gdi.fSub, $S.gdi.bg, $S.gdi.pen)) {
                    if ($o) { try { $o.Dispose() } catch {} }
                }
                $S.gdi.fTitle = New-Object System.Drawing.Font('Segoe UI', (10*$scale), [System.Drawing.FontStyle]::Bold)
                $S.gdi.fLbl   = New-Object System.Drawing.Font('Segoe UI Semibold', (8.5*$scale))
                # Consolas: gleiche Zeichenbreite, dadurch springen die Zahlen nicht
                $S.gdi.fVal   = New-Object System.Drawing.Font('Consolas', (10.5*$scale), [System.Drawing.FontStyle]::Bold)
                $S.gdi.fSub   = New-Object System.Drawing.Font('Consolas', (8*$scale))
                try {
                    $S.gdi.bg = New-Object System.Drawing.Drawing2D.LinearGradientBrush(
                        (New-Object System.Drawing.Point(0,0)),
                        (New-Object System.Drawing.Point(0,[int]$H)),
                        [System.Drawing.Color]::FromArgb(22,20,29),
                        [System.Drawing.Color]::FromArgb(10,9,13))
                } catch { $S.gdi.bg = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(12,11,15)) }
                $S.gdi.pen = New-Object System.Drawing.Pen ([System.Drawing.Color]::FromArgb(38,255,255,255)), 1
                $S.gdi.key = $key
            }

            $f.Add_Paint({
                param($sender,$e)
                $c = $S.cfg
                $scale = 1.0; try { if ($c.scale) { $scale = [double]$c.scale / 100.0 } } catch {}
                if ($scale -lt 0.6) { $scale = 0.6 }; if ($scale -gt 2.0) { $scale = 2.0 }
                $accHex = "$($c.accent)"; if (-not $accHex) { $accHex = 'ff4172' }
                $graphOn = $true; try { if ($null -ne $c.graph) { $graphOn = [bool]$c.graph } } catch {}
                $g = $e.Graphics
                $g.SmoothingMode = 'AntiAlias'; $g.TextRenderingHint = 'ClearTypeGridFit'
                $W = $f.ClientSize.Width; $H = $f.ClientSize.Height
                & $ensureGdi $scale $W $H

                $accBrush = & $getBrush $accHex
                $grey     = & $getBrush '9a96a4'
                $barBg    = & $getBrush '26242e'
                $glow     = & $getBrush '3a3648'

                # Hintergrund mit Verlauf statt flacher Flaeche
                $g.FillRectangle($S.gdi.bg, 0, 0, $W, $H)
                # Akzent-Kopfbalken
                $g.FillRectangle($accBrush, 0, 0, $W, [int](3*$scale))
                # feiner Rahmen - hebt das Overlay von hellen Spielszenen ab
                $g.DrawRectangle($S.gdi.pen, 0, 0, $W-1, $H-1)

                $pad = [int](12*$scale)
                $g.DrawString($S.title, $S.gdi.fTitle, $accBrush, [single]$pad, [single]([int](7*$scale)))

                # pulsierender Punkt rechts oben - zeigt, dass die Werte live sind
                $ps = [int](6*$scale); if ($ps -lt 4) { $ps = 4 }
                $phase = [math]::Abs([math]::Sin($S.pulseT))
                $pcol = [System.Drawing.Color]::FromArgb([int](90 + 165*$phase), 53, 224, 161)
                $pb = New-Object System.Drawing.SolidBrush $pcol
                $g.FillEllipse($pb, ($W - $pad - $ps), [int](11*$scale), $ps, $ps)
                $pb.Dispose()

                # Muss exakt zu applyLayout passen, sonst ueberlappen die Zeilen
                $y = [int](32*$scale)
                $rowH = if ($graphOn) { [int](37*$scale) } else { [int](24*$scale) }
                foreach ($row in $S.rows) {
                    $rcBrush = & $getBrush ($row.color)
                    $g.DrawString($row.label, $S.gdi.fLbl, $grey, [single]$pad, [single]($y + [int](1*$scale)))
                    # Hauptwert rechtsbuendig, feste Spalte durch Monospace-Schrift
                    $vsz = $g.MeasureString($row.val, $S.gdi.fVal)
                    $vx  = $W - $pad - $vsz.Width
                    $g.DrawString($row.val, $S.gdi.fVal, $rcBrush, [single]$vx, [single]$y)
                    # Temperatur direkt links daneben - kleiner und gedaempft (wie RTSS)
                    if ($row.sub) {
                        $ssz = $g.MeasureString($row.sub, $S.gdi.fSub)
                        $g.DrawString($row.sub, $S.gdi.fSub, $grey, [single]($vx - $ssz.Width - [int](7*$scale)), [single]($y + [int](4*$scale)))
                    }
                    if ($row.bar -ge 0 -and $graphOn) {
                        # Verlaufsgraph statt flachem Balken - Vorbild Xbox Game Bar
                        $gx = $pad; $gy = $y + [int](15*$scale); $gw = $W - 2*$pad; $gh = [int](18*$scale)
                        if ($gh -lt 8) { $gh = 8 }
                        $g.FillRectangle($barBg, $gx, $gy, $gw, $gh)
                        $hs = $null; if ($S.hist.ContainsKey($row.label)) { $hs = $S.hist[$row.label] }
                        $n = 0; if ($hs) { $n = $hs.Count }
                        if ($n -ge 2) {
                            $step = [double]$gw / [double]([math]::Max(1, $S.histMax - 1))
                            $x0 = $gx + ($S.histMax - $n) * $step
                            $pts = New-Object 'System.Collections.Generic.List[System.Drawing.Point]'
                            for ($k = 0; $k -lt $n; $k++) {
                                $vv = [math]::Min(100, [math]::Max(0, [double]$hs[$k]))
                                $px = [int]($x0 + $k * $step)
                                $py = [int]($gy + $gh - ($vv / 100.0) * ($gh - 1))
                                $pts.Add((New-Object System.Drawing.Point($px, $py)))
                            }
                            # Flaeche unter der Kurve
                            $poly = New-Object 'System.Collections.Generic.List[System.Drawing.Point]'
                            $poly.Add((New-Object System.Drawing.Point($pts[0].X, ($gy + $gh))))
                            $poly.AddRange($pts)
                            $poly.Add((New-Object System.Drawing.Point($pts[$n-1].X, ($gy + $gh))))
                            try { $g.FillPolygon((& $getFill ($row.color)), $poly.ToArray()) } catch {}
                            try { $g.DrawLines((& $getPen ($row.color) ([math]::Max(1.0, 1.4*$scale))), $pts.ToArray()) } catch {}
                            # Punkt auf dem aktuellen Wert
                            $ds = [int](2.5*$scale); if ($ds -lt 2) { $ds = 2 }
                            $lp = $pts[$n-1]
                            $g.FillEllipse($rcBrush, ($lp.X - $ds), ($lp.Y - $ds), ($ds*2), ($ds*2))
                        }
                    }
                    elseif ($row.bar -ge 0) {
                        # Kompaktmodus (graph=false): schmaler Balken wie bisher
                        $bx = $pad; $by = $y + [int](17*$scale); $bw = $W - 2*$pad; $bh = [int](5*$scale)
                        if ($bh -lt 3) { $bh = 3 }
                        $g.FillRectangle($barBg, $bx, $by, $bw, $bh)
                        $shown = $row.bar; if ($S.disp.ContainsKey($row.label)) { $shown = $S.disp[$row.label] }
                        $fillW = [int]($bw * ([math]::Min(100,[math]::Max(0,$shown)) / 100.0))
                        if ($fillW -gt 0) {
                            $g.FillRectangle($rcBrush, $bx, $by, $fillW, $bh)
                            $g.FillRectangle($glow, $bx, $by, $fillW, [int]([math]::Max(1, $bh/2)))
                            $g.FillRectangle($rcBrush, $bx, ($by + [int]($bh/2)), $fillW, ($bh - [int]($bh/2)))
                        }
                    }
                    $y += $rowH
                }
            })
            $f.Add_FormClosed({
                # Zwischengespeicherte GDI-Objekte sauber freigeben
                foreach ($o in @($S.gdi.fTitle, $S.gdi.fLbl, $S.gdi.fVal, $S.gdi.fSub, $S.gdi.bg, $S.gdi.pen)) { if ($o) { try { $o.Dispose() } catch {} } }
                foreach ($b in $S.gdi.brushes.Values) { if ($b) { try { $b.Dispose() } catch {} } }
                foreach ($p in $S.gdi.pens.Values)    { if ($p) { try { $p.Dispose() } catch {} } }
                foreach ($fl in $S.gdi.fills.Values)  { if ($fl) { try { $fl.Dispose() } catch {} } }
            })
            # Verschiebbar
            $st = @{ drag = $false; dx = 0; dy = 0 }
            $f.Add_MouseDown({ $st.drag = $true; $st.dx = [System.Windows.Forms.Cursor]::Position.X - $f.Left; $st.dy = [System.Windows.Forms.Cursor]::Position.Y - $f.Top })
            $f.Add_MouseUp({ $st.drag = $false })
            $f.Add_MouseMove({ if ($st.drag) { $f.Left = [System.Windows.Forms.Cursor]::Position.X - $st.dx; $f.Top = [System.Windows.Forms.Cursor]::Position.Y - $st.dy } })
            $loadCol = { param($v) if ($v -lt 50) { '35e0a1' } elseif ($v -lt 80) { 'ffd24b' } else { 'ff5b6e' } }
            $tempCol = { param($v) if ($v -lt 60) { '35e0a1' } elseif ($v -lt 80) { 'ffd24b' } else { 'ff5b6e' } }
            $activeFile = "$env:TEMP\pcboost-input-active"
            $fetch = {
                try {
                    $wc = New-Object System.Net.WebClient; $wc.Proxy = $null
                    $j = $wc.DownloadString("http://localhost:$port/api/stats") | ConvertFrom-Json
                    $c = $S.cfg; $mt = $c.metrics
                    $rows = @()
                    $show = { param($key, $def) if ($null -eq $mt) { return $def }; $v = $mt.$key; if ($null -eq $v) { return $def }; [bool]$v }
                    # Auslastung und Temperatur teilen sich eine Zeile (wie RTSS / Xbox Game Bar).
                    # Ist nur die Temperatur eingeschaltet, bekommt sie eine eigene Zeile.
                    $cpuOn = & $show 'cpu' $true; $cpuTOn = & $show 'cpuTemp' $true
                    if ($cpuOn) {
                        $sub = ''
                        if ($cpuTOn -and $null -ne $j.cpuTemp) { $sub = "$([int]$j.cpuTemp)C" }
                        $rows += @{ label='CPU'; val="$([int]$j.cpuLoad)%"; sub=$sub; bar=[int]$j.cpuLoad; color=(& $loadCol ([int]$j.cpuLoad)) }
                    }
                    elseif ($cpuTOn) {
                        $ct = if ($null -ne $j.cpuTemp) { "$([int]$j.cpuTemp)C" } else { 'n/a' }
                        $cc = if ($null -ne $j.cpuTemp) { & $tempCol ([int]$j.cpuTemp) } else { '8a8a94' }
                        $rows += @{ label='CPU Temp'; val=$ct; bar=-1; color=$cc }
                    }
                    $gpuOn = & $show 'gpu' $true; $gpuTOn = & $show 'gpuTemp' $true
                    if ($gpuOn) {
                        $gl = if ($null -ne $j.gpuLoad) { "$([int]$j.gpuLoad)%" } else { 'n/a' }
                        $gb = if ($null -ne $j.gpuLoad) { [int]$j.gpuLoad } else { -1 }
                        $gc = if ($null -ne $j.gpuLoad) { & $loadCol ([int]$j.gpuLoad) } else { '8a8a94' }
                        $sub = ''
                        if ($gpuTOn -and $null -ne $j.gpuTemp) { $sub = "$([int]$j.gpuTemp)C" }
                        $rows += @{ label='GPU'; val=$gl; sub=$sub; bar=$gb; color=$gc }
                    }
                    elseif ($gpuTOn) {
                        $gt = if ($null -ne $j.gpuTemp) { "$([int]$j.gpuTemp)C" } else { 'n/a' }
                        $gtc = if ($null -ne $j.gpuTemp) { & $tempCol ([int]$j.gpuTemp) } else { '8a8a94' }
                        $rows += @{ label='GPU Temp'; val=$gt; bar=-1; color=$gtc }
                    }
                    if (& $show 'gpuClock' $false) { $gk = if ($null -ne $j.gpuClock) { "$($j.gpuClock) MHz" } else { 'n/a' }; $rows += @{ label='GPU Takt'; val=$gk; bar=-1; color='c9c9d2' } }
                    if (& $show 'gpuPower' $false) { $gw = if ($null -ne $j.gpuPower) { "$($j.gpuPower) W" } else { 'n/a' }; $rows += @{ label='GPU Watt'; val=$gw; bar=-1; color='c9c9d2' } }
                    if (& $show 'vram'    $false) { $vv = if ($null -ne $j.gpuMemUsed) { "$($j.gpuMemUsed)/$($j.gpuMemTot)G" } else { 'n/a' }; $rows += @{ label='VRAM'; val=$vv; bar=-1; color='c9c9d2' } }
                    if (& $show 'ram'     $true)  { $rows += @{ label='RAM'; val="$([int]$j.ramPct)%"; bar=[int]$j.ramPct; color=(& $loadCol ([int]$j.ramPct)) } }
                    if (& $show 'net'     $false) { $rows += @{ label='Netz'; val="$($j.rxRate)/$($j.txRate)"; bar=-1; color='2bb3fb' } }
                    if (& $show 'clock'   $false) { $rows += @{ label='Uhrzeit'; val="$($j.time)"; bar=-1; color='c9c9d2' } }
                    if (& $show 'input'   $false) {
                        $ia = $null; try { if (Test-Path $activeFile) { $ia = (Get-Content $activeFile -Raw).Trim() } } catch {}
                        if ($ia) { $rows += @{ label='Automatik'; val="$ia AKTIV"; bar=-1; color='35e0a1' } }
                        else     { $rows += @{ label='Automatik'; val='aus'; bar=-1; color='8a8a94' } }
                    }
                    if ($rows.Count -eq 0) { $rows += @{ label='CPU'; val="$($j.cpuLoad)%"; bar=[int]$j.cpuLoad; color=(& $loadCol ([int]$j.cpuLoad)) } }
                    $prevCount = $S.rows.Count
                    $S.rows = $rows
                    if ($rows.Count -ne $prevCount) { & $applyLayout }
                } catch {}
            }
            # Der Zaehler MUSS in der Hashtable liegen. Ein einfaches $tick++ im
            # Event-Handler legt nur eine lokale Kopie an - der Wert bliebe ewig 1.
            # Dadurch lief bisher der Stats-Abruf 30x pro Sekunde statt einmal,
            # und die Einstellungen wurden nie nachgeladen.
            $S.tick = 0
            $timer = New-Object System.Windows.Forms.Timer
            $timer.Interval = 33   # ~30 FPS fuer fluessige Balken-Animation
            $timer.Add_Tick({
                if (Test-Path $flag) { $timer.Stop(); $f.Close(); return }
                $S.tick++
                if ($S.tick % 90 -eq 0) { $S.cfg = & $readCfg; & $applyLayout }   # Config ~alle 3s
                if ($S.tick % 30 -eq 1) { & $fetch }                              # Daten ~1x/s
                # Phase fuer den pulsierenden Live-Punkt (~1 Zyklus alle 2s)
                $S.pulseT = $S.pulseT + 0.05
                if ($S.pulseT -gt 6.283185) { $S.pulseT = $S.pulseT - 6.283185 }
                # weiche Annaeherung der Balken an den Zielwert
                foreach ($row in $S.rows) {
                    if ($row.bar -ge 0) {
                        $cur = $row.bar; if ($S.disp.ContainsKey($row.label)) { $cur = $S.disp[$row.label] }
                        $S.disp[$row.label] = $cur + ($row.bar - $cur) * 0.25
                    }
                }
                # Verlauf fuer die Sparkline mitschreiben (~3 Werte je Sekunde)
                if ($S.tick % 10 -eq 0) {
                    foreach ($row in $S.rows) {
                        if ($row.bar -ge 0) {
                            $k = $row.label
                            $v = $row.bar; if ($S.disp.ContainsKey($k)) { $v = $S.disp[$k] }
                            if (-not $S.hist.ContainsKey($k)) {
                                # Mit dem aktuellen Wert vorbelegen, damit der Graph sofort
                                # ueber die volle Breite laeuft - so macht es der Task-Manager.
                                $S.hist[$k] = New-Object System.Collections.ArrayList
                                for ($q = 0; $q -lt $S.histMax; $q++) { [void]$S.hist[$k].Add([double]$v) }
                            }
                            [void]$S.hist[$k].Add([double]$v)
                            while ($S.hist[$k].Count -gt $S.histMax) { $S.hist[$k].RemoveAt(0) }
                        }
                    }
                }
                $f.Invalidate()
            })
            & $fetch
            & $applyLayout
            $timer.Start()
            [System.Windows.Forms.Application]::Run($f)
            Remove-Item (Join-Path $env:TEMP 'pcboost-overlay-on') -Force -ErrorAction SilentlyContinue
        }
        try {
            $rs = [runspacefactory]::CreateRunspace(); $rs.ApartmentState = 'STA'; $rs.ThreadOptions = 'ReuseThread'; $rs.Open()
            $ps = [powershell]::Create(); $ps.Runspace = $rs
            [void]$ps.AddScript($formSb.ToString()).AddArgument($port)
            [void]$ps.BeginInvoke()
            'Overlay gestartet - bleibt immer im Vordergrund (auch ueber Spielen im randlosen Fenstermodus). Mit der Maus verschiebbar.'
        } catch {
            Remove-Item $onflag -Force -ErrorAction SilentlyContinue
            'Fehler beim Starten des Overlays: ' + $_.Exception.Message
        }
    }
    'restorepoint' = {
        try {
            Enable-ComputerRestore -Drive "C:\" -ErrorAction SilentlyContinue
            Checkpoint-Computer -Description "PC Boost" -RestorePointType "MODIFY_SETTINGS" -ErrorAction Stop
            "Wiederherstellungspunkt 'PC Boost' erfolgreich erstellt."
        } catch {
            "Fehler: " + $_.Exception.Message + "`r`nTipp: Systemschutz muss fuer C: aktiviert sein und PC Boost als Admin laufen."
        }
    }
    'gamingstart' = {
        $rep = @()
        $ap = powercfg /getactivescheme
        if ($ap -match '([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})') {
            Set-Content -Path "$env:TEMP\pcboost-plan.txt" -Value $Matches[1] -Force
        }
        powercfg /setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c | Out-Null
        $rep += "Energieplan: Hoechstleistung aktiviert"
        $killList = 'Discord','DiscordCanary','Spotify','EpicGamesLauncher','Slack','Teams','ms-teams','OneDrive','Dropbox','Skype','GoogleDriveFS'
        $closed = @()
        foreach ($n in $killList) { $p = Get-Process -Name $n -ErrorAction SilentlyContinue; if ($p) { $p | Stop-Process -Force -ErrorAction SilentlyContinue; $closed += $n } }
        if ($closed.Count) { $rep += ("Beendet: " + ($closed -join ', ')) } else { $rep += "Keine Hintergrund-Apps zum Beenden gefunden." }
        $rep += "Viel Spass beim Zocken! (Session beenden stellt den Energieplan wieder her.)"
        $rep -join "`r`n"
    }
    'gamingstop' = {
        $rep = @()
        $pf = "$env:TEMP\pcboost-plan.txt"
        if (Test-Path $pf) {
            $g = (Get-Content $pf -Raw).Trim()
            if ($g) { powercfg /setactive $g | Out-Null; $rep += "Energieplan wiederhergestellt." }
            Remove-Item $pf -Force -ErrorAction SilentlyContinue
        } else {
            powercfg /setactive 381b4222-f694-41f0-9685-ff5bb260df2e | Out-Null
            $rep += "Energieplan auf 'Ausbalanciert' gesetzt."
        }
        $rep += "Geschlossene Apps kannst du normal wieder starten."
        $rep -join "`r`n"
    }
    'removeapp' = {
        param($pkg)
        if (-not $pkg) { return 'Kein Paket angegeben.' }
        try {
            $p = Get-AppxPackage -Name $pkg -ErrorAction SilentlyContinue
            if (-not $p) { return "$pkg ist nicht (mehr) installiert." }
            $p | Remove-AppxPackage -ErrorAction Stop
            "'$pkg' wurde entfernt. (Bei Bedarf im Microsoft Store neu installierbar.)"
        } catch { "Fehler bei '$pkg': " + $_.Exception.Message }
    }
    'cleantemp' = {
        $count = 0
        foreach ($base in @($env:TEMP, "$env:WINDIR\Temp")) {
            if (Test-Path $base) {
                Get-ChildItem -Path $base -Force -ErrorAction SilentlyContinue | ForEach-Object {
                    try { Remove-Item $_.FullName -Recurse -Force -ErrorAction Stop; $count++ } catch {}
                }
            }
        }
        "Temp-Ordner bereinigt: $count Elemente entfernt (in Benutzung befindliche Dateien wurden uebersprungen)."
    }
    'emptybin' = {
        try { Clear-RecycleBin -Force -ErrorAction Stop; "Papierkorb geleert." }
        catch { "Papierkorb war bereits leer oder nicht zugaenglich." }
    }
    'deepclean' = {
        $freed = 0.0; $rep = @()
        $targets = @(
            @{ n='Temp (Nutzer)';     p=$env:TEMP },
            @{ n='Temp (Windows)';    p="$env:WINDIR\Temp" },
            @{ n='Prefetch';          p="$env:WINDIR\Prefetch" },
            @{ n='Update-Downloads';  p="$env:WINDIR\SoftwareDistribution\Download" },
            @{ n='Absturzberichte';   p="$env:LOCALAPPDATA\CrashDumps" }
        )
        foreach ($t in $targets) {
            if ($t.p -and (Test-Path $t.p)) {
                $before = 0.0
                Get-ChildItem $t.p -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object { if (-not $_.PSIsContainer) { $before += $_.Length } }
                Get-ChildItem $t.p -Force -ErrorAction SilentlyContinue | ForEach-Object { try { Remove-Item $_.FullName -Recurse -Force -ErrorAction Stop } catch {} }
                $after = 0.0
                Get-ChildItem $t.p -Recurse -Force -ErrorAction SilentlyContinue | ForEach-Object { if (-not $_.PSIsContainer) { $after += $_.Length } }
                $mb = [math]::Round(($before - $after)/1MB, 1); if ($mb -lt 0) { $mb = 0 }
                $freed += $mb; $rep += ("{0}: {1} MB" -f $t.n, $mb)
            }
        }
        # Thumbnail-Cache
        $tc = "$env:LOCALAPPDATA\Microsoft\Windows\Explorer"
        if (Test-Path $tc) { Get-ChildItem $tc -Filter 'thumbcache_*.db' -ErrorAction SilentlyContinue | ForEach-Object { try { Remove-Item $_.FullName -Force -ErrorAction Stop } catch {} }; $rep += 'Thumbnail-Cache geleert' }
        try { Clear-RecycleBin -Force -ErrorAction Stop; $rep += 'Papierkorb geleert' } catch {}
        ipconfig /flushdns | Out-Null; $rep += 'DNS-Cache geleert'
        ("Fertig - rund {0} MB freigegeben.`r`n`r`n{1}" -f [math]::Round($freed,1), ($rep -join "`r`n"))
    }
    'privreset' = {
        $rep = @()
        $recent = "$env:APPDATA\Microsoft\Windows\Recent"
        if (Test-Path $recent) {
            Get-ChildItem $recent -Force -ErrorAction SilentlyContinue | ForEach-Object { try { Remove-Item $_.FullName -Recurse -Force -ErrorAction Stop } catch {} }
            $rep += "Zuletzt-verwendet-Liste geleert"
        }
        ipconfig /flushdns | Out-Null
        $rep += "DNS-Cache geleert"
        $tc = "$env:LOCALAPPDATA\Microsoft\Windows\Explorer"
        if (Test-Path $tc) {
            Get-ChildItem $tc -Filter 'thumbcache_*.db' -ErrorAction SilentlyContinue | ForEach-Object { try { Remove-Item $_.FullName -Force -ErrorAction Stop } catch {} }
            $rep += "Thumbnail-Cache geleert (soweit nicht in Benutzung)"
        }
        ($rep -join "`r`n")
    }
    'runcmd' = {
        param($c)
        if (-not $c) { return 'Kein Befehl.' }
        try { (cmd /c $c 2>&1 | Out-String).Trim() } catch { $_.Exception.Message }
    }
    'autoclick' = {
        param($cfg)
        $flag = "$env:TEMP\pcboost-stopinput"
        Remove-Item $flag -Force -ErrorAction SilentlyContinue
        try { $c = $cfg | ConvertFrom-Json } catch { return 'Ungueltige Konfiguration.' }
        $interval = [int]$c.interval; if ($interval -lt 1) { $interval = 1 }
        $rand = [int]$c.randomOffset; if ($rand -lt 0) { $rand = 0 }
        $limit = [int]$c.limit
        $delay = [int]$c.delay
        $btn = "$($c.button)"
        $dbl = [bool]$c.doubleClick
        $useFixed = ($null -ne $c.posX -and "$($c.posX)" -ne '')
        $px = [int]$c.posX; $py = [int]$c.posY
        $rng = New-Object System.Random
        $active = "$env:TEMP\pcboost-input-active"; Set-Content -Path $active -Value 'Auto-Klicker' -Force
        if ($delay -gt 0) { Start-Sleep -Milliseconds $delay }
        $n = 0
        while ($true) {
            if (Test-Path $flag) { break }
            if ($limit -gt 0 -and $n -ge $limit) { break }
            if ($useFixed) { [PCBoostInput]::MoveTo($px, $py) }
            switch ($btn) {
                'right'  { [PCBoostInput]::RightClick(); if ($dbl) { [PCBoostInput]::RightClick() } }
                'middle' { [PCBoostInput]::MiddleClick(); if ($dbl) { [PCBoostInput]::MiddleClick() } }
                default  { [PCBoostInput]::LeftClick(); if ($dbl) { [PCBoostInput]::LeftClick() } }
            }
            $n++
            $wait = $interval
            if ($rand -gt 0) { $wait = $interval + $rng.Next(-$rand, $rand + 1); if ($wait -lt 1) { $wait = 1 } }
            Start-Sleep -Milliseconds $wait
        }
        Remove-Item $flag -Force -ErrorAction SilentlyContinue
        Remove-Item "$env:TEMP\pcboost-input-active" -Force -ErrorAction SilentlyContinue
        "Auto-Klicker beendet. $n Klicks ausgefuehrt."
    }
    'pickpos' = {
        param($delay)
        $d = 3; [void][int]::TryParse("$delay", [ref]$d); if ($d -lt 0) { $d = 0 }; if ($d -gt 10) { $d = 10 }
        Start-Sleep -Seconds $d
        $r = [PCBoostInput]::PickColor() -split ','
        @{ x = [int]$r[3]; y = [int]$r[4] } | ConvertTo-Json -Compress
    }
    'keyrepeat' = {
        param($cfg)
        $flag = "$env:TEMP\pcboost-stopinput"
        Remove-Item $flag -Force -ErrorAction SilentlyContinue
        try { $c = $cfg | ConvertFrom-Json } catch { return 'Ungueltige Konfiguration.' }
        $vk = [byte]([int]$c.vk)
        $interval = [int]$c.interval; if ($interval -lt 10) { $interval = 10 }
        $limit = [int]$c.limit
        $delay = [int]$c.delay
        $active = "$env:TEMP\pcboost-input-active"; Set-Content -Path $active -Value 'Tasten-Wiederholer' -Force
        if ($delay -gt 0) { Start-Sleep -Milliseconds $delay }
        $n = 0
        while ($true) {
            if (Test-Path $flag) { break }
            if ($limit -gt 0 -and $n -ge $limit) { break }
            [PCBoostInput]::KeyPress($vk)
            $n++
            Start-Sleep -Milliseconds $interval
        }
        Remove-Item $flag -Force -ErrorAction SilentlyContinue
        Remove-Item $active -Force -ErrorAction SilentlyContinue
        "Tasten-Wiederholer beendet. $n Tastendruecke."
    }
    'macro' = {
        param($cfg)
        $flag = "$env:TEMP\pcboost-stopinput"
        Remove-Item $flag -Force -ErrorAction SilentlyContinue
        try { $c = $cfg | ConvertFrom-Json } catch { return 'Ungueltige Konfiguration.' }
        $steps = @($c.steps)
        if ($steps.Count -eq 0) { return 'Kein Makro definiert - fuege zuerst Schritte hinzu.' }
        $loops = [int]$c.loops            # 0 = unbegrenzt
        $startDelay = [int]$c.startDelay
        $active = "$env:TEMP\pcboost-input-active"; Set-Content -Path $active -Value 'Makro' -Force
        if ($startDelay -gt 0) { Start-Sleep -Milliseconds $startDelay }
        $done = 0
        while ($true) {
            if (Test-Path $flag) { break }
            if ($loops -gt 0 -and $done -ge $loops) { break }
            foreach ($s in $steps) {
                if (Test-Path $flag) { break }
                if ($s.type -eq 'click') {
                    if ($s.button -eq 'right') { [PCBoostInput]::RightClick() } else { [PCBoostInput]::LeftClick() }
                } else {
                    [PCBoostInput]::KeyPress([byte]([int]$s.vk))
                }
                $d = [int]$s.delay; if ($d -lt 0) { $d = 0 }
                if ($d -gt 0) { Start-Sleep -Milliseconds $d }
            }
            $done++
        }
        Remove-Item $flag -Force -ErrorAction SilentlyContinue
        Remove-Item $active -Force -ErrorAction SilentlyContinue
        "Makro beendet. $done Durchlaeufe abgespielt."
    }
    'armmacro' = {
        param($cfg)
        $off = "$env:TEMP\pcboost-macroarm-off"
        Remove-Item $off -Force -ErrorAction SilentlyContinue
        try { $c = $cfg | ConvertFrom-Json } catch { return 'Ungueltige Konfiguration.' }
        $vk = [int]$c.vk
        $steps = @($c.steps)
        if ($steps.Count -eq 0) { return 'Kein Makro definiert.' }
        $prev = $false; $plays = 0
        $active = "$env:TEMP\pcboost-input-active"; Set-Content -Path $active -Value 'Makro-Hotkey' -Force
        while (-not (Test-Path $off)) {
            $down = [PCBoostInput]::IsDown($vk)
            if ($down -and -not $prev) {
                foreach ($s in $steps) {
                    if ($s.type -eq 'click') { if ($s.button -eq 'right') { [PCBoostInput]::RightClick() } else { [PCBoostInput]::LeftClick() } }
                    else { [PCBoostInput]::KeyPress([byte]([int]$s.vk)) }
                    $d = [int]$s.delay; if ($d -gt 0) { Start-Sleep -Milliseconds $d }
                }
                $plays++
            }
            $prev = $down
            Start-Sleep -Milliseconds 25
        }
        Remove-Item $off -Force -ErrorAction SilentlyContinue
        Remove-Item $active -Force -ErrorAction SilentlyContinue
        "Hotkey deaktiviert. Makro wurde $plays mal per Hotkey ausgeloest."
    }
    'defupdate' = {
        try { Update-MpSignature -ErrorAction Stop; "Virensignaturen aktualisiert." }
        catch { "Update nicht moeglich: " + $_.Exception.Message }
    }
    'gpupinfo' = {
        $res = @{ supported = $false; cur = $null; min = $null; max = $null; default = $null; name = '' }
        try {
            $psi = New-Object System.Diagnostics.ProcessStartInfo
            $psi.FileName = 'nvidia-smi'
            $psi.Arguments = '--query-gpu=name,power.limit,power.min_limit,power.max_limit,power.default_limit --format=csv,noheader,nounits'
            $psi.UseShellExecute = $false; $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true; $psi.CreateNoWindow = $true
            $pr = [System.Diagnostics.Process]::Start($psi)
            $out = ''; if ($pr.WaitForExit(4000)) { $out = $pr.StandardOutput.ReadToEnd() } else { try { $pr.Kill() } catch {} }
            if ($out) {
                $c = ($out -split "`n" | Select-Object -First 1).Split(',')
                $res.name = $c[0].Trim()
                if ($c[1].Trim() -match '^\d') { $res.cur = [math]::Round([double]$c[1].Trim()) }
                if ($c[2].Trim() -match '^\d') { $res.min = [math]::Round([double]$c[2].Trim()) }
                if ($c[3].Trim() -match '^\d') { $res.max = [math]::Round([double]$c[3].Trim()) }
                if ($c[4].Trim() -match '^\d') { $res.default = [math]::Round([double]$c[4].Trim()) }
                if ($null -ne $res.min -and $null -ne $res.max -and $res.max -gt $res.min) { $res.supported = $true }
            }
        } catch {}
        $res | ConvertTo-Json -Compress
    }
    'gpupl' = {
        param($watts)
        function Query-Pl { $psi = New-Object System.Diagnostics.ProcessStartInfo; $psi.FileName='nvidia-smi'; $psi.Arguments='--query-gpu=power.min_limit,power.max_limit,power.default_limit --format=csv,noheader,nounits'; $psi.UseShellExecute=$false; $psi.RedirectStandardOutput=$true; $psi.RedirectStandardError=$true; $psi.CreateNoWindow=$true; $p=[System.Diagnostics.Process]::Start($psi); $o=''; if($p.WaitForExit(3000)){$o=$p.StandardOutput.ReadToEnd()}; return $o }
        $w = 0; if (-not [int]::TryParse("$watts", [ref]$w)) { return 'Ungueltiger Wert.' }
        $q = Query-Pl; if (-not $q) { return 'Keine NVIDIA-GPU gefunden (nvidia-smi nicht verfuegbar).' }
        $r = ($q -split "`n" | Select-Object -First 1).Split(','); $min=[math]::Round([double]$r[0].Trim()); $max=[math]::Round([double]$r[1].Trim())
        if ($w -lt $min) { $w = $min }; if ($w -gt $max) { $w = $max }
        $psi = New-Object System.Diagnostics.ProcessStartInfo; $psi.FileName='nvidia-smi'; $psi.Arguments="-pl $w"; $psi.UseShellExecute=$false; $psi.RedirectStandardOutput=$true; $psi.RedirectStandardError=$true; $psi.CreateNoWindow=$true
        $p2=[System.Diagnostics.Process]::Start($psi); $so=''; $se=''; if($p2.WaitForExit(5000)){ $so=$p2.StandardOutput.ReadToEnd(); $se=$p2.StandardError.ReadToEnd() }
        if ($p2.ExitCode -eq 0 -and $so -match 'set to') { "GPU-Power-Limit auf $w W gesetzt (erlaubt: $min-$max W). Umkehrbar per 'Zuruecksetzen'." }
        elseif ($se -match 'Insufficient Permissions|admin|privilege') { 'Fehlgeschlagen: Adminrechte noetig. Starte PC-Boost.exe als Administrator.' }
        else { "Nicht moeglich: " + (($so + ' ' + $se).Trim()) }
    }
    'gpuplreset' = {
        $psi = New-Object System.Diagnostics.ProcessStartInfo; $psi.FileName='nvidia-smi'; $psi.Arguments='--query-gpu=power.default_limit --format=csv,noheader,nounits'; $psi.UseShellExecute=$false; $psi.RedirectStandardOutput=$true; $psi.RedirectStandardError=$true; $psi.CreateNoWindow=$true
        $p=[System.Diagnostics.Process]::Start($psi); $o=''; if($p.WaitForExit(3000)){$o=$p.StandardOutput.ReadToEnd()}
        if (-not $o) { return 'Keine NVIDIA-GPU gefunden.' }
        $def = [math]::Round([double]($o.Trim()))
        $psi2 = New-Object System.Diagnostics.ProcessStartInfo; $psi2.FileName='nvidia-smi'; $psi2.Arguments="-pl $def"; $psi2.UseShellExecute=$false; $psi2.RedirectStandardOutput=$true; $psi2.RedirectStandardError=$true; $psi2.CreateNoWindow=$true
        $p2=[System.Diagnostics.Process]::Start($psi2); $so=''; $se=''; if($p2.WaitForExit(5000)){ $so=$p2.StandardOutput.ReadToEnd(); $se=$p2.StandardError.ReadToEnd() }
        if ($p2.ExitCode -eq 0) { "GPU auf Werks-Power-Limit ($def W) zurueckgesetzt." }
        elseif ($se -match 'Insufficient Permissions|admin|privilege') { 'Fehlgeschlagen: Adminrechte noetig.' }
        else { "Nicht moeglich: " + (($so + ' ' + $se).Trim()) }
    }
    'gpuocinfo' = {
        function nvq($a) { $psi = New-Object System.Diagnostics.ProcessStartInfo; $psi.FileName = 'nvidia-smi'; $psi.Arguments = $a; $psi.UseShellExecute = $false; $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true; $psi.CreateNoWindow = $true; $p = [System.Diagnostics.Process]::Start($psi); $o = ''; if ($p.WaitForExit(4000)) { $o = $p.StandardOutput.ReadToEnd() }; return $o }
        $res = @{ supported = $false }
        try {
            $o = nvq '--query-gpu=name,clocks.gr,clocks.max.gr,clocks.mem,clocks.max.mem,power.limit,power.min_limit,power.max_limit,power.default_limit --format=csv,noheader,nounits'
            if ($o) {
                $c = ($o -split "`n" | Select-Object -First 1).Split(',')
                $res.name = $c[0].Trim(); $res.curGr = [int]$c[1].Trim(); $res.maxGr = [int]$c[2].Trim(); $res.curMem = [int]$c[3].Trim(); $res.maxMem = [int]$c[4].Trim()
                $res.plCur = [math]::Round([double]$c[5].Trim()); $res.plMin = [math]::Round([double]$c[6].Trim()); $res.plMax = [math]::Round([double]$c[7].Trim()); $res.plDef = [math]::Round([double]$c[8].Trim())
                if ($res.maxGr -gt 0) { $res.supported = $true }
            }
        } catch {}
        $res | ConvertTo-Json -Compress
    }
    'gpuoc' = {
        param($cfg)
        try { $c = $cfg | ConvertFrom-Json } catch { return 'Ungueltige Konfiguration.' }
        function nvset($a) { $psi = New-Object System.Diagnostics.ProcessStartInfo; $psi.FileName = 'nvidia-smi'; $psi.Arguments = $a; $psi.UseShellExecute = $false; $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true; $psi.CreateNoWindow = $true; $p = [System.Diagnostics.Process]::Start($psi); $so = ''; $se = ''; if ($p.WaitForExit(6000)) { $so = $p.StandardOutput.ReadToEnd(); $se = $p.StandardError.ReadToEnd() }; return @{ code = $p.ExitCode; out = ($so + ' ' + $se).Trim() } }
        $done = @(); $adminFail = $false
        if ($c.powerMax -and [int]$c.powerMaxW -gt 0) { $r = nvset "-pl $([int]$c.powerMaxW)"; if ($r.code -eq 0) { $done += "Power-Limit $([int]$c.powerMaxW) W" } elseif ($r.out -match 'permission|privilege|Insufficient') { $adminFail = $true } }
        if ([int]$c.gclock -gt 0) { $g = [int]$c.gclock; $r = nvset "-lgc $g,$g"; if ($r.code -eq 0) { $done += "GPU-Takt auf $g MHz gesperrt" } elseif ($r.out -match 'permission|privilege|Insufficient') { $adminFail = $true } else { $done += ("GPU-Takt nicht moeglich: " + $r.out) } }
        if ([int]$c.mclock -gt 0) { $m = [int]$c.mclock; $r = nvset "-lmc $m,$m"; if ($r.code -eq 0) { $done += "Speichertakt auf $m MHz gesperrt" } elseif ($r.out -match 'permission|privilege|Insufficient') { $adminFail = $true } elseif ($r.out) { $done += 'Speichertakt-Sperre nicht unterstuetzt' } }
        if ($adminFail) { return 'Fehlgeschlagen: Adminrechte noetig. Starte PC-Boost als Administrator.' }
        if (-not $done.Count) { return 'Nichts angewendet.' }
        'UNSICHER angewendet: ' + ($done -join ', ') + '. Bei Abstuerzen/Grafikfehlern: "Zuruecksetzen" + Neustart.'
    }
    'gpuocreset' = {
        function nvset($a) { $psi = New-Object System.Diagnostics.ProcessStartInfo; $psi.FileName = 'nvidia-smi'; $psi.Arguments = $a; $psi.UseShellExecute = $false; $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true; $psi.CreateNoWindow = $true; $p = [System.Diagnostics.Process]::Start($psi); $so = ''; $se = ''; if ($p.WaitForExit(6000)) { $so = $p.StandardOutput.ReadToEnd(); $se = $p.StandardError.ReadToEnd() }; return @{ code = $p.ExitCode; out = ($so + ' ' + $se).Trim() } }
        $r1 = nvset '-rgc'; nvset '-rmc' | Out-Null
        $psi = New-Object System.Diagnostics.ProcessStartInfo; $psi.FileName = 'nvidia-smi'; $psi.Arguments = '--query-gpu=power.default_limit --format=csv,noheader,nounits'; $psi.UseShellExecute = $false; $psi.RedirectStandardOutput = $true; $psi.CreateNoWindow = $true; $p = [System.Diagnostics.Process]::Start($psi); $o = ''; if ($p.WaitForExit(3000)) { $o = $p.StandardOutput.ReadToEnd() }; if ($o.Trim() -match '^\d') { nvset "-pl $([math]::Round([double]$o.Trim()))" | Out-Null }
        if ($r1.out -match 'permission|privilege|Insufficient') { 'Fehlgeschlagen: Adminrechte noetig.' } else { 'GPU auf Werkseinstellung zurueckgesetzt (Takt + Speichertakt + Power-Limit).' }
    }
    'refreshinfo' = {
        try { $r = [PCBoostInput]::GetRefresh() -split '\|'; @{ cur = [int]$r[0]; max = [int]$r[1]; w = [int]$r[2]; h = [int]$r[3] } | ConvertTo-Json -Compress } catch { '{"cur":0,"max":0}' }
    }
    'setrefresh' = {
        param($hz)
        $h = 0; [void][int]::TryParse("$hz", [ref]$h); if ($h -lt 24 -or $h -gt 500) { return 'Ungueltige Hz-Zahl.' }
        try { $c = [PCBoostInput]::SetRefresh($h); if ($c -eq 0) { "Bildschirm-Aktualisierungsrate auf $h Hz gesetzt." } else { "Nicht moeglich (Code $c) - der Monitor unterstuetzt diese Rate bei der aktuellen Aufloesung evtl. nicht." } } catch { 'Fehler: ' + $_.Exception.Message }
    }
    'healthscan' = {
        function chk($label, $status, $detail, $fix, $page) { @{ label = $label; status = $status; detail = $detail; fix = $fix; page = $page } }
        $checks = @()
        # 1) Windows Defender
        try {
            $mp = Get-MpComputerStatus -ErrorAction Stop
            if ($mp.RealTimeProtectionEnabled) { $checks += chk 'Echtzeit-Virenschutz' 'ok' 'Aktiv.' '' '' }
            else { $checks += chk 'Echtzeit-Virenschutz' 'bad' 'Ausgeschaltet - in den Windows-Einstellungen einschalten.' '' '' }
            $sa = [int]$mp.AntivirusSignatureAge
            if ($sa -le 3) { $checks += chk 'Virensignaturen' 'ok' "Aktuell ($sa Tage alt)." '' '' }
            else { $checks += chk 'Virensignaturen' 'warn' "$sa Tage alt - aktualisieren." 'defupdate' '' }
        } catch { $checks += chk 'Virenschutz' 'warn' 'Status nicht lesbar (Adminrechte noetig).' '' '' }
        # 2) Freier Speicher C:
        try {
            $dv = Get-PSDrive C -ErrorAction Stop
            $free = [double]$dv.Free; $tot = [double]($dv.Free + $dv.Used); $pct = if ($tot) { [math]::Round($free / $tot * 100) } else { 0 }; $fg = [math]::Round($free / 1GB, 1)
            if ($pct -ge 15) { $checks += chk 'Freier Speicher (C:)' 'ok' "$fg GB frei ($pct%)." '' '' }
            elseif ($pct -ge 8) { $checks += chk 'Freier Speicher (C:)' 'warn' "Nur $fg GB frei ($pct%) - aufraeumen." '' 'cleanup' }
            else { $checks += chk 'Freier Speicher (C:)' 'bad' "Kritisch: $fg GB frei ($pct%)." '' 'cleanup' }
        } catch {}
        # 3) Temp-Dateien
        try {
            $paths = @($env:TEMP, "$env:WINDIR\Temp") | Select-Object -Unique
            $sz = 0; foreach ($p in $paths) { if ($p -and (Test-Path $p)) { $sz += [double]((Get-ChildItem $p -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object -Sum Length).Sum) } }
            $gb = [math]::Round($sz / 1GB, 2)
            if ($gb -lt 1) { $checks += chk 'Temp-Dateien' 'ok' "$gb GB - wenig Ballast." '' '' }
            elseif ($gb -lt 3) { $checks += chk 'Temp-Dateien' 'warn' "$gb GB - koennen geleert werden." 'cleantemp' 'cleanup' }
            else { $checks += chk 'Temp-Dateien' 'bad' "$gb GB - viel Ballast." 'cleantemp' 'cleanup' }
        } catch {}
        # 4) Neustart ausstehend
        $pending = $false
        if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending') { $pending = $true }
        if (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired') { $pending = $true }
        if ($pending) { $checks += chk 'Windows-Neustart' 'warn' 'Ein Neustart steht aus (Updates abschliessen).' '' '' }
        else { $checks += chk 'Windows-Neustart' 'ok' 'Kein Neustart noetig.' '' '' }
        # 5) Autostart-Programme
        try {
            $rk = @('HKCU:\Software\Microsoft\Windows\CurrentVersion\Run', 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Run')
            $n = 0; foreach ($k in $rk) { if (Test-Path $k) { $n += @((Get-Item $k).Property).Count } }
            if ($n -le 6) { $checks += chk 'Autostart-Programme' 'ok' "$n Eintraege." '' '' }
            else { $checks += chk 'Autostart-Programme' 'warn' "$n Eintraege - ausduennen beschleunigt den Start." '' 'cleanup' }
        } catch {}
        # 6) Wiederherstellungspunkt
        try {
            $rp = @(Get-ComputerRestorePoint -ErrorAction Stop)
            if ($rp.Count -gt 0) { $checks += chk 'Wiederherstellungspunkt' 'ok' "$($rp.Count) vorhanden." '' '' }
            else { $checks += chk 'Wiederherstellungspunkt' 'warn' 'Keiner vorhanden - vor Tweaks anlegen.' 'restorepoint' 'backup' }
        } catch { $checks += chk 'Wiederherstellungspunkt' 'warn' 'Systemschutz fuer C: evtl. aus.' '' 'backup' }
        # Score
        $score = 100
        foreach ($c in $checks) { if ($c.status -eq 'bad') { $score -= 20 } elseif ($c.status -eq 'warn') { $score -= 8 } }
        if ($score -lt 0) { $score = 0 }
        @{ score = $score; checks = $checks } | ConvertTo-Json -Depth 5 -Compress
    }
    'avscan' = {
        $findings = @()
        $tempDirs = @($env:TEMP, "$env:WINDIR\Temp", "$env:USERPROFILE\Downloads", "$env:LOCALAPPDATA\Temp") | Where-Object { $_ }
        $inSusp = {
            param($p)
            if (-not $p) { return $false }
            foreach ($d in $tempDirs) { if ($p -like "$d*") { return $true } }
            return $false
        }
        $isSigned = {
            param($p)
            try { if (-not (Test-Path $p)) { return $null }; return ((Get-AuthenticodeSignature $p -ErrorAction Stop).Status -eq 'Valid') } catch { return $null }
        }
        $add = { param($sev, $cat, $title, $detail, $path) $script:_f += @{ sev = $sev; cat = $cat; title = $title; detail = $detail; path = "$path" } }
        $script:_f = @()

        # 1) Autostart (Run-/RunOnce-Keys)
        $arCount = 0
        $runKeys = @(
            'HKCU:\Software\Microsoft\Windows\CurrentVersion\Run', 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Run',
            'HKCU:\Software\Microsoft\Windows\CurrentVersion\RunOnce', 'HKLM:\Software\Microsoft\Windows\CurrentVersion\RunOnce'
        )
        foreach ($k in $runKeys) {
            if (Test-Path $k) {
                foreach ($name in @((Get-Item $k).Property)) {
                    $arCount++
                    $val = "$((Get-ItemProperty $k -Name $name -ErrorAction SilentlyContinue).$name)"
                    $exe = $val; if ($val -match '^"([^"]+)"') { $exe = $matches[1] } elseif ($val -match '^(\S+\.exe)') { $exe = $matches[1] }
                    if (& $inSusp $exe) { & $add 'danger' 'Autostart' $name 'Startet aus einem Temp-/Download-Ordner - typisch fuer Schadsoftware.' $exe }
                    elseif ((& $isSigned $exe) -eq $false) { & $add 'warn' 'Autostart' $name 'Autostart-Programm ohne gueltige digitale Signatur.' $exe }
                }
            }
        }
        # Autostart-Ordner (Skripte)
        foreach ($sd in @("$env:APPDATA\Microsoft\Windows\Start Menu\Programs\Startup", "$env:ProgramData\Microsoft\Windows\Start Menu\Programs\Startup")) {
            if (Test-Path $sd) {
                foreach ($fi in (Get-ChildItem $sd -File -ErrorAction SilentlyContinue)) {
                    $arCount++
                    if ($fi.Extension -match '\.(bat|cmd|vbs|js|scr|ps1|hta)$') { & $add 'warn' 'Autostart' $fi.Name "Skript-Datei im Autostart-Ordner ($($fi.Extension))." $fi.FullName }
                }
            }
        }
        # 2) Laufende Prozesse aus verdaechtigen Orten
        $prCount = 0
        foreach ($proc in (Get-Process -ErrorAction SilentlyContinue)) {
            $pp = $null; try { $pp = $proc.Path } catch {}
            if ($pp) {
                $prCount++
                if (& $inSusp $pp) {
                    $sg = & $isSigned $pp
                    if ($sg -ne $true) { & $add 'danger' 'Prozess' $proc.ProcessName ("Laeuft aus Temp-/Download-Ordner" + $(if ($sg -eq $false) { ' und ist unsigniert' } else { '' }) + '.') $pp }
                }
            }
        }
        # 3) Hosts-Datei (Phishing-Umleitung sensibler Seiten)
        $hosts = "$env:WINDIR\System32\drivers\etc\hosts"
        if (Test-Path $hosts) {
            foreach ($ln in (Get-Content $hosts -ErrorAction SilentlyContinue)) {
                $t = $ln.Trim(); if (-not $t -or $t.StartsWith('#')) { continue }
                $parts = $t -split '\s+', 2; if ($parts.Count -lt 2) { continue }
                $ip = $parts[0]; $dom = $parts[1].Trim()
                if ($ip -notin @('0.0.0.0', '127.0.0.1', '::1', '255.255.255.255') -and $dom -match 'paypal|bank|login\.live|accounts\.google|steamcommunity|amazon|microsoftonline|discord') {
                    & $add 'danger' 'Hosts-Datei' 'Umleitung einer sensiblen Seite' "$dom wird auf $ip umgeleitet - moegliches Phishing." $hosts
                }
            }
        }
        # 4) Downloads mit doppelter Dateiendung (Tarnung)
        $dl = "$env:USERPROFILE\Downloads"
        if (Test-Path $dl) {
            foreach ($fi in (Get-ChildItem $dl -File -ErrorAction SilentlyContinue)) {
                if ($fi.Name -match '\.(pdf|jpg|jpeg|png|doc|docx|txt|mp4|mp3|zip)\.(exe|scr|bat|cmd|com|pif|vbs|js|hta)$') {
                    & $add 'danger' 'Downloads' $fi.Name 'Doppelte Dateiendung - tarnt sich als harmlose Datei.' $fi.FullName
                }
            }
        }
        # 5) Krypto-Miner (bekannte Miner-Namen + Mining-Kommandozeilen)
        $minerNames = 'xmrig|nbminer|phoenixminer|t-rex|trex|lolminer|gminer|teamredminer|nanominer|cpuminer|minerd|ethminer|cgminer|bfgminer|claymore|xmr-stak|srbminer|wildrig|miniz|ccminer|nicehash|winring0miner|systemminer'
        try {
            foreach ($wp in (Get-CimInstance Win32_Process -ErrorAction SilentlyContinue)) {
                $nm = "$($wp.Name)"; $cl = "$($wp.CommandLine)"; $ep = "$($wp.ExecutablePath)"
                $nmBase = $nm -replace '\.exe$', ''
                if ($nmBase -match "^($minerNames)$") { & $add 'danger' 'Krypto-Miner' $nm 'Bekannter Krypto-Miner laeuft - nutzt evtl. heimlich deine Hardware fuers Schuerfen.' $ep }
                elseif ($cl -match 'stratum\+tcp://|stratum2\+tcp://|--coin |--pool |xmr-stak|randomx|--algo ') { & $add 'danger' 'Krypto-Miner' $nm 'Prozess mit typischem Mining-Befehl (Pool-Verbindung) erkannt.' $ep }
            }
        } catch {}
        # 6) IFEO-Hijack (Debugger-Umleitung von Programmen)
        try {
            $ifeo = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options'
            if (Test-Path $ifeo) {
                foreach ($sub in (Get-ChildItem $ifeo -ErrorAction SilentlyContinue)) {
                    $dbg = (Get-ItemProperty $sub.PSPath -Name 'Debugger' -ErrorAction SilentlyContinue).Debugger
                    if ($dbg) { & $add 'danger' 'Hijack' ("$($sub.PSChildName)") "Programm wird beim Start auf '$dbg' umgeleitet (klassischer Malware-Trick)." $dbg }
                }
            }
        } catch {}
        # 7) Winlogon-Manipulation (Shell/Userinit)
        try {
            $wl = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon'
            $shell = (Get-ItemProperty $wl -Name 'Shell' -ErrorAction SilentlyContinue).Shell
            if ($shell -and $shell -notmatch '^explorer\.exe\s*$') { & $add 'danger' 'Winlogon' 'Shell veraendert' "Windows-Shell ist '$shell' statt explorer.exe." $shell }
            $ui = (Get-ItemProperty $wl -Name 'Userinit' -ErrorAction SilentlyContinue).Userinit
            if ($ui -and $ui -notmatch 'userinit\.exe') { & $add 'danger' 'Winlogon' 'Userinit veraendert' "Anmelde-Programm ist '$ui'." $ui }
        } catch {}
        # 8) Geplante Aufgaben aus verdaechtigen Orten
        $tkCount = 0
        try {
            foreach ($tk in (Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.State -ne 'Disabled' })) {
                foreach ($ac in @($tk.Actions)) {
                    $ex = "$($ac.Execute)"; if (-not $ex) { continue }
                    $ex2 = $ex.Trim('"'); $tkCount++
                    if (& $inSusp $ex2) { & $add 'danger' 'Geplante Aufgabe' $tk.TaskName "Startet aus Temp-/Download-Ordner: $ex2" $ex2 }
                }
            }
        } catch {}
        # 9) Dienste aus verdaechtigen Orten
        try {
            foreach ($sv in (Get-CimInstance Win32_Service -ErrorAction SilentlyContinue | Where-Object { $_.State -eq 'Running' -and $_.PathName })) {
                $spath = "$($sv.PathName)"; if ($spath -match '^"([^"]+)"') { $spath = $matches[1] } elseif ($spath -match '^(\S+\.exe)') { $spath = $matches[1] }
                if (& $inSusp $spath) { & $add 'danger' 'Dienst' "$($sv.Name)" "Windows-Dienst laeuft aus Temp-/Download-Ordner: $spath" $spath }
            }
        } catch {}
        # 10) Netzwerk: unsigniertes Programm aus Temp/AppData mit Aussenverbindung (moeglicher RAT/Backdoor)
        try {
            $seen = @{}
            foreach ($cn in (Get-NetTCPConnection -State Established -ErrorAction SilentlyContinue | Where-Object { $_.RemoteAddress -notmatch '^(127\.|::1$|0\.0\.0\.0|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2[0-9]|3[01])\.|fe80|::$)' })) {
                $op = "$($cn.OwningProcess)"; if (-not $op -or $seen.ContainsKey($op)) { continue }; $seen[$op] = $true
                $pp = $null; $pnm = ''; try { $pr = Get-Process -Id ([int]$op) -ErrorAction Stop; $pp = $pr.Path; $pnm = $pr.ProcessName } catch {}
                if ($pp -and (& $inSusp $pp) -and ((& $isSigned $pp) -ne $true)) {
                    & $add 'danger' 'Netzwerk' $pnm "Unsigniertes Programm aus Temp/AppData mit Internet-Verbindung ($($cn.RemoteAddress)) - moeglicher Backdoor/RAT." $pp
                }
            }
        } catch {}
        # 11) Getarnte System-Prozesse (svchost/lsass/... ausserhalb System32 = starkes Malware-Signal)
        try {
            $sysNames = 'svchost|lsass|csrss|services|winlogon|smss|wininit|spoolsv|taskhostw|dwm|conhost'
            foreach ($proc in (Get-Process -ErrorAction SilentlyContinue)) {
                if ($proc.ProcessName -match "^($sysNames)$") {
                    $pp = $null; try { $pp = $proc.Path } catch {}
                    if ($pp -and $pp -notmatch '\\Windows\\(System32|SysWOW64|WinSxS)\\' -and $pp -notmatch '\\Windows\\explorer') {
                        & $add 'danger' 'Tarnung' $proc.ProcessName "Systemname, laeuft aber aus '$pp' statt System32 - typisch fuer getarnte Malware." $pp
                    }
                }
            }
        } catch {}
        # 12) AppInit_DLLs (DLL-Injektion in alle Programme)
        try {
            foreach ($ai in @('HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Windows', 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows NT\CurrentVersion\Windows')) {
                $dll = (Get-ItemProperty $ai -Name 'AppInit_DLLs' -ErrorAction SilentlyContinue).AppInit_DLLs
                if ("$dll".Trim()) { & $add 'danger' 'Injektion' 'AppInit_DLLs gesetzt' "Eine DLL wird in JEDES Programm geladen: $dll" "$dll" }
            }
        } catch {}
        # 13) Frisch erstellte, unsignierte Programme in Temp/Downloads (letzte 7 Tage)
        try {
            $cut = (Get-Date).AddDays(-7)
            foreach ($d in @($env:TEMP, "$env:USERPROFILE\Downloads", "$env:LOCALAPPDATA\Temp")) {
                if ($d -and (Test-Path $d)) {
                    foreach ($fi in (Get-ChildItem $d -File -ErrorAction SilentlyContinue | Where-Object { $_.Extension -match '\.(exe|scr|com|pif)$' -and $_.CreationTime -gt $cut })) {
                        if ((& $isSigned $fi.FullName) -ne $true) { & $add 'warn' 'Neu & unsigniert' $fi.Name "Kuerzlich erstellte, unsignierte ausfuehrbare Datei ($($fi.CreationTime.ToString('yyyy-MM-dd')))." $fi.FullName }
                    }
                }
            }
        } catch {}
        $findings = $script:_f
        # Vertrauensliste (vom Nutzer als sicher markierte Pfade) ausblenden
        $trust = @(); $trustFile = "$env:LOCALAPPDATA\PC-Boost\avtrust.json"
        if (Test-Path $trustFile) { try { $trust = @((Get-Content $trustFile -Raw | ConvertFrom-Json) | ForEach-Object { "$_".ToLower() }) } catch {} }
        if ($trust.Count -gt 0) { $findings = @($findings | Where-Object { -not $_.path -or ($trust -notcontains "$($_.path)".ToLower()) }) }
        # SHA256-Hash + Entropie fuer Datei-Funde (via .NET, kein Modul noetig)
        foreach ($fd in $findings) {
            if ($fd.path -and (Test-Path $fd.path -PathType Leaf)) {
                try {
                    $sha = [System.Security.Cryptography.SHA256]::Create()
                    $fsx = [System.IO.File]::OpenRead($fd.path)
                    $fd.hash = [BitConverter]::ToString($sha.ComputeHash($fsx)).Replace('-', '')
                    $fsx.Close(); $sha.Dispose()
                } catch {}
                try {
                    $fs2 = [System.IO.File]::OpenRead($fd.path)
                    $buf = New-Object byte[] 262144
                    $read = $fs2.Read($buf, 0, $buf.Length); $fs2.Close()
                    if ($read -gt 1024) {
                        $counts = New-Object 'int[]' 256
                        for ($k = 0; $k -lt $read; $k++) { $counts[$buf[$k]]++ }
                        $ent = 0.0
                        foreach ($ct in $counts) { if ($ct -gt 0) { $pr = $ct / $read; $ent -= $pr * [Math]::Log($pr, 2) } }
                        $fd.entropy = [Math]::Round($ent, 2)
                        # Sehr hohe Entropie in ausfuehrbarer Datei = wahrscheinlich gepackt/verschluesselt
                        if ($ent -gt 7.2 -and $fd.path -match '\.(exe|scr|dll|com)$') { $fd.packed = $true; if ($fd.sev -eq 'warn') { $fd.sev = 'danger' } }
                    }
                } catch {}
            }
        }
        $danger = @($findings | Where-Object { $_.sev -eq 'danger' }).Count
        $warn = @($findings | Where-Object { $_.sev -eq 'warn' }).Count
        $score = 100 - $danger * 25 - $warn * 8; if ($score -lt 0) { $score = 0 }
        @{ score = $score; danger = $danger; warn = $warn; scanned = @{ autoruns = $arCount; processes = $prCount }; findings = @($findings) } | ConvertTo-Json -Depth 5 -Compress
    }
    'opsecscan' = {
        function rv($path, $name) { try { return (Get-ItemProperty -Path $path -Name $name -ErrorAction Stop).$name } catch { return $null } }
        function ochk($label, $status, $detail, $fix, $page) { @{ label = $label; status = $status; detail = $detail; fix = $fix; page = $page } }
        $c = @()
        # Firewall
        try { $fw = @(Get-NetFirewallProfile -ErrorAction Stop); $off = @($fw | Where-Object { -not $_.Enabled })
            if ($off.Count -eq 0) { $c += ochk 'Windows-Firewall' 'ok' 'Alle Profile aktiv.' '' '' } else { $c += ochk 'Windows-Firewall' 'bad' "$($off.Count) Profil(e) ausgeschaltet." 'fwon' '' }
        } catch { $c += ochk 'Windows-Firewall' 'warn' 'Status nicht lesbar.' '' '' }
        # Remotedesktop (RDP)
        $rdp = rv 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server' 'fDenyTSConnections'
        if ($rdp -eq 0) { $c += ochk 'Remotedesktop (RDP)' 'bad' 'Aktiviert - Fernzugriff auf deinen PC moeglich. Fuer OPSEC besser aus.' 'rdpoff' '' } else { $c += ochk 'Remotedesktop (RDP)' 'ok' 'Deaktiviert.' '' '' }
        # Remoteunterstuetzung
        $ra = rv 'HKLM:\SYSTEM\CurrentControlSet\Control\Remote Assistance' 'fAllowToGetHelp'
        if ($ra -eq 1) { $c += ochk 'Remoteunterstuetzung' 'warn' 'Aktiviert - erlaubt Hilfe-Fernsitzungen.' 'raoff' '' } else { $c += ochk 'Remoteunterstuetzung' 'ok' 'Deaktiviert.' '' '' }
        # SMBv1 (veraltet/unsicher)
        try { $smb1 = (Get-SmbServerConfiguration -ErrorAction Stop).EnableSMB1Protocol
            if ($smb1) { $c += ochk 'SMBv1 (Alt-Protokoll)' 'bad' 'Aktiv - unsicher (WannaCry-Vektor).' 'smb1off' '' } else { $c += ochk 'SMBv1 (Alt-Protokoll)' 'ok' 'Deaktiviert.' '' '' }
        } catch { $c += ochk 'SMBv1 (Alt-Protokoll)' 'ok' 'Nicht aktiv.' '' '' }
        # Telemetrie
        $tel = rv 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection' 'AllowTelemetry'
        if ($tel -eq 0) { $c += ochk 'Telemetrie' 'ok' 'Auf Minimum.' '' '' } else { $c += ochk 'Telemetrie' 'warn' 'Diagnosedaten werden an Microsoft gesendet.' '' 'tracking' }
        # Werbe-ID
        $ad = rv 'HKCU:\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo' 'Enabled'
        if ($ad -eq 0) { $c += ochk 'Werbe-ID' 'ok' 'Aus.' '' '' } else { $c += ochk 'Werbe-ID' 'warn' 'Aktiv - App-uebergreifendes Tracking moeglich.' '' 'tracking' }
        # Standort-Dienst
        $loc = rv 'HKLM:\SYSTEM\CurrentControlSet\Services\lfsvc\Service\Configuration' 'Status'
        if ($loc -eq 0) { $c += ochk 'Standort-Dienst' 'ok' 'Aus.' '' '' } else { $c += ochk 'Standort-Dienst' 'warn' 'Aktiv - dein Standort ist abrufbar.' '' 'tracking' }
        # Cloud-Zwischenablage
        $clip = rv 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\System' 'AllowCrossDeviceClipboard'
        if ($clip -eq 0) { $c += ochk 'Cloud-Zwischenablage' 'ok' 'Bleibt lokal.' '' '' } else { $c += ochk 'Cloud-Zwischenablage' 'warn' 'Kopierte Inhalte werden evtl. in die Cloud synchronisiert.' '' 'tracking' }
        # UAC (Benutzerkontensteuerung)
        $uac = rv 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' 'EnableLUA'
        if ($uac -eq 0) { $c += ochk 'UAC (Benutzerkontensteuerung)' 'bad' 'Ausgeschaltet - Programme koennen ohne Nachfrage Admin-Rechte nehmen.' 'uacon' '' } else { $c += ochk 'UAC (Benutzerkontensteuerung)' 'ok' 'Aktiv.' '' '' }
        # Automatische Anmeldung
        $alogon = rv 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' 'AutoAdminLogon'
        if ("$alogon" -eq '1') { $c += ochk 'Automatische Anmeldung' 'bad' 'Aktiv - Windows startet ohne Passwort. Passwort steht evtl. im Klartext in der Registry.' 'autologonoff' '' } else { $c += ochk 'Automatische Anmeldung' 'ok' 'Aus - Anmeldung mit Passwort.' '' '' }
        # BitLocker (Festplattenverschluesselung)
        try {
            $bl = Get-BitLockerVolume -MountPoint 'C:' -ErrorAction Stop
            if ("$($bl.ProtectionStatus)" -eq 'On') { $c += ochk 'BitLocker (Laufwerk C:)' 'ok' 'Verschluesselt - Daten bei Diebstahl geschuetzt.' '' '' }
            else { $c += ochk 'BitLocker (Laufwerk C:)' 'warn' 'Nicht verschluesselt - bei Diebstahl sind deine Daten lesbar.' '' '' }
        } catch { $c += ochk 'BitLocker (Laufwerk C:)' 'warn' 'Status nicht lesbar (evtl. nicht verfuegbar/Adminrechte).' '' '' }
        # Netzwerkprofil
        try {
            $np = @(Get-NetConnectionProfile -ErrorAction Stop)
            $priv = @($np | Where-Object { "$($_.NetworkCategory)" -eq 'Private' })
            if ($priv.Count -gt 0) { $c += ochk 'Netzwerkprofil' 'warn' 'Mind. ein Netzwerk ist "Privat" (dein PC ist im Netz sichtbar/teilbar). In fremden Netzen besser "Oeffentlich".' '' '' }
            else { $c += ochk 'Netzwerkprofil' 'ok' 'Oeffentlich - PC ist im Netz nicht sichtbar.' '' '' }
        } catch {}
        # Offene (lauschende) Ports nach aussen
        try {
            $risky = @{ '3389'='Remotedesktop'; '445'='Dateifreigabe (SMB)'; '139'='NetBIOS'; '135'='RPC'; '5900'='VNC'; '5985'='WinRM'; '23'='Telnet' }
            $listen = @(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue | Where-Object { $_.LocalAddress -notmatch '^(127\.|::1$)' })
            $openRisky = @($listen | Where-Object { $risky.ContainsKey("$($_.LocalPort)") } | ForEach-Object { "$($_.LocalPort) ($($risky["$($_.LocalPort)"]))" } | Sort-Object -Unique)
            if ($openRisky.Count -gt 0) { $c += ochk 'Offene Ports nach aussen' 'warn' ("Riskante lauschende Ports: " + ($openRisky -join ', ') + '. Nur oeffnen, wenn wirklich noetig.') '' '' }
            else { $c += ochk 'Offene Ports nach aussen' 'ok' 'Keine riskanten Ports offen.' '' '' }
        } catch {}
        # LLMNR (Namensaufloesung - LAN-Poisoning/Hash-Diebstahl-Vektor)
        $llmnr = rv 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient' 'EnableMulticast'
        if ($llmnr -eq 0) { $c += ochk 'LLMNR' 'ok' 'Deaktiviert.' '' '' } else { $c += ochk 'LLMNR' 'warn' 'Aktiv - Angreifer im selben Netz koennen Namensanfragen faelschen (Passwort-Hash-Diebstahl).' 'llmnroff' '' }
        # NetBIOS ueber TCP/IP
        try {
            $nbk = 'HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters\Interfaces'; $anyOn = $false
            if (Test-Path $nbk) { foreach ($i in (Get-ChildItem $nbk -ErrorAction SilentlyContinue)) { $v = (Get-ItemProperty $i.PSPath -Name 'NetbiosOptions' -ErrorAction SilentlyContinue).NetbiosOptions; if ("$v" -ne '2') { $anyOn = $true } } }
            if ($anyOn) { $c += ochk 'NetBIOS ueber TCP/IP' 'warn' 'Aktiv - altes Protokoll, Angriffs-/Poisoning-Vektor im LAN.' 'netbiosoff' '' } else { $c += ochk 'NetBIOS ueber TCP/IP' 'ok' 'Deaktiviert.' '' '' }
        } catch {}
        # AutoRun/AutoPlay (USB-Malware)
        $autorun = rv 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' 'NoDriveTypeAutoRun'
        if ("$autorun" -eq '255') { $c += ochk 'AutoRun/AutoPlay' 'ok' 'Deaktiviert.' '' '' } else { $c += ochk 'AutoRun/AutoPlay' 'warn' 'Aktiv - USB-Sticks koennen automatisch Schadcode starten.' 'autorunoff' '' }
        # SmartScreen
        $ss = rv 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' 'SmartScreenEnabled'
        if ("$ss" -eq 'Off') { $c += ochk 'SmartScreen' 'warn' 'Aus - kein Schutz vor bekannten boesartigen Downloads.' 'smartscreenon' '' } else { $c += ochk 'SmartScreen' 'ok' 'Aktiv.' '' '' }
        $score = 100; foreach ($x in $c) { if ($x.status -eq 'bad') { $score -= 15 } elseif ($x.status -eq 'warn') { $score -= 6 } }; if ($score -lt 0) { $score = 0 }
        @{ score = $score; checks = $c } | ConvertTo-Json -Depth 5 -Compress
    }
    'uacon'        = { try { Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'EnableLUA' -Value 1 -ErrorAction Stop; 'UAC aktiviert (Neustart noetig).' } catch { 'Nicht moeglich (Adminrechte noetig): ' + $_.Exception.Message } }
    'autologonoff' = { try { Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' -Name 'AutoAdminLogon' -Value '0' -ErrorAction Stop; Remove-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' -Name 'DefaultPassword' -ErrorAction SilentlyContinue; 'Automatische Anmeldung deaktiviert.' } catch { 'Nicht moeglich (Adminrechte noetig): ' + $_.Exception.Message } }
    'llmnroff'     = { try { New-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient' -Force -ErrorAction Stop | Out-Null; Set-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient' -Name 'EnableMulticast' -Value 0 -Type DWord -ErrorAction Stop; 'LLMNR deaktiviert.' } catch { 'Nicht moeglich (Adminrechte noetig): ' + $_.Exception.Message } }
    'netbiosoff'   = { try { Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters\Interfaces' -ErrorAction Stop | ForEach-Object { Set-ItemProperty -Path $_.PSPath -Name 'NetbiosOptions' -Value 2 -ErrorAction SilentlyContinue }; 'NetBIOS ueber TCP/IP deaktiviert (alle Adapter).' } catch { 'Nicht moeglich (Adminrechte noetig): ' + $_.Exception.Message } }
    'autorunoff'   = { try { New-Item -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Force -ErrorAction SilentlyContinue | Out-Null; Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'NoDriveTypeAutoRun' -Value 255 -Type DWord -ErrorAction Stop; 'AutoRun/AutoPlay deaktiviert.' } catch { 'Nicht moeglich (Adminrechte noetig): ' + $_.Exception.Message } }
    'smartscreenon'= { try { Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -Name 'SmartScreenEnabled' -Value 'RequireAdmin' -ErrorAction Stop; 'SmartScreen aktiviert.' } catch { 'Nicht moeglich (Adminrechte noetig): ' + $_.Exception.Message } }
    'hardenall' = {
        $done = @(); $fail = @()
        try { Set-NetFirewallProfile -All -Enabled True -ErrorAction Stop; $done += 'Firewall an' } catch { $fail += 'Firewall' }
        try { Set-SmbServerConfiguration -EnableSMB1Protocol $false -Force -ErrorAction Stop; $done += 'SMBv1 aus' } catch { $fail += 'SMBv1' }
        try { New-Item -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient' -Force -ErrorAction Stop | Out-Null; Set-ItemProperty -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient' -Name 'EnableMulticast' -Value 0 -Type DWord -ErrorAction Stop; $done += 'LLMNR aus' } catch { $fail += 'LLMNR' }
        try { Get-ChildItem 'HKLM:\SYSTEM\CurrentControlSet\Services\NetBT\Parameters\Interfaces' -ErrorAction Stop | ForEach-Object { Set-ItemProperty -Path $_.PSPath -Name 'NetbiosOptions' -Value 2 -ErrorAction SilentlyContinue }; $done += 'NetBIOS aus' } catch { $fail += 'NetBIOS' }
        try { New-Item -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Force -ErrorAction SilentlyContinue | Out-Null; Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer' -Name 'NoDriveTypeAutoRun' -Value 255 -Type DWord -ErrorAction Stop; $done += 'AutoRun aus' } catch { $fail += 'AutoRun' }
        try { Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer' -Name 'SmartScreenEnabled' -Value 'RequireAdmin' -ErrorAction Stop; $done += 'SmartScreen an' } catch { $fail += 'SmartScreen' }
        try { Set-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -Name 'EnableLUA' -Value 1 -ErrorAction Stop; $done += 'UAC an' } catch { $fail += 'UAC' }
        $msg = 'Gehaertet: ' + ($done -join ', ') + '.'
        if ($fail.Count) { $msg += ' | Fehlgeschlagen (Adminrechte noetig): ' + ($fail -join ', ') + '.' }
        $msg
    }
    'fwon'    = { try { Set-NetFirewallProfile -All -Enabled True -ErrorAction Stop; 'Windows-Firewall fuer alle Profile aktiviert.' } catch { 'Nicht moeglich (Adminrechte noetig): ' + $_.Exception.Message } }
    'rdpoff'  = { try { Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server' -Name 'fDenyTSConnections' -Value 1 -ErrorAction Stop; try { Disable-NetFirewallRule -DisplayGroup 'Remotedesktop' -ErrorAction SilentlyContinue } catch {}; 'Remotedesktop (RDP) deaktiviert.' } catch { 'Nicht moeglich (Adminrechte noetig): ' + $_.Exception.Message } }
    'raoff'   = { try { Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Remote Assistance' -Name 'fAllowToGetHelp' -Value 0 -ErrorAction Stop; 'Remoteunterstuetzung deaktiviert.' } catch { 'Nicht moeglich (Adminrechte noetig): ' + $_.Exception.Message } }
    'smb1off' = { try { Set-SmbServerConfiguration -EnableSMB1Protocol $false -Force -ErrorAction Stop; 'SMBv1 deaktiviert.' } catch { 'Nicht moeglich (Adminrechte noetig): ' + $_.Exception.Message } }
    'winlist' = {
        $raw = [PCBoostInput]::ListWindows()
        $arr = @()
        foreach ($ln in ($raw -split "`n")) {
            if (-not $ln) { continue }
            $p = $ln -split '\|', 3
            if ($p.Count -lt 3) { continue }
            $pid2 = 0; [void][int]::TryParse($p[1], [ref]$pid2)
            $pn = ''; try { $pn = (Get-Process -Id $pid2 -ErrorAction Stop).ProcessName } catch {}
            $arr += [ordered]@{ hwnd = "$($p[0])"; pid = "$($p[1])"; proc = $pn; title = $p[2] }
        }
        @{ windows = @($arr) } | ConvertTo-Json -Depth 5 -Compress
    }
    'winfocus' = { param($h) try { [PCBoostInput]::FocusWindow([long]$h); 'Fenster in den Vordergrund geholt.' } catch { 'Nicht moeglich.' } }
    'winclose' = { param($h) try { [PCBoostInput]::CloseWindow([long]$h); 'Schliessen-Signal an das Fenster gesendet.' } catch { 'Nicht moeglich.' } }
    'wintop'   = { param($cfg) try { $x = "$cfg" -split ','; [PCBoostInput]::SetTop([long]$x[0], ($x[1] -eq '1')); if ($x[1] -eq '1') { 'Fenster bleibt jetzt immer im Vordergrund.' } else { 'Immer-im-Vordergrund aufgehoben.' } } catch { 'Nicht moeglich.' } }
    'colorpick' = {
        param($delay)
        $d = 3; [void][int]::TryParse("$delay", [ref]$d); if ($d -lt 0) { $d = 0 }; if ($d -gt 10) { $d = 10 }
        Start-Sleep -Seconds $d
        $r = [PCBoostInput]::PickColor() -split ','
        $hex = ('#{0:X2}{1:X2}{2:X2}' -f [int]$r[0], [int]$r[1], [int]$r[2])
        @{ hex = $hex; r = [int]$r[0]; g = [int]$r[1]; b = [int]$r[2]; x = [int]$r[3]; y = [int]$r[4] } | ConvertTo-Json -Compress
    }
    'screenshot' = {
        try {
            Add-Type -AssemblyName System.Drawing -ErrorAction SilentlyContinue
            Add-Type -AssemblyName System.Windows.Forms -ErrorAction SilentlyContinue
            $b = [System.Windows.Forms.SystemInformation]::VirtualScreen
            $dir = $null
            foreach ($cand in @("$env:USERPROFILE\Desktop\PC-Boost", "$env:USERPROFILE\PC-Boost-Screens")) {
                try { [System.IO.Directory]::CreateDirectory($cand) | Out-Null; if (Test-Path $cand) { $dir = $cand; break } } catch {}
            }
            if (-not $dir) { return 'Kein schreibbarer Ordner fuer Screenshots gefunden.' }
            $bmp = New-Object System.Drawing.Bitmap($b.Width, $b.Height)
            $g = [System.Drawing.Graphics]::FromImage($bmp)
            $g.CopyFromScreen($b.Location, [System.Drawing.Point]::Empty, $b.Size)
            $file = Join-Path $dir ('shot_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.png')
            $bmp.Save($file, [System.Drawing.Imaging.ImageFormat]::Png)
            $g.Dispose(); $bmp.Dispose()
            "PATH:$file"
        } catch { 'Screenshot fehlgeschlagen: ' + $_.Exception.Message }
    }
    'shred' = {
        param($path)
        $p = "$path".Trim('"').Trim()
        if (-not $p -or -not (Test-Path $p -PathType Leaf)) { return 'Datei nicht gefunden. Bitte den vollstaendigen Pfad zu EINER Datei angeben.' }
        $full = (Resolve-Path $p).Path
        if ($full.ToLower() -match '\\windows\\|\\program files|\\programdata\\|pc-boost') { return 'Zur Sicherheit gesperrt: System-/Programm-Ordner werden nicht geschreddert.' }
        try {
            $fi = Get-Item $full; $len = [long]$fi.Length
            $fs = [System.IO.File]::Open($full, 'Open', 'Write')
            $buf = New-Object byte[] 65536; $rand = New-Object System.Random
            for ($pass = 0; $pass -lt 3; $pass++) {
                $fs.Position = 0; $written = 0
                while ($written -lt $len) {
                    $chunk = [Math]::Min($buf.Length, $len - $written)
                    $rand.NextBytes($buf); $fs.Write($buf, 0, $chunk); $written += $chunk
                }
                $fs.Flush()
            }
            $fs.Close(); Remove-Item $full -Force
            "Datei 3x mit Zufallsdaten ueberschrieben und geloescht: $full"
        } catch { 'Fehlgeschlagen: ' + $_.Exception.Message }
    }
    'quarantine' = {
        param($path)
        $p = "$path".Trim('"').Trim()
        if (-not $p -or -not (Test-Path $p -PathType Leaf)) { return 'Datei nicht gefunden.' }
        $full = (Resolve-Path $p).Path
        if ($full.ToLower() -match '\\windows\\|\\program files|pc-boost') { return 'Zur Sicherheit gesperrt: System-/Programm-Dateien nicht in Quarantaene.' }
        try {
            $qdir = Join-Path $env:LOCALAPPDATA 'PC-Boost-Quarantaene'
            [System.IO.Directory]::CreateDirectory($qdir) | Out-Null
            $qfile = Join-Path $qdir ((Get-Date -Format 'yyyyMMdd_HHmmss') + '_' + (Split-Path $full -Leaf) + '.quar')
            Move-Item -Path $full -Destination $qfile -Force
            $qlog = Join-Path $qdir 'index.json'; $idx = @(); if (Test-Path $qlog) { try { $idx = @(Get-Content $qlog -Raw | ConvertFrom-Json) } catch {} }
            $idx = @(@([ordered]@{ orig = $full; quar = $qfile; time = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss') }) + $idx)
            ($idx | ConvertTo-Json -Depth 5) | Set-Content $qlog -Encoding UTF8
            'In Quarantaene verschoben - die Datei ist jetzt isoliert und laeuft nicht mehr. Wiederherstellbar.'
        } catch { 'Quarantaene fehlgeschlagen: ' + $_.Exception.Message }
    }
    'quarlist' = {
        $qdir = Join-Path $env:LOCALAPPDATA 'PC-Boost-Quarantaene'; $qlog = Join-Path $qdir 'index.json'
        $idx = @(); if (Test-Path $qlog) { try { $idx = @((Get-Content $qlog -Raw | ConvertFrom-Json) | Where-Object { Test-Path $_.quar } | ForEach-Object { [ordered]@{ orig = "$($_.orig)"; quar = "$($_.quar)"; time = "$($_.time)" } }) } catch {} }
        @{ items = @($idx) } | ConvertTo-Json -Depth 5 -Compress
    }
    'quarrestore' = {
        param($quar)
        $q = "$quar".Trim(); if (-not (Test-Path $q)) { return 'Quarantaene-Datei nicht gefunden.' }
        $qdir = Join-Path $env:LOCALAPPDATA 'PC-Boost-Quarantaene'; $qlog = Join-Path $qdir 'index.json'
        $idx = @(); if (Test-Path $qlog) { try { $idx = @(Get-Content $qlog -Raw | ConvertFrom-Json) } catch {} }
        $entry = $idx | Where-Object { $_.quar -eq $q } | Select-Object -First 1
        if (-not $entry) { return 'Kein passender Eintrag gefunden.' }
        try {
            Move-Item -Path $q -Destination $entry.orig -Force
            $idx = @($idx | Where-Object { $_.quar -ne $q }); ($idx | ConvertTo-Json -Depth 5) | Set-Content $qlog -Encoding UTF8
            "Wiederhergestellt nach: $($entry.orig)"
        } catch { 'Wiederherstellen fehlgeschlagen: ' + $_.Exception.Message }
    }
    'quardelete' = {
        param($quar)
        $q = "$quar".Trim(); if (-not (Test-Path $q)) { return 'Datei nicht gefunden.' }
        $qdir = Join-Path $env:LOCALAPPDATA 'PC-Boost-Quarantaene'; $qlog = Join-Path $qdir 'index.json'
        try {
            Remove-Item $q -Force
            $idx = @(); if (Test-Path $qlog) { try { $idx = @(Get-Content $qlog -Raw | ConvertFrom-Json) } catch {} }
            $idx = @($idx | Where-Object { $_.quar -ne $q }); ($idx | ConvertTo-Json -Depth 5) | Set-Content $qlog -Encoding UTF8
            'Endgueltig aus der Quarantaene geloescht.'
        } catch { 'Loeschen fehlgeschlagen: ' + $_.Exception.Message }
    }
    'avtrust' = {
        param($path)
        $p = "$path".Trim(); if (-not $p) { return 'Kein Pfad.' }
        try {
            $dir = "$env:LOCALAPPDATA\PC-Boost"; [System.IO.Directory]::CreateDirectory($dir) | Out-Null
            $tf = Join-Path $dir 'avtrust.json'
            $t = @(); if (Test-Path $tf) { try { $t = @(Get-Content $tf -Raw | ConvertFrom-Json) } catch {} }
            if ($t -notcontains $p) { $t = @($t) + $p }
            ($t | ConvertTo-Json) | Set-Content $tf -Encoding UTF8
            'Als sicher markiert - taucht im Scan nicht mehr auf.'
        } catch { 'Fehlgeschlagen: ' + $_.Exception.Message }
    }
    'filehash' = {
        param($path)
        $p = "$path".Trim('"').Trim()
        if (-not $p -or -not (Test-Path $p -PathType Leaf)) { return '{"ok":false,"msg":"Datei nicht gefunden - vollstaendigen Pfad angeben."}' }
        try {
            $fi = Get-Item $p
            $h = @{}
            foreach ($alg in 'MD5', 'SHA1', 'SHA256') {
                $fs = [System.IO.File]::OpenRead($p)
                $c = [System.Security.Cryptography.HashAlgorithm]::Create($alg)
                $h[$alg] = [BitConverter]::ToString($c.ComputeHash($fs)).Replace('-', '')
                $fs.Close(); $c.Dispose()
            }
            @{ ok = $true; name = $fi.Name; sizeKB = [math]::Round($fi.Length / 1KB, 1); md5 = $h['MD5']; sha1 = $h['SHA1']; sha256 = $h['SHA256'] } | ConvertTo-Json -Compress
        } catch { '{"ok":false,"msg":"Fehler beim Lesen der Datei."}' }
    }
    'vtcheck' = {
        param($hash)
        $h = "$hash".Trim()
        if ($h -notmatch '^[0-9a-fA-F]{64}$') { return '{"ok":false,"msg":"Kein gueltiger Hash."}' }
        $key = $env:PCBOOST_VTKEY
        if (-not $key) { return '{"ok":false,"msg":"Kein VirusTotal-API-Key eingerichtet. Trage ihn in pcboost-virustotal.txt ein und starte neu."}' }
        try {
            $wr = [System.Net.HttpWebRequest]::Create("https://www.virustotal.com/api/v3/files/$h")
            $wr.Method = 'GET'; $wr.Timeout = 9000; $wr.UserAgent = 'PC-Boost'
            $wr.Headers.Add('x-apikey', $key)
            $rp = $wr.GetResponse(); $sr2 = New-Object IO.StreamReader($rp.GetResponseStream()); $json = $sr2.ReadToEnd(); $sr2.Close(); $rp.Close()
            $o = $json | ConvertFrom-Json
            $st = $o.data.attributes.last_analysis_stats
            $mal = [int]$st.malicious; $susp = [int]$st.suspicious
            $tot = $mal + $susp + [int]$st.harmless + [int]$st.undetected
            @{ ok = $true; malicious = $mal; suspicious = $susp; total = $tot; link = "https://www.virustotal.com/gui/file/$h" } | ConvertTo-Json -Compress
        } catch [System.Net.WebException] {
            $code = 0; try { $code = [int]$_.Exception.Response.StatusCode } catch {}
            if ($code -eq 404) { '{"ok":true,"notfound":true,"msg":"VirusTotal kennt diese Datei nicht (kein Treffer)."}' }
            elseif ($code -eq 401) { '{"ok":false,"msg":"VirusTotal-API-Key ungueltig."}' }
            elseif ($code -eq 429) { '{"ok":false,"msg":"VirusTotal-Limit erreicht (kostenlos ~4/Minute). Kurz warten."}' }
            else { '{"ok":false,"msg":"Abfrage fehlgeschlagen."}' }
        } catch { '{"ok":false,"msg":"Abfrage fehlgeschlagen."}' }
    }
    'explorerrestart' = {
        try { Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue; Start-Sleep -Milliseconds 900; if (-not (Get-Process -Name explorer -ErrorAction SilentlyContinue)) { Start-Process explorer }; 'Explorer neu gestartet - Taskleisten-/Explorer-Aenderungen sind jetzt aktiv.' } catch { 'Fehler: ' + $_.Exception.Message }
    }
    'power' = {
        param($cfg)
        try { $c = $cfg | ConvertFrom-Json } catch { return 'Ungueltige Konfiguration.' }
        $mode = "$($c.mode)"; $sec = 0; [void][int]::TryParse("$($c.seconds)", [ref]$sec); if ($sec -lt 0) { $sec = 0 }
        try {
            switch ($mode) {
                'lock'      { Start-Process rundll32.exe -ArgumentList 'user32.dll,LockWorkStation'; 'PC gesperrt.' }
                'sleep'     { Start-Process rundll32.exe -ArgumentList 'powrprof.dll,SetSuspendState 0,1,0'; 'Energiesparmodus wird aktiviert ...' }
                'hibernate' { & shutdown /h; 'Ruhezustand wird aktiviert ...' }
                'logoff'    { & shutdown /l; 'Abmelden ...' }
                'restart'   { & shutdown /r /t $sec /c 'PC Boost: Neustart'; if ($sec -gt 0) { "Neustart in $sec Sekunden geplant. Abbrechen mit dem roten Knopf." } else { 'PC wird neu gestartet ...' } }
                'shutdown'  { & shutdown /s /t $sec /c 'PC Boost: Herunterfahren'; if ($sec -gt 0) { "Herunterfahren in $sec Sekunden geplant. Abbrechen mit dem roten Knopf." } else { 'PC wird heruntergefahren ...' } }
                'cancel'    { & shutdown /a 2>&1 | Out-Null; 'Geplantes Herunterfahren/Neustart abgebrochen.' }
                default     { 'Unbekannte Aktion.' }
            }
        } catch { 'Fehler: ' + $_.Exception.Message }
    }
    'ctxmenu' = {
        param($mode)
        $base = 'HKCU:\Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}'
        try {
            if ("$mode" -eq 'on') { New-Item -Path "$base\InprocServer32" -Force | Out-Null; New-ItemProperty -Path "$base\InprocServer32" -Name '(Default)' -Value '' -Force | Out-Null; 'Klassisches (volles) Rechtsklick-Menue aktiviert. Explorer-Neustart uebernimmt es.' }
            else { Remove-Item -Path $base -Recurse -Force -ErrorAction SilentlyContinue; 'Windows-11-Rechtsklick-Menue wiederhergestellt. Explorer-Neustart uebernimmt es.' }
        } catch { 'Fehler: ' + $_.Exception.Message }
    }
    'mouseaccel' = {
        param($mode)
        try {
            if ("$mode" -eq 'off') { Set-ItemProperty 'HKCU:\Control Panel\Mouse' -Name MouseSpeed -Value '0' -Force; Set-ItemProperty 'HKCU:\Control Panel\Mouse' -Name MouseThreshold1 -Value '0' -Force; Set-ItemProperty 'HKCU:\Control Panel\Mouse' -Name MouseThreshold2 -Value '0' -Force; 'Maus-Beschleunigung AUS (1:1-Bewegung, besser fuers Zielen). Beim naechsten An-/Abmelden voll aktiv.' }
            else { Set-ItemProperty 'HKCU:\Control Panel\Mouse' -Name MouseSpeed -Value '1' -Force; Set-ItemProperty 'HKCU:\Control Panel\Mouse' -Name MouseThreshold1 -Value '6' -Force; Set-ItemProperty 'HKCU:\Control Panel\Mouse' -Name MouseThreshold2 -Value '10' -Force; 'Maus-Beschleunigung AN (Windows-Standard).' }
        } catch { 'Fehler: ' + $_.Exception.Message }
    }
    'darkmode' = {
        param($mode)
        $p = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize'
        try {
            if (-not (Test-Path $p)) { New-Item $p -Force | Out-Null }
            if ("$mode" -eq 'light') { Set-ItemProperty $p -Name AppsUseLightTheme -Value 1 -Type DWord -Force; Set-ItemProperty $p -Name SystemUsesLightTheme -Value 1 -Type DWord -Force; 'Helles Design aktiviert.' }
            else { Set-ItemProperty $p -Name AppsUseLightTheme -Value 0 -Type DWord -Force; Set-ItemProperty $p -Name SystemUsesLightTheme -Value 0 -Type DWord -Force; 'Dunkles Design aktiviert.' }
        } catch { 'Fehler: ' + $_.Exception.Message }
    }
    'visualfx' = {
        param($mode)
        $p = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects'
        try {
            if (-not (Test-Path $p)) { New-Item $p -Force | Out-Null }
            if ("$mode" -eq 'perf') { Set-ItemProperty $p -Name VisualFXSetting -Value 2 -Type DWord -Force; 'Auf beste LEISTUNG gestellt (weniger Effekte = schneller). Ab-/Anmelden oder Explorer-Neustart uebernimmt es voll.' }
            else { Set-ItemProperty $p -Name VisualFXSetting -Value 1 -Type DWord -Force; 'Auf beste OPTIK gestellt (alle Effekte an).' }
        } catch { 'Fehler: ' + $_.Exception.Message }
    }
    'ultplan' = {
        try {
            $out = powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61 2>&1 | Out-String
            $g = ''; if ($out -match '([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})') { $g = $Matches[1] }
            if ($g) { powercfg /setactive $g | Out-Null; 'Energieplan "Ultimative Leistung" aktiviert (maximale Performance).' }
            else { 'Konnte den Plan nicht anlegen - evtl. Adminrechte noetig.' }
        } catch { 'Fehler: ' + $_.Exception.Message }
    }
    'hibernateoff' = { try { powercfg /hibernate off 2>&1 | Out-Null; 'Ruhezustand deaktiviert - gibt mehrere GB Speicher frei (hiberfil.sys). Umkehrbar mit "Ruhezustand an".' } catch { 'Fehler (Adminrechte noetig): ' + $_.Exception.Message } }
    'hibernateon'  = { try { powercfg /hibernate on 2>&1 | Out-Null; 'Ruhezustand wieder aktiviert.' } catch { 'Fehler (Adminrechte noetig): ' + $_.Exception.Message } }
    'sysmainoff' = { try { Stop-Service -Name SysMain -Force -ErrorAction SilentlyContinue; Set-Service -Name SysMain -StartupType Disabled -ErrorAction Stop; 'SysMain (Superfetch) deaktiviert - kann auf SSDs Hintergrundlast sparen. Umkehrbar mit "SysMain an".' } catch { 'Fehler (Adminrechte noetig): ' + $_.Exception.Message } }
    'sysmainon'  = { try { Set-Service -Name SysMain -StartupType Automatic -ErrorAction Stop; Start-Service -Name SysMain -ErrorAction SilentlyContinue; 'SysMain wieder aktiviert.' } catch { 'Fehler (Adminrechte noetig): ' + $_.Exception.Message } }
    'cpumax' = {
        try {
            powercfg /setacvalueindex SCHEME_CURRENT SUB_PROCESSOR PROCTHROTTLEMIN 100 | Out-Null
            powercfg /setacvalueindex SCHEME_CURRENT SUB_PROCESSOR PROCTHROTTLEMAX 100 | Out-Null
            powercfg /setacvalueindex SCHEME_CURRENT SUB_PROCESSOR CPMINCORES 100 | Out-Null
            powercfg /setactive SCHEME_CURRENT | Out-Null
            'CPU auf Dauer-Hoechsttakt (min/max 100%, Core-Parking aus). Umkehrbar ueber "Standard".'
        } catch { 'Nicht moeglich (Adminrechte noetig): ' + $_.Exception.Message }
    }
    'usbpower' = {
        param($mode)
        try {
            $v = if ("$mode" -eq 'off') { 0 } else { 1 }
            powercfg /setacvalueindex SCHEME_CURRENT SUB_USB USBSELECTIVESUSPEND $v | Out-Null
            powercfg /setdcvalueindex SCHEME_CURRENT SUB_USB USBSELECTIVESUSPEND $v | Out-Null
            powercfg /setactive SCHEME_CURRENT | Out-Null
            if ($v -eq 0) { 'USB-Energiesparen AUS - Maus/Tastatur/Controller bleiben voll reaktionsschnell.' } else { 'USB-Energiesparen wieder an (Standard).' }
        } catch { 'Nicht moeglich (Adminrechte noetig): ' + $_.Exception.Message }
    }
    'nagleoff' = {
        param($mode)
        try {
            $ifs = 'HKLM:\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces'
            $cnt = 0
            foreach ($i in (Get-ChildItem $ifs -ErrorAction SilentlyContinue)) {
                if ((Get-ItemProperty $i.PSPath -Name 'DhcpIPAddress' -ErrorAction SilentlyContinue) -or (Get-ItemProperty $i.PSPath -Name 'IPAddress' -ErrorAction SilentlyContinue)) {
                    if ("$mode" -eq 'off') { Set-ItemProperty $i.PSPath -Name 'TcpAckFrequency' -Value 1 -Type DWord -Force; Set-ItemProperty $i.PSPath -Name 'TCPNoDelay' -Value 1 -Type DWord -Force }
                    else { Remove-ItemProperty $i.PSPath -Name 'TcpAckFrequency' -ErrorAction SilentlyContinue; Remove-ItemProperty $i.PSPath -Name 'TCPNoDelay' -ErrorAction SilentlyContinue }
                    $cnt++
                }
            }
            if ("$mode" -eq 'off') { "Nagle-Algorithmus deaktiviert auf $cnt Adapter(n) - kann Online-Latenz senken." } else { "Nagle-Standard auf $cnt Adapter(n) wiederhergestellt." }
        } catch { 'Nicht moeglich (Adminrechte noetig): ' + $_.Exception.Message }
    }
    'maxperf' = {
        $done = @(); $fail = @()
        try { $o = powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61 2>&1 | Out-String; $g = ''; if ($o -match '([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})') { $g = $matches[1] }; if ($g) { powercfg /setactive $g | Out-Null; $done += 'Ultimate-Energieplan' } else { powercfg /setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c | Out-Null; $done += 'Hoechstleistung' } } catch { $fail += 'Energieplan' }
        try { powercfg /setacvalueindex SCHEME_CURRENT SUB_PROCESSOR PROCTHROTTLEMIN 100 | Out-Null; powercfg /setacvalueindex SCHEME_CURRENT SUB_PROCESSOR PROCTHROTTLEMAX 100 | Out-Null; powercfg /setacvalueindex SCHEME_CURRENT SUB_PROCESSOR CPMINCORES 100 | Out-Null; powercfg /setacvalueindex SCHEME_CURRENT SUB_USB USBSELECTIVESUSPEND 0 | Out-Null; powercfg /setactive SCHEME_CURRENT | Out-Null; $done += 'CPU 100% + Core-Parking aus + USB voll' } catch { $fail += 'CPU/USB' }
        try { New-Item 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling' -Force -ErrorAction Stop | Out-Null; Set-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling' -Name PowerThrottlingOff -Value 1 -Type DWord -Force; $done += 'Power-Throttling aus' } catch { $fail += 'Power-Throttling' }
        try { Set-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' -Name SystemResponsiveness -Value 0 -Type DWord -ErrorAction Stop; $gt = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games'; if (Test-Path $gt) { Set-ItemProperty $gt -Name 'GPU Priority' -Value 8 -ErrorAction SilentlyContinue; Set-ItemProperty $gt -Name 'Priority' -Value 6 -ErrorAction SilentlyContinue; Set-ItemProperty $gt -Name 'Scheduling Category' -Value 'High' -ErrorAction SilentlyContinue }; $done += 'Spiele-Prioritaet' } catch { $fail += 'Spiele-Prioritaet' }
        try { New-Item 'HKCU:\Software\Microsoft\GameBar' -Force -ErrorAction SilentlyContinue | Out-Null; Set-ItemProperty 'HKCU:\Software\Microsoft\GameBar' -Name AutoGameModeEnabled -Value 1 -Type DWord -ErrorAction SilentlyContinue; Set-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers' -Name HwSchMode -Value 2 -Type DWord -ErrorAction SilentlyContinue; $done += 'Game Mode + HAGS' } catch { $fail += 'Game Mode' }
        try { Set-ItemProperty 'HKCU:\Control Panel\Mouse' -Name MouseSpeed -Value '0' -Force; Set-ItemProperty 'HKCU:\Control Panel\Mouse' -Name MouseThreshold1 -Value '0' -Force; Set-ItemProperty 'HKCU:\Control Panel\Mouse' -Name MouseThreshold2 -Value '0' -Force; Set-ItemProperty 'HKCU:\Control Panel\Keyboard' -Name KeyboardSpeed -Value '31' -Force; Set-ItemProperty 'HKCU:\Control Panel\Keyboard' -Name KeyboardDelay -Value '0' -Force; $done += 'Maus/Tastatur max' } catch { $fail += 'Maus/Tastatur' }
        try {
            $psi = New-Object System.Diagnostics.ProcessStartInfo; $psi.FileName = 'nvidia-smi'; $psi.Arguments = '--query-gpu=power.max_limit --format=csv,noheader,nounits'; $psi.UseShellExecute = $false; $psi.RedirectStandardOutput = $true; $psi.CreateNoWindow = $true
            $pr = [System.Diagnostics.Process]::Start($psi); $o = ''; if ($pr.WaitForExit(3000)) { $o = $pr.StandardOutput.ReadToEnd() }
            $mx = 0; if ($o.Trim() -match '^\d') { $mx = [math]::Round([double]$o.Trim()) }
            if ($mx -gt 0) { $p2 = New-Object System.Diagnostics.ProcessStartInfo; $p2.FileName = 'nvidia-smi'; $p2.Arguments = "-pl $mx"; $p2.UseShellExecute = $false; $p2.CreateNoWindow = $true; $p2.RedirectStandardOutput = $true; $p2.RedirectStandardError = $true; $pp = [System.Diagnostics.Process]::Start($p2); $pp.WaitForExit(5000) | Out-Null; if ($pp.ExitCode -eq 0) { $done += "GPU Power-Limit max ($mx W)" } }
        } catch {}
        $msg = 'AUF MAXIMUM gestellt: ' + ($done -join ', ') + '.'
        if ($fail.Count) { $msg += ' | Fehlgeschlagen (Adminrechte noetig): ' + ($fail -join ', ') + '.' }
        $msg + ' Fuer volle Wirkung: Neustart.'
    }
    'maxperfreset' = {
        $done = @()
        try { powercfg /setactive 381b4222-f694-41f0-9685-ff5bb260df2e | Out-Null; $done += 'Energieplan Ausbalanciert' } catch {}
        try { Remove-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling' -Name PowerThrottlingOff -ErrorAction SilentlyContinue; $done += 'Power-Throttling Standard' } catch {}
        try { powercfg /setacvalueindex SCHEME_CURRENT SUB_USB USBSELECTIVESUSPEND 1 | Out-Null; powercfg /setactive SCHEME_CURRENT | Out-Null; $done += 'USB-Energiesparen an' } catch {}
        try { Set-ItemProperty 'HKCU:\Control Panel\Mouse' -Name MouseSpeed -Value '1' -Force; Set-ItemProperty 'HKCU:\Control Panel\Mouse' -Name MouseThreshold1 -Value '6' -Force; Set-ItemProperty 'HKCU:\Control Panel\Mouse' -Name MouseThreshold2 -Value '10' -Force; $done += 'Maus Standard' } catch {}
        try { Set-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile' -Name SystemResponsiveness -Value 20 -Type DWord -ErrorAction SilentlyContinue; $done += 'Reaktionsfaehigkeit Standard' } catch {}
        'Windows-Standard wiederhergestellt: ' + ($done -join ', ') + '. Ein Neustart schliesst es ab.'
    }
}

# Erlaubte Schnellstart-Ziele (Whitelist)
$LAUNCH = @{
    taskmgr='taskmgr'; devmgmt='devmgmt.msc'; diskmgmt='diskmgmt.msc'; services='services.msc'
    resmon='resmon'; cleanmgr='cleanmgr'; msconfig='msconfig'; control='control'; regedit='regedit'
    powercfg='powercfg.cpl'; display='ms-settings:display'; sound='ms-settings:sound'
    update='ms-settings:windowsupdate'; gaming='ms-settings:gaming-gamemode'
    startup='ms-settings:startupapps'; apps='ms-settings:appsfeatures'
}

# --- Makros & Training-Eintraege ---
# Nachgebaut anhand der Aufrufe der Oberflaeche. Ablage wie bei den
# Benutzerkonten: eine JSON-Datei neben dem Skript.
$macrosFile   = Join-Path $scriptDir 'pcboost-macros.json'
$trainingFile = Join-Path $scriptDir 'pcboost-training.json'

function Get-JsonMap($pfad) {
    if (Test-Path $pfad) {
        try {
            $o = @{}
            (Get-Content $pfad -Raw | ConvertFrom-Json).PSObject.Properties | ForEach-Object { $o[$_.Name] = $_.Value }
            return $o
        } catch {}
    }
    return @{}
}
function Save-JsonMap($pfad, $map) {
    try { ($map | ConvertTo-Json -Depth 6) | Set-Content -Path $pfad -Encoding UTF8; return $true } catch { return $false }
}
function Get-NextId($map) {
    $max = 0
    foreach ($k in $map.Keys) { $n = 0; if ([int]::TryParse("$k", [ref]$n) -and $n -gt $max) { $max = $n } }
    return ($max + 1)
}
# Tastenname -> virtueller Tastencode (fuer die Makro-Wiedergabe)
function Get-VirtualKey($name) {
    if (-not $name) { return 0 }
    $n = "$name".Trim().ToUpper()
    if ($n.Length -eq 1) {
        $c = [int][char]$n
        if (($c -ge 48 -and $c -le 57) -or ($c -ge 65 -and $c -le 90)) { return $c }
    }
    switch ($n) {
        'SPACE'  { return 0x20 }
        'ENTER'  { return 0x0D }
        'TAB'    { return 0x09 }
        'ESC'    { return 0x1B }
        'SHIFT'  { return 0x10 }
        'STRG'   { return 0x11 }
        'CTRL'   { return 0x11 }
        'ALT'    { return 0x12 }
        'UP'     { return 0x26 }
        'DOWN'   { return 0x28 }
        'LEFT'   { return 0x25 }
        'RIGHT'  { return 0x27 }
        'F1'     { return 0x70 }
        'F2'     { return 0x71 }
        'F3'     { return 0x72 }
        'F4'     { return 0x73 }
        'F5'     { return 0x74 }
        'F6'     { return 0x75 }
        'F7'     { return 0x76 }
        'F8'     { return 0x77 }
        default  { return 0 }
    }
}

# --- System-Tweaks (umkehrbare Registry-Schalter) ---
$script:TWEAKS = [ordered]@{
    gamemode     = @{ group='gaming'; path='HKCU:\Software\Microsoft\GameBar'; name='AutoGameModeEnabled'; valOn=1; valOff=0; missingIsOn=$true;  label='Game Mode'; hint='An = Windows priorisiert das Spiel'; reboot=$false }
    gamedvr      = @{ group='gaming'; path='HKCU:\System\GameConfigStore'; name='GameDVR_Enabled'; valOn=1; valOff=0; missingIsOn=$true;  label='Game DVR / Aufnahme'; hint='Aus = mehr FPS'; reboot=$false }
    transparency = @{ group='gaming'; path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Themes\Personalize'; name='EnableTransparency'; valOn=1; valOff=0; missingIsOn=$true; label='Transparenz-Effekte'; hint='Aus = etwas schneller'; reboot=$false }
    hags         = @{ group='gaming'; path='HKLM:\SYSTEM\CurrentControlSet\Control\GraphicsDrivers'; name='HwSchMode'; valOn=2; valOff=1; missingIsOn=$false; label='GPU-Terminplanung (HAGS)'; hint='kann Latenz senken'; reboot=$true }
    bgapps       = @{ group='gaming'; path='HKCU:\Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications'; name='GlobalUserDisabled'; valOn=0; valOff=1; missingIsOn=$true; label='Hintergrund-Apps'; hint='Aus = weniger Hintergrundlast'; reboot=$false }
    telemetry    = @{ group='privacy'; path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\DataCollection'; name='AllowTelemetry'; valOn=1; valOff=0; missingIsOn=$true; label='Telemetrie / Diagnosedaten'; hint='Aus = weniger Datensammlung'; reboot=$false }
    advertising  = @{ group='privacy'; path='HKCU:\Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo'; name='Enabled'; valOn=1; valOff=0; missingIsOn=$true; label='Werbe-ID'; hint='Aus = keine personalisierte Werbung'; reboot=$false }
    suggestions  = @{ group='privacy'; path='HKCU:\Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager'; name='SubscribedContent-338389Enabled'; valOn=1; valOff=0; missingIsOn=$true; label='Windows-Tipps & Vorschlaege'; hint='Aus = weniger Werbung im System'; reboot=$false }
    activityhist = @{ group='privacy'; path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\System'; name='EnableActivityFeed'; valOn=1; valOff=0; missingIsOn=$true; label='Aktivitaetsverlauf / Timeline'; hint='Aus = keine Aktivitaets-Aufzeichnung'; reboot=$false }
    location     = @{ group='privacy'; path='HKLM:\SYSTEM\CurrentControlSet\Services\lfsvc\Service\Configuration'; name='Status'; valOn=1; valOff=0; missingIsOn=$true; label='Standort-Dienst'; hint='Aus = kein Standort-Tracking'; reboot=$false }
    tailored     = @{ group='privacy'; path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Privacy'; name='TailoredExperiencesWithDiagnosticDataEnabled'; valOn=1; valOff=0; missingIsOn=$true; label='Massgeschneiderte Erlebnisse'; hint='Aus = keine personalisierten Inhalte'; reboot=$false }
    feedback     = @{ group='privacy'; path='HKCU:\Software\Microsoft\Siuf\Rules'; name='NumberOfSIUFInPeriod'; valOn=1; valOff=0; missingIsOn=$true; label='Feedback-Anfragen'; hint='Aus = Windows fragt kein Feedback'; reboot=$false }
    cloudclip    = @{ group='privacy'; path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\System'; name='AllowCrossDeviceClipboard'; valOn=1; valOff=0; missingIsOn=$true; label='Cloud-Zwischenablage (Sync)'; hint='Aus = Zwischenablage bleibt lokal'; reboot=$false }
    bingsearch   = @{ group='privacy'; path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Search'; name='BingSearchEnabled'; valOn=1; valOff=0; missingIsOn=$true; label='Web-/Bing-Suche im Startmenue'; hint='Aus = keine Web-Suche-Uebertragung'; reboot=$false }
    tbalign      = @{ group='personalize'; path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; name='TaskbarAl'; valOn=1; valOff=0; missingIsOn=$true; label='Taskleiste zentriert'; hint='Aus = linksbuendig (wie Win10). Explorer-Neustart noetig'; reboot=$false }
    tbsearch     = @{ group='personalize'; path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Search'; name='SearchboxTaskbarMode'; valOn=1; valOff=0; missingIsOn=$true; label='Such-Symbol in Taskleiste'; hint='Aus = kein Suchfeld/-Symbol'; reboot=$false }
    tbwidgets    = @{ group='personalize'; path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; name='TaskbarDa'; valOn=1; valOff=0; missingIsOn=$true; label='Widgets-Button'; hint='Aus = weg aus der Taskleiste'; reboot=$false }
    tbtaskview   = @{ group='personalize'; path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; name='ShowTaskViewButton'; valOn=1; valOff=0; missingIsOn=$true; label='Task-Ansicht-Button'; hint='Aus = weg aus der Taskleiste'; reboot=$false }
    fileext      = @{ group='personalize'; path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; name='HideFileExt'; valOn=0; valOff=1; missingIsOn=$false; label='Dateiendungen anzeigen'; hint='An = du siehst .exe/.txt usw. (sicherer)'; reboot=$false }
    hiddenfiles  = @{ group='personalize'; path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; name='Hidden'; valOn=1; valOff=2; missingIsOn=$false; label='Versteckte Dateien anzeigen'; hint='An = versteckte Ordner/Dateien sichtbar'; reboot=$false }
    launchtopc   = @{ group='personalize'; path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; name='LaunchTo'; valOn=1; valOff=2; missingIsOn=$false; label='Explorer oeffnet "Dieser PC"'; hint='An = statt Schnellzugriff'; reboot=$false }
    tbanim       = @{ group='personalize'; path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'; name='TaskbarAnimations'; valOn=1; valOff=0; missingIsOn=$true; label='Fenster-Animationen'; hint='Aus = wirkt schneller/snappiger'; reboot=$false }

    # --- Mehr FPS ---
    fse          = @{ group='fps'; path='HKCU:\System\GameConfigStore'; name='GameDVR_FSEBehaviorMode'; valOn=0; valOff=2; missingIsOn=$true;  label='Vollbild-Optimierungen'; hint='Aus = echtes Vollbild, meist stabilere Frametimes'; reboot=$false }
    appcapture   = @{ group='fps'; path='HKCU:\Software\Microsoft\Windows\CurrentVersion\GameDVR'; name='AppCaptureEnabled'; valOn=1; valOff=0; missingIsOn=$true;  label='Xbox Game Bar Aufnahme'; hint='Aus = Aufnahme-Overlay kostet keine Leistung mehr'; reboot=$false }
    gpuprio      = @{ group='fps'; path='HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games'; name='GPU Priority'; valOn=8; valOff=2; missingIsOn=$false; label='GPU-Prioritaet fuer Spiele'; hint='An = Spiele bekommen die GPU zuerst (Adminrechte)'; reboot=$true }
    gamesprio    = @{ group='fps'; path='HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games'; name='Priority'; valOn=6; valOff=2; missingIsOn=$false; label='CPU-Prioritaet fuer Spiele'; hint='An = Spiele werden bevorzugt eingeplant (Adminrechte)'; reboot=$true }
    visualfx     = @{ group='fps'; path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects'; name='VisualFXSetting'; valOn=2; valOff=0; missingIsOn=$false; label='Optik auf Leistung trimmen'; hint='An = Schatten und Animationen aus, mehr Rechenzeit fuers Spiel'; reboot=$false }

    # --- Weniger Input-Lag und Latenz ---
    sysresp      = @{ group='latency'; path='HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile'; name='SystemResponsiveness'; valOn=10; valOff=20; missingIsOn=$false; label='Reaktionszeit-Reserve'; hint='An = Windows haelt weniger CPU zurueck (Adminrechte)'; reboot=$true }
    # -1 wird als DWord 0xFFFFFFFF gespeichert und auch wieder als -1 gelesen.
    # 4294967295 waere zwar derselbe Wert, kaeme beim Auslesen aber als -1 zurueck
    # und der Schalter wuerde dauerhaft "aus" anzeigen.
    netthrottle  = @{ group='latency'; path='HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile'; name='NetworkThrottlingIndex'; valOn=-1; valOff=10; missingIsOn=$false; label='Netzwerk-Drosselung aus'; hint='An = keine kuenstliche Paketbremse, spuerbar in Online-Spielen (Adminrechte)'; reboot=$true }
    prioctrl     = @{ group='latency'; path='HKLM:\SYSTEM\CurrentControlSet\Control\PriorityControl'; name='Win32PrioritySeparation'; valOn=38; valOff=2; missingIsOn=$false; label='Vordergrund bevorzugen'; hint='An = aktives Fenster bekommt mehr CPU-Zeit (Adminrechte)'; reboot=$true }
    powerthrott  = @{ group='latency'; path='HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling'; name='PowerThrottlingOff'; valOn=1; valOff=0; missingIsOn=$false; label='Energie-Drosselung aus'; hint='An = CPU wird nicht heruntergetaktet, mehr Verbrauch (Adminrechte)'; reboot=$true }

    # --- Verbesserte PC-Sicherheit ---
    smartscreen  = @{ group='security'; path='HKLM:\SOFTWARE\Policies\Microsoft\Windows\System'; name='EnableSmartScreen'; valOn=1; valOff=0; missingIsOn=$false; label='SmartScreen-Schutz'; hint='An = Windows warnt vor unbekannten Downloads (Adminrechte)'; reboot=$false }
    rdp          = @{ group='security'; path='HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server'; name='fDenyTSConnections'; valOn=1; valOff=0; missingIsOn=$true;  label='Remotedesktop gesperrt'; hint='An = niemand kann sich per RDP aufschalten (Adminrechte)'; reboot=$false }
    autorun      = @{ group='security'; path='HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer'; name='NoDriveTypeAutoRun'; valOn=255; valOff=145; missingIsOn=$false; label='Autostart von USB-Sticks aus'; hint='An = eingesteckte Medien starten nichts von allein (Adminrechte)'; reboot=$false }
    llmnr        = @{ group='security'; path='HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\DNSClient'; name='EnableMulticast'; valOn=0; valOff=1; missingIsOn=$false; label='LLMNR abgeschaltet'; hint='An = schliesst einen bekannten Weg zum Abgreifen von Zugangsdaten (Adminrechte)'; reboot=$true }

    # --- Windows-Optimierungen ---
    faststartup  = @{ group='windows'; path='HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power'; name='HiberbootEnabled'; valOn=1; valOff=0; missingIsOn=$true;  label='Schnellstart'; hint='Aus = sauberer Kaltstart, behebt viele Treiber-Macken (Adminrechte)'; reboot=$true }
    startupdelay = @{ group='windows'; path='HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize'; name='StartupDelayInMSec'; valOn=0; valOff=1; missingIsOn=$false; label='Autostart-Verzoegerung aus'; hint='An = Autostart-Programme starten sofort statt verzoegert'; reboot=$true }
    clearpagefile= @{ group='windows'; path='HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management'; name='ClearPageFileAtShutdown'; valOn=0; valOff=1; missingIsOn=$true;  label='Auslagerungsdatei nicht loeschen'; hint='An = deutlich schnelleres Herunterfahren (Adminrechte)'; reboot=$true }
    storagesense = @{ group='windows'; path='HKCU:\Software\Microsoft\Windows\CurrentVersion\StorageSense\Parameters\StoragePolicy'; name='01'; valOn=1; valOff=0; missingIsOn=$false; label='Speicheroptimierung'; hint='An = Windows raeumt Temp und Papierkorb selbst auf'; reboot=$false }

    # --- Allgemeine Performance- und System-Tweaks ---
    sysmain      = @{ group='perf'; path='HKLM:\SYSTEM\CurrentControlSet\Services\SysMain'; name='Start'; valOn=2; valOff=4; missingIsOn=$true;  label='SysMain / Superfetch'; hint='Aus = weniger Dauerlast auf SSDs. Bei Festplatten lieber an lassen (Adminrechte)'; reboot=$true }
    searchindex  = @{ group='perf'; path='HKLM:\SYSTEM\CurrentControlSet\Services\WSearch'; name='Start'; valOn=2; valOff=4; missingIsOn=$true;  label='Suchindizierung'; hint='Aus = weniger Hintergrundlast, dafuer langsamere Dateisuche (Adminrechte)'; reboot=$true }
    prefetcher   = @{ group='perf'; path='HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters'; name='EnablePrefetcher'; valOn=3; valOff=0; missingIsOn=$true;  label='Prefetcher'; hint='Aus nur bei SSD sinnvoll. Bei Festplatten an lassen (Adminrechte)'; reboot=$true }
    # Hinweis: Schalter unter "HKCU:\Control Panel\Desktop" (z.B. AutoEndTasks,
    # MenuShowDelay, Maus-Beschleunigung) sind REG_SZ-Textwerte. Set-TweakByKey
    # schreibt ausschliesslich DWord - sie wuerden mit falschem Typ landen und
    # von Windows ignoriert. Deshalb bewusst nicht aufgenommen.
}
function Read-RegVal($path, $name) { try { return (Get-ItemProperty -Path $path -Name $name -ErrorAction Stop).$name } catch { return $null } }
function Get-TweakStatus {
    $tw = @()
    foreach ($k in $script:TWEAKS.Keys) {
        $t = $script:TWEAKS[$k]
        $v = Read-RegVal $t.path $t.name
        $state = if ($null -eq $v) { if ($t.missingIsOn) { 'an' } else { 'aus' } } elseif ([int]$v -eq $t.valOn) { 'an' } else { 'aus' }
        $tw += [ordered]@{ key=$k; group=$t.group; label=$t.label; hint=$t.hint; reboot=$t.reboot; state=$state }
    }
    $active = ''
    $ap = powercfg /getactivescheme
    if ($ap -match '([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})') { $active = $Matches[1] }
    $plans = @(
        [ordered]@{ name='Ausbalanciert';   guid='381b4222-f694-41f0-9685-ff5bb260df2e' },
        [ordered]@{ name='Hoechstleistung'; guid='8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c' }
    ) | ForEach-Object { [ordered]@{ name=$_.name; guid=$_.guid; active=($_.guid -eq $active) } }
    return [ordered]@{ tweaks=$tw; plans=$plans }
}
# --- Aenderungsprotokoll fuer Schalter ---------------------------------
# Haelt fest, was wann umgestellt wurde und welchen Wert die Registry
# vorher hatte. Damit laesst sich jede Aenderung einzeln oder alles
# zusammen wieder zuruecknehmen.
$tweakLogFile = Join-Path $scriptDir 'pcboost-tweaklog.json'

function Get-TweakLog {
    if (Test-Path $tweakLogFile) {
        try {
            $o = Get-Content $tweakLogFile -Raw | ConvertFrom-Json
            if ($null -eq $o) { return @() }
            # ConvertFrom-Json liefert ein JSON-Array als EIN Objekt, nicht als
            # einzelne Pipeline-Elemente. Ein blosses @(...) erzeugt daraus ein
            # verschachteltes Array - dann verschmelzen beim Auslesen alle
            # Eintraege zu einem einzigen mit Array-Werten. Deshalb auspacken.
            $flach = @()
            foreach ($x in $o) { $flach += $x }
            return $flach
        } catch {}
    }
    return @()
}
function Add-TweakLogEntry($key, $label, $altWert, $neuWert) {
    $log = @(Get-TweakLog)
    $log += [ordered]@{
        key   = $key
        label = $label
        alt   = $altWert      # $null bedeutet: Wert war vorher gar nicht gesetzt
        neu   = $neuWert
        zeit  = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
    }
    if ($log.Count -gt 300) { $log = $log[($log.Count - 300)..($log.Count - 1)] }
    try { ($log | ConvertTo-Json -Depth 4) | Set-Content -Path $tweakLogFile -Encoding UTF8 } catch {}
}
function Restore-TweakValue($key, $wert) {
    $t = $script:TWEAKS[$key]
    if (-not $t) { return $false }
    try {
        if ($null -eq $wert -or "$wert" -eq '') {
            # Wert existierte vorher nicht - also wieder entfernen statt 0 zu schreiben
            Remove-ItemProperty -Path $t.path -Name $t.name -Force -ErrorAction SilentlyContinue
        } else {
            if (-not (Test-Path $t.path)) { New-Item -Path $t.path -Force | Out-Null }
            New-ItemProperty -Path $t.path -Name $t.name -Value ([int]$wert) -PropertyType DWord -Force | Out-Null
        }
        return $true
    } catch { return $false }
}
function Undo-AllTweaks {
    # Je Schalter den AELTESTEN protokollierten Wert wiederherstellen -
    # das ist der Zustand vor der allerersten Aenderung.
    $log = @(Get-TweakLog)
    if ($log.Count -eq 0) { return @{ ok = 0; fehl = 0; leer = $true } }
    $ersteWerte = [ordered]@{}
    foreach ($e in $log) { if (-not $ersteWerte.Contains($e.key)) { $ersteWerte[$e.key] = $e.alt } }
    $ok = 0; $fehl = 0
    foreach ($k in $ersteWerte.Keys) {
        if (Restore-TweakValue $k $ersteWerte[$k]) { $ok++ } else { $fehl++ }
    }
    try { Remove-Item $tweakLogFile -Force -ErrorAction SilentlyContinue } catch {}
    return @{ ok = $ok; fehl = $fehl; leer = $false }
}

# --- Wirkungsnachweis: hat eine Umstellung messbar etwas gebracht? -----
# Vergleicht die Messwerte aus dem Verlauf vor und nach dem Zeitpunkt
# einer Aenderung. Bewusst konservativ: Unterschiede werden erst dann als
# solche bezeichnet, wenn sie groesser sind als die normale Schwankung.
function Get-HistoryRows {
    $rows = @()
    if (-not (Test-Path $histFile)) { return $rows }
    try {
        foreach ($z in @(Get-Content $histFile -ErrorAction SilentlyContinue)) {
            $s = "$z".Split(',')
            if ($s.Count -lt 6) { continue }
            $m = 0; if (-not [int]::TryParse($s[0], [ref]$m)) { continue }
            $rows += ,@([int]$m, [int]$s[1], [int]$s[2], [int]$s[3], [int]$s[4], [int]$s[5])
        }
    } catch {}
    return $rows
}
function Measure-HistWindow($rows, $von, $bis, $idx) {
    $werte = @()
    foreach ($r in $rows) {
        if ($r[0] -ge $von -and $r[0] -lt $bis -and $r[$idx] -ge 0) { $werte += [double]$r[$idx] }
    }
    if ($werte.Count -eq 0) { return $null }
    $mw = ($werte | Measure-Object -Average).Average
    $sd = 0.0
    if ($werte.Count -gt 1) {
        $sum = 0.0
        foreach ($w in $werte) { $sum += [math]::Pow($w - $mw, 2) }
        $sd = [math]::Sqrt($sum / ($werte.Count - 1))
    }
    return @{ n = $werte.Count; mittel = [math]::Round($mw, 1); streuung = [math]::Round($sd, 1) }
}
function Get-TweakEffect($logIndex, $fensterMin) {
    $log = @(Get-TweakLog)
    if ($logIndex -lt 0 -or $logIndex -ge $log.Count) { return @{ ok = $false; msg = 'Eintrag nicht gefunden.' } }
    $e = $log[$logIndex]
    $t0 = 0
    try {
        $dt = [datetime]::ParseExact("$($e.zeit)", 'yyyy-MM-dd HH:mm:ss', [Globalization.CultureInfo]::InvariantCulture)
        $t0 = [int][math]::Floor(($dt.ToUniversalTime() - (New-Object DateTime(1970,1,1,0,0,0,[DateTimeKind]::Utc))).TotalMinutes)
    } catch { return @{ ok = $false; msg = 'Zeitstempel des Eintrags ist unlesbar.' } }

    if ($fensterMin -lt 5)   { $fensterMin = 30 }
    if ($fensterMin -gt 240) { $fensterMin = 240 }

    $rows = Get-HistoryRows
    $namen = @(
        @{ idx = 1; name = 'CPU-Auslastung'; einheit = '%' },
        @{ idx = 2; name = 'RAM-Auslastung'; einheit = '%' },
        @{ idx = 3; name = 'GPU-Auslastung'; einheit = '%' },
        @{ idx = 4; name = 'CPU-Temperatur'; einheit = ' Grad' },
        @{ idx = 5; name = 'GPU-Temperatur'; einheit = ' Grad' }
    )
    $erg = @()
    foreach ($m in $namen) {
        $v = Measure-HistWindow $rows ($t0 - $fensterMin) $t0 $m.idx
        $n = Measure-HistWindow $rows ($t0 + 1) ($t0 + 1 + $fensterMin) $m.idx
        $nv = if ($v) { $v.n } else { 0 }
        $nn = if ($n) { $n.n } else { 0 }
        # Unter 5 Messwerten je Seite ist jede Aussage Kaffeesatzleserei
        if (-not $v -or -not $n -or $nv -lt 5 -or $nn -lt 5) {
            $erg += [ordered]@{ name = $m.name; einheit = $m.einheit; genug = $false; nVor = $nv; nNach = $nn }
            continue
        }
        $diff = [math]::Round($n.mittel - $v.mittel, 1)
        # Standardfehler der Differenz - daran messen wir, ob der
        # Unterschied ueberhaupt aus dem Rauschen herausragt.
        $se = [math]::Sqrt((($v.streuung * $v.streuung) / $nv) + (($n.streuung * $n.streuung) / $nn))
        $urteil = 'kein Unterschied erkennbar'
        if ($se -gt 0) {
            if ([math]::Abs($diff) -gt 2 * $se)   { $urteil = 'deutlicher Unterschied' }
            elseif ([math]::Abs($diff) -gt $se)   { $urteil = 'schwacher Hinweis' }
        } elseif ($diff -ne 0) { $urteil = 'Unterschied vorhanden' }
        $erg += [ordered]@{
            name = $m.name; einheit = $m.einheit; genug = $true
            nVor = $nv; nNach = $nn
            vor = $v.mittel; nach = $n.mittel
            streuungVor = $v.streuung; streuungNach = $n.streuung
            diff = $diff; urteil = $urteil
        }
    }
    return @{
        ok = $true
        label = "$($e.label)"; key = "$($e.key)"; zeit = "$($e.zeit)"
        fenster = $fensterMin
        werte = @($erg)
    }
}

# --- Empfohlene Grundeinstellung ---------------------------------------
# Bewusst konservativ gewaehlt: kein Neustart noetig, keine Dienste
# angefasst, keine Optik veraendert. Alles landet im Aenderungsprotokoll
# und laesst sich mit einem Klick zurueckdrehen.
$script:EMPFOHLEN = [ordered]@{
    gamemode    = 'an'      # Windows priorisiert das Spiel
    gamedvr     = 'aus'     # Hintergrundaufnahme kostet FPS
    appcapture  = 'aus'     # dito, Xbox Game Bar
    bgapps      = 'aus'     # weniger Hintergrundlast
    telemetry   = 'aus'     # weniger Datensammlung (Adminrechte)
    advertising = 'aus'     # Werbe-ID
    suggestions = 'aus'     # Vorschlaege im Startmenue
    tailored    = 'aus'     # personalisierte Inhalte
    feedback    = 'aus'     # Feedback-Abfragen
    bingsearch  = 'aus'     # Web-Suche im Startmenue
    fileext     = 'an'      # Dateiendungen sichtbar = sicherer
}
function Set-RecommendedTweaks {
    $geaendert = 0; $schon = 0; $fehl = 0; $details = @()
    foreach ($k in $script:EMPFOHLEN.Keys) {
        $t = $script:TWEAKS[$k]
        if (-not $t) { continue }
        $soll = "$($script:EMPFOHLEN[$k])"
        $ist  = Get-TweakState $t
        if ($ist -eq $soll) { $schon++; $details += "$($t.label): war bereits $soll"; continue }
        $r = Set-TweakByKey $k
        if ("$r" -eq 'OK') { $geaendert++; $details += "$($t.label): $ist -> $soll" }
        else { $fehl++; $details += "$($t.label): fehlgeschlagen (Adminrechte noetig?)" }
    }
    return @{ geaendert = $geaendert; schon = $schon; fehl = $fehl; details = @($details) }
}

# --- Auffaelligkeiten aus dem Langzeit-Verlauf -------------------------
# Wandelt die Kurven in Saetze um: laengste Phase ueber einer Schwelle,
# Spitzenwert mit Uhrzeit, Durchschnitt.
function Get-HistoryFindings($stunden) {
    if ($stunden -lt 1) { $stunden = 24 }
    if ($stunden -gt 168) { $stunden = 168 }
    $rows = Get-HistoryRows
    $jetzt = [int][math]::Floor(((Get-Date).ToUniversalTime() - (New-Object DateTime(1970,1,1,0,0,0,[DateTimeKind]::Utc))).TotalMinutes)
    $ab = $jetzt - ($stunden * 60)
    $rows = @($rows | Where-Object { $_[0] -ge $ab })
    if ($rows.Count -lt 10) {
        return @{ ok = $false; msg = "Zu wenig Aufzeichnung fuer die letzten $stunden Stunden ($($rows.Count) Messpunkte). Der Verlauf fuellt sich mit jeder Minute Laufzeit."; punkte = $rows.Count }
    }
    $defs = @(
        @{ idx=1; name='CPU-Auslastung'; einheit='%';    hoch=85; dauer=10 },
        @{ idx=2; name='RAM-Auslastung'; einheit='%';    hoch=90; dauer=10 },
        @{ idx=3; name='GPU-Auslastung'; einheit='%';    hoch=90; dauer=10 },
        @{ idx=4; name='CPU-Temperatur'; einheit=' Grad'; hoch=85; dauer=5 },
        @{ idx=5; name='GPU-Temperatur'; einheit=' Grad'; hoch=83; dauer=5 }
    )
    $funde = @()
    foreach ($d in $defs) {
        $werte = @($rows | Where-Object { $_[$d.idx] -ge 0 })
        if ($werte.Count -lt 10) { continue }
        $mittel = [math]::Round((($werte | ForEach-Object { $_[$d.idx] }) | Measure-Object -Average).Average, 1)
        $spitze = 0; $spitzeMin = 0
        foreach ($r in $werte) { if ($r[$d.idx] -gt $spitze) { $spitze = $r[$d.idx]; $spitzeMin = $r[0] } }
        # laengste zusammenhaengende Phase oberhalb der Schwelle
        $lauf = 0; $besterLauf = 0; $besterStart = 0; $start = 0
        foreach ($r in $werte) {
            if ($r[$d.idx] -ge $d.hoch) {
                if ($lauf -eq 0) { $start = $r[0] }
                $lauf++
                if ($lauf -gt $besterLauf) { $besterLauf = $lauf; $besterStart = $start }
            } else { $lauf = 0 }
        }
        $sZeit = (New-Object DateTime(1970,1,1,0,0,0,[DateTimeKind]::Utc)).AddMinutes($spitzeMin).ToLocalTime()
        $eintrag = [ordered]@{
            name = $d.name; einheit = $d.einheit
            mittel = $mittel
            spitze = $spitze; spitzeZeit = $sZeit.ToString('dd.MM. HH:mm')
            schwelle = $d.hoch
            minutenHoch = $besterLauf
            auffaellig = ($besterLauf -ge $d.dauer)
        }
        if ($besterLauf -ge $d.dauer) {
            $bZeit = (New-Object DateTime(1970,1,1,0,0,0,[DateTimeKind]::Utc)).AddMinutes($besterStart).ToLocalTime()
            $eintrag.text = "$($d.name) lag $besterLauf Minuten am Stueck ueber $($d.hoch)$($d.einheit) - ab $($bZeit.ToString('dd.MM. HH:mm'))."
        } else {
            $eintrag.text = "$($d.name) unauffaellig: im Mittel $mittel$($d.einheit), Spitze $spitze$($d.einheit) am $($sZeit.ToString('dd.MM. HH:mm'))."
        }
        $funde += $eintrag
    }
    return @{ ok = $true; stunden = $stunden; punkte = $rows.Count; funde = @($funde) }
}

# --- Profil: alle Schalterstellungen sichern und uebertragen ------------
function Get-TweakState($t) {
    $v = Read-RegVal $t.path $t.name
    if ($null -eq $v) { if ($t.missingIsOn) { return 'an' } else { return 'aus' } }
    if ([int]$v -eq $t.valOn) { return 'an' } else { return 'aus' }
}
function Export-TweakProfile {
    $items = [ordered]@{}
    foreach ($k in $script:TWEAKS.Keys) { $items[$k] = (Get-TweakState $script:TWEAKS[$k]) }
    $plan = ''
    try { $ap = powercfg /getactivescheme; if ($ap -match '([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})') { $plan = $Matches[1] } } catch {}
    return [ordered]@{
        typ      = 'pcboost-profil'
        version  = 1
        erstellt = (Get-Date).ToString('yyyy-MM-dd HH:mm')
        pc       = "$env:COMPUTERNAME"
        plan     = $plan
        schalter = $items
    }
}
function Import-TweakProfile($profil) {
    if (-not $profil -or "$($profil.typ)" -ne 'pcboost-profil') {
        return @{ ok = $false; msg = 'Das ist keine gueltige PC-Boost-Profildatei.' }
    }
    $gesetzt = 0; $schon = 0; $unbekannt = 0
    $props = @()
    if ($profil.schalter -is [hashtable]) { $props = $profil.schalter.Keys | ForEach-Object { @{ Name = $_; Value = $profil.schalter[$_] } } }
    else { $props = $profil.schalter.PSObject.Properties | ForEach-Object { @{ Name = $_.Name; Value = $_.Value } } }
    foreach ($p in $props) {
        $k = "$($p.Name)"; $soll = "$($p.Value)"
        $t = $script:TWEAKS[$k]
        if (-not $t) { $unbekannt++; continue }
        if ((Get-TweakState $t) -eq $soll) { $schon++; continue }
        [void](Set-TweakByKey $k)   # schaltet um und protokolliert die Aenderung
        $gesetzt++
    }
    $planTxt = ''
    if ($profil.plan) {
        try { powercfg /setactive "$($profil.plan)" 2>&1 | Out-Null; $planTxt = ' Energieplan uebernommen.' } catch {}
    }
    return @{
        ok  = $true
        msg = "$gesetzt geaendert, $schon waren bereits richtig" + $(if ($unbekannt) { ", $unbekannt unbekannt uebersprungen" } else { '' }) + '.' + $planTxt
    }
}

function Set-TweakByKey($key) {
    $t = $script:TWEAKS[$key]
    if (-not $t) { return 'Unbekannter Schalter.' }
    $v = Read-RegVal $t.path $t.name
    $cur = if ($null -eq $v) { [bool]$t.missingIsOn } else { [int]$v -eq $t.valOn }
    $newVal = if ($cur) { $t.valOff } else { $t.valOn }
    try {
        if (-not (Test-Path $t.path)) { New-Item -Path $t.path -Force | Out-Null }
        New-ItemProperty -Path $t.path -Name $t.name -Value $newVal -PropertyType DWord -Force | Out-Null
        Add-TweakLogEntry $key $t.label $v $newVal
        return "OK"
    } catch { return ("Fehler (evtl. Adminrechte noetig): " + $_.Exception.Message) }
}

# --- Telemetrie-Domains ueber hosts-Datei blockieren (umkehrbar) ---
$script:hostsFile = Join-Path $env:WINDIR 'System32\drivers\etc\hosts'
$script:TELEMETRY_HOSTS = @(
    'vortex.data.microsoft.com','vortex-win.data.microsoft.com','telecommand.telemetry.microsoft.com',
    'oca.telemetry.microsoft.com','sqm.telemetry.microsoft.com','watson.telemetry.microsoft.com',
    'redir.metaservices.microsoft.com','df.telemetry.microsoft.com','reports.wes.df.telemetry.microsoft.com',
    'services.wes.df.telemetry.microsoft.com','telemetry.microsoft.com','telemetry.appex.bing.net',
    'telemetry.urs.microsoft.com','settings-sandbox.data.microsoft.com','vortex-sandbox.data.microsoft.com',
    'statsfe2.ws.microsoft.com','statsfe1.ws.microsoft.com','i1.services.social.microsoft.com'
)
function Get-HostsStatus {
    $blocked = $false
    if (Test-Path $script:hostsFile) {
        try { $blocked = ((Get-Content $script:hostsFile -Raw) -match '# PCBOOST-START') } catch {}
    }
    return @{ blocked = $blocked; count = $script:TELEMETRY_HOSTS.Count }
}
function Set-HostsBlock($on) {
    try {
        $content = if (Test-Path $script:hostsFile) { Get-Content $script:hostsFile -Raw } else { '' }
        # bestehenden PC-Boost-Block entfernen (idempotent)
        $content = [regex]::Replace($content, '(?ms)\r?\n?# PCBOOST-START.*?# PCBOOST-END\r?\n?', '')
        if ($on) {
            $block = "`r`n# PCBOOST-START (Telemetrie blockiert - von PC Boost, dieser Block kann geloescht werden)`r`n"
            foreach ($h in $script:TELEMETRY_HOSTS) { $block += "0.0.0.0 $h`r`n" }
            $block += "# PCBOOST-END`r`n"
            $content = $content.TrimEnd() + "`r`n" + $block
        }
        Set-Content -Path $script:hostsFile -Value $content -Encoding ASCII -Force
        ipconfig /flushdns | Out-Null
        if ($on) { return "$($script:TELEMETRY_HOSTS.Count) Telemetrie-Domains blockiert (umkehrbar)." }
        else     { return "Blockierung entfernt." }
    } catch { return 'Fehler (Adminrechte noetig): ' + $_.Exception.Message }
}

# --- Autostart-Verwaltung (wie Task-Manager, umkehrbar) ---
function Get-StartupEnabledFlag($saPath, $name) {
    try { $v = (Get-ItemProperty -Path $saPath -Name $name -ErrorAction Stop).$name; if ($v -and ($v[0] -band 1)) { return $false }; return $true } catch { return $true }
}
function Get-StartupList {
    $items = @()
    $srcs = @(
        @{ run='HKCU:\Software\Microsoft\Windows\CurrentVersion\Run'; sa='HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run'; scope='hkcu' },
        @{ run='HKLM:\Software\Microsoft\Windows\CurrentVersion\Run'; sa='HKLM:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run'; scope='hklm' }
    )
    foreach ($s in $srcs) {
        if (Test-Path $s.run) {
            (Get-ItemProperty $s.run).PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' } | ForEach-Object {
                $items += [ordered]@{ name=$_.Name; cmd=("$($_.Value)"); enabled=(Get-StartupEnabledFlag $s.sa $_.Name); scope=$s.scope }
            }
        }
    }
    return @{ items = $items }
}
function Set-StartupEntry($scope, $name, $enabled) {
    $sa = if ($scope -eq 'hklm') { 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run' } else { 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run' }
    try {
        if (-not (Test-Path $sa)) { New-Item -Path $sa -Force | Out-Null }
        $b = New-Object byte[] 12
        $b[0] = if ($enabled) { 2 } else { 3 }
        New-ItemProperty -Path $sa -Name $name -Value $b -PropertyType Binary -Force | Out-Null
        return "OK"
    } catch { return ("Fehler (evtl. Adminrechte noetig): " + $_.Exception.Message) }
}

# --- Bloatware (kuratierte, sichere Liste vorinstallierter Apps) ---
$script:BLOAT = @(
    @{ pkg='Microsoft.BingNews'; label='Bing News'; risky=$false }
    @{ pkg='Microsoft.BingWeather'; label='Wetter'; risky=$false }
    @{ pkg='Microsoft.ZuneMusic'; label='Groove Musik'; risky=$false }
    @{ pkg='Microsoft.ZuneVideo'; label='Filme & TV'; risky=$false }
    @{ pkg='Microsoft.MicrosoftSolitaireCollection'; label='Solitaire Collection'; risky=$false }
    @{ pkg='Microsoft.People'; label='Kontakte (People)'; risky=$false }
    @{ pkg='Microsoft.windowscommunicationsapps'; label='Mail & Kalender'; risky=$false }
    @{ pkg='Microsoft.YourPhone'; label='Smartphone-Link'; risky=$false }
    @{ pkg='Microsoft.GetHelp'; label='Hilfe anfordern'; risky=$false }
    @{ pkg='Microsoft.Getstarted'; label='Tipps'; risky=$false }
    @{ pkg='Microsoft.MicrosoftOfficeHub'; label='Office-Hub'; risky=$false }
    @{ pkg='Microsoft.SkypeApp'; label='Skype'; risky=$false }
    @{ pkg='Microsoft.Todos'; label='Microsoft To Do'; risky=$false }
    @{ pkg='Clipchamp.Clipchamp'; label='Clipchamp Video-Editor'; risky=$false }
    @{ pkg='Microsoft.PowerAutomateDesktop'; label='Power Automate'; risky=$false }
    @{ pkg='Microsoft.XboxGamingOverlay'; label='Xbox Game Bar'; risky=$true }
)
function Get-BloatList {
    $installed = Get-AppxPackage | Select-Object -ExpandProperty Name
    $list = @()
    foreach ($b in $script:BLOAT) { if ($installed -contains $b.pkg) { $list += [ordered]@{ pkg=$b.pkg; label=$b.label; risky=$b.risky } } }
    return @{ apps = $list }
}

# Aktionen, die nur intern angestossen werden duerfen - nie direkt ueber
# /api/run?a=... . 'runcmd' fuehrt seinen Parameter mit cmd /c aus.
$script:INTERN = @('runcmd')

# --- Befehls-Bibliothek & Fixes (serverseitige Whitelist; Client waehlt per ID) ---
$script:RUNCMDS = @(
    # CMD-Bibliothek
    [ordered]@{ id='c1';  grp='cmd'; cat='Netzwerk'; label='IP-Konfiguration';        desc='Alle Netzwerkdetails anzeigen';         cmd='ipconfig /all';                              slow=$false; reboot=$false }
    [ordered]@{ id='c2';  grp='cmd'; cat='Netzwerk'; label='DNS-Cache leeren';         desc='Zwischengespeicherte DNS-Eintraege loeschen'; cmd='ipconfig /flushdns';                    slow=$false; reboot=$false }
    [ordered]@{ id='c3';  grp='cmd'; cat='Netzwerk'; label='Ping Google DNS';          desc='Verbindungstest zu 8.8.8.8';            cmd='ping -n 4 8.8.8.8';                           slow=$false; reboot=$false }
    [ordered]@{ id='c4';  grp='cmd'; cat='Netzwerk'; label='Aktive Verbindungen';      desc='Offene Ports und Verbindungen';         cmd='netstat -ano';                                slow=$false; reboot=$false }
    [ordered]@{ id='c5';  grp='cmd'; cat='Netzwerk'; label='WLAN-Profile';             desc='Gespeicherte WLAN-Netze auflisten';     cmd='netsh wlan show profiles';                    slow=$false; reboot=$false }
    [ordered]@{ id='c6';  grp='cmd'; cat='System';   label='Systeminfo';               desc='Ausfuehrliche Systemdaten';             cmd='systeminfo';                                  slow=$true;  reboot=$false }
    [ordered]@{ id='c7';  grp='cmd'; cat='System';   label='Laufende Prozesse';        desc='Alle laufenden Tasks';                  cmd='tasklist';                                    slow=$false; reboot=$false }
    [ordered]@{ id='c8';  grp='cmd'; cat='System';   label='Umgebungsvariablen';       desc='Alle Umgebungsvariablen';               cmd='set';                                         slow=$false; reboot=$false }
    [ordered]@{ id='c9';  grp='cmd'; cat='Diagnose'; label='Datentraeger-Status';      desc='SMART-Status der Festplatten';          cmd='wmic diskdrive get model,status';             slow=$false; reboot=$false }
    [ordered]@{ id='c10'; grp='cmd'; cat='Diagnose'; label='RAM-Module';               desc='Groesse, Takt, Hersteller';             cmd='wmic memorychip get capacity,speed,manufacturer'; slow=$false; reboot=$false }
    # Fixes / Reparaturen
    [ordered]@{ id='f1'; grp='fix'; cat='Netzwerk'; label='DNS-Cache leeren';             desc='Behebt viele Verbindungsprobleme';      cmd='ipconfig /flushdns';                          slow=$false; reboot=$false }
    [ordered]@{ id='f2'; grp='fix'; cat='Netzwerk'; label='IP-Adresse erneuern';          desc='Neue IP vom Router holen';              cmd='ipconfig /release & ipconfig /renew';         slow=$false; reboot=$false }
    [ordered]@{ id='f3'; grp='fix'; cat='Netzwerk'; label='Winsock zuruecksetzen';        desc='Netzwerk-Stack reparieren';             cmd='netsh winsock reset';                         slow=$false; reboot=$true }
    [ordered]@{ id='f4'; grp='fix'; cat='Netzwerk'; label='TCP/IP zuruecksetzen';         desc='Internet-Protokoll reparieren';         cmd='netsh int ip reset';                          slow=$false; reboot=$true }
    [ordered]@{ id='f5'; grp='fix'; cat='System';   label='Explorer neu starten';         desc='Bei haengender Taskleiste/Desktop';     cmd='taskkill /f /im explorer.exe & start explorer.exe'; slow=$false; reboot=$false }
    [ordered]@{ id='f6'; grp='fix'; cat='System';   label='Druckerwarteschlange neustart';desc='Bei Druckerproblemen';                  cmd='net stop spooler & net start spooler';        slow=$false; reboot=$false }
    [ordered]@{ id='f7'; grp='fix'; cat='System';   label='Windows-Update-Cache leeren';  desc='Bei fehlgeschlagenen Updates';          cmd='net stop wuauserv & net stop bits & rd /s /q "%windir%\SoftwareDistribution" & net start wuauserv & net start bits'; slow=$false; reboot=$false }
    [ordered]@{ id='f8'; grp='fix'; cat='Reparatur';label='Systemdateien pruefen (SFC)';  desc='Repariert Windows-Dateien - dauert Minuten'; cmd='sfc /scannow';                           slow=$true;  reboot=$false }
    [ordered]@{ id='f9'; grp='fix'; cat='Reparatur';label='Windows-Abbild reparieren';    desc='DISM-Tiefenreparatur - dauert lange';   cmd='DISM /Online /Cleanup-Image /RestoreHealth';  slow=$true;  reboot=$false }
    [ordered]@{ id='f10';grp='fix'; cat='Netzwerk'; label='Firewall zuruecksetzen';        desc='Firewall-Regeln auf Standard - bei Netzwerkproblemen'; cmd='netsh advfirewall reset';         slow=$false; reboot=$false }
    [ordered]@{ id='f11';grp='fix'; cat='System';   label='Windows Store zuruecksetzen';   desc='Bei Store-/App-Problemen (wsreset)';    cmd='wsreset.exe';                                 slow=$true;  reboot=$false }
    [ordered]@{ id='f12';grp='fix'; cat='System';   label='Audio-Dienst neu starten';      desc='Bei fehlendem oder haengendem Ton';     cmd='net stop audiosrv & net start audiosrv';      slow=$false; reboot=$false }
    [ordered]@{ id='f13';grp='fix'; cat='System';   label='Symbol-Cache neu aufbauen';     desc='Bei kaputten/leeren Icons auf dem Desktop'; cmd='taskkill /f /im explorer.exe & del /a /q "%localappdata%\IconCache.db" & start explorer.exe'; slow=$false; reboot=$false }
    [ordered]@{ id='f14';grp='fix'; cat='System';   label='Gruppenrichtlinien aktualisieren'; desc='Wendet geaenderte Richtlinien sofort an'; cmd='gpupdate /force';                          slow=$true;  reboot=$false }
    [ordered]@{ id='f15';grp='fix'; cat='System';   label='Uhrzeit neu synchronisieren';   desc='Bei falscher Systemzeit';               cmd='net start w32time & w32tm /resync /force';    slow=$false; reboot=$false }
    [ordered]@{ id='f16';grp='fix'; cat='Reparatur';label='Datentraeger pruefen (CHKDSK)'; desc='Plant Dateisystem-Pruefung fuer C: beim naechsten Neustart'; cmd='echo j| chkdsk C: /f /r'; slow=$true;  reboot=$true }
    [ordered]@{ id='f17';grp='fix'; cat='Netzwerk'; label='Netzwerk komplett zuruecksetzen'; desc='Winsock + TCP/IP + DNS auf einmal';    cmd='netsh winsock reset & netsh int ip reset & ipconfig /flushdns'; slow=$false; reboot=$true }
)
function Get-CmdLib {
    return @{
        cmds  = @($script:RUNCMDS | Where-Object { $_.grp -eq 'cmd' } | ForEach-Object { [ordered]@{ id=$_.id; cat=$_.cat; label=$_.label; desc=$_.desc; cmd=$_.cmd; slow=$_.slow } })
        fixes = @($script:RUNCMDS | Where-Object { $_.grp -eq 'fix' } | ForEach-Object { [ordered]@{ id=$_.id; cat=$_.cat; label=$_.label; desc=$_.desc; slow=$_.slow; reboot=$_.reboot } })
    }
}

# --- Paketmanager (winget): beliebte Apps zum 1-Klick-Installieren ---
$script:BUNDLE = @(
    [ordered]@{ id='Valve.Steam'; label='Steam' }
    [ordered]@{ id='EpicGames.EpicGamesLauncher'; label='Epic Games' }
    [ordered]@{ id='Discord.Discord'; label='Discord' }
    [ordered]@{ id='Spotify.Spotify'; label='Spotify' }
    [ordered]@{ id='Mozilla.Firefox'; label='Firefox' }
    [ordered]@{ id='Brave.Brave'; label='Brave' }
    [ordered]@{ id='Google.Chrome'; label='Chrome' }
    [ordered]@{ id='VideoLAN.VLC'; label='VLC Player' }
    [ordered]@{ id='7zip.7zip'; label='7-Zip' }
    [ordered]@{ id='Notepad++.Notepad++'; label='Notepad++' }
    [ordered]@{ id='OBSProject.OBSStudio'; label='OBS Studio' }
    [ordered]@{ id='Nvidia.GeForceExperience'; label='GeForce Experience' }
)
function Get-WingetInfo {
    return @{ available = [bool](Get-Command winget -ErrorAction SilentlyContinue); bundle = $script:BUNDLE }
}

# --- Peripherie: Geraete erkennen + eigene Namen speichern ---
$script:periphFile = Join-Path $scriptDir 'pcboost-peripherals.json'
function Get-Peripherals {
    $saved = @{}
    if (Test-Path $script:periphFile) {
        try { (Get-Content $script:periphFile -Raw | ConvertFrom-Json).PSObject.Properties | ForEach-Object { $saved[$_.Name] = $_.Value } } catch {}
    }
    $devs = @()
    $i = 0
    Get-CimInstance -Namespace root/wmi -ClassName WmiMonitorID -ErrorAction SilentlyContinue | ForEach-Object {
        $nm = -join ($_.UserFriendlyName | Where-Object { $_ -gt 0 } | ForEach-Object { [char]$_ })
        $mn = -join ($_.ManufacturerName | Where-Object { $_ -gt 0 } | ForEach-Object { [char]$_ })
        $k = "mon$i"; $devs += [ordered]@{ key=$k; type='Monitor'; detected=("$mn $nm").Trim(); name=[string]$saved[$k] }; $i++
    }
    $i = 0
    Get-CimInstance Win32_PointingDevice -ErrorAction SilentlyContinue | Where-Object { $_.Name } | Select-Object -ExpandProperty Name -Unique | ForEach-Object {
        $k = "mouse$i"; $devs += [ordered]@{ key=$k; type='Maus / Zeiger'; detected=$_; name=[string]$saved[$k] }; $i++
    }
    $i = 0
    Get-CimInstance Win32_Keyboard -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Name -Unique | ForEach-Object {
        $k = "kbd$i"; $devs += [ordered]@{ key=$k; type='Tastatur'; detected=$_; name=[string]$saved[$k] }; $i++
    }
    $i = 0
    Get-CimInstance Win32_SoundDevice -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'OK' } | Select-Object -ExpandProperty Name | ForEach-Object {
        $k = "audio$i"; $devs += [ordered]@{ key=$k; type='Audio'; detected=$_; name=[string]$saved[$k] }; $i++
    }
    return @{ devices = $devs }
}
function Save-Peripherals($json) {
    try {
        $obj = $json | ConvertFrom-Json    # validieren
        ($obj | ConvertTo-Json -Compress) | Set-Content -Path $script:periphFile -Encoding UTF8
        return 'Setup gespeichert.'
    } catch { return 'Konnte nicht speichern (ungueltige Daten).' }
}

# --- PC ausmisten: grosse Dateien finden + in den Papierkorb legen ---
$script:SCANDIRS = [ordered]@{
    downloads = (Join-Path $env:USERPROFILE 'Downloads')
    desktop   = [Environment]::GetFolderPath('Desktop')
    dokumente = [Environment]::GetFolderPath('MyDocuments')
    videos    = (Join-Path $env:USERPROFILE 'Videos')
}
function Get-BigFiles($which) {
    $dir = $script:SCANDIRS[$which]
    if (-not $dir -or -not (Test-Path $dir)) { return @{ dir=$dir; files=@() } }
    $files = @(Get-ChildItem -Path $dir -File -Recurse -Depth 4 -ErrorAction SilentlyContinue |
        Sort-Object Length -Descending | Select-Object -First 30 | ForEach-Object {
            [ordered]@{ path=$_.FullName; name=$_.Name; sizeMB=[math]::Round($_.Length / 1MB, 1); modified=$_.LastWriteTime.ToString('yyyy-MM-dd') }
        })
    return @{ dir=$dir; files=$files }
}
function Send-FileToBin($path) {
    if (-not $path) { return 'Kein Pfad.' }
    # Sicherheit: nur innerhalb der erlaubten Nutzer-Ordner
    $allowed = $false
    foreach ($a in $script:SCANDIRS.Values) {
        if ($a -and $path.ToLower().StartsWith(($a.ToLower()))) { $allowed = $true }
    }
    if (-not $allowed) { return 'Nicht erlaubt: nur Dateien in Downloads/Desktop/Dokumente/Videos.' }
    if (-not (Test-Path $path)) { return 'Datei nicht gefunden.' }
    try {
        Add-Type -AssemblyName Microsoft.VisualBasic
        [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile($path, 'OnlyErrorDialogs', 'SendToRecycleBin')
        return "In den Papierkorb verschoben (wiederherstellbar): $(Split-Path $path -Leaf)"
    } catch { return 'Fehler: ' + $_.Exception.Message }
}

function Start-Action($name, $arg) {
    $sb = $ACT[$name]
    if (-not $sb) { return $null }
    $script:actId++
    $id = "a$($script:actId)"
    $ps = [powershell]::Create()
    $ps.RunspacePool = $actionPool
    [void]$ps.AddScript($sb.ToString())
    if ($null -ne $arg -and $arg -ne '') { [void]$ps.AddArgument($arg) }
    $async = $ps.BeginInvoke()
    $shared.actions[$id] = @{ done = $false; output = $null; ps = $ps; async = $async }
    return $id
}

# Kleiner Query-Parser (?a=..&t=..)
function Get-Query($url) {
    $q = @{}
    if ($url.Query -and $url.Query.Length -gt 1) {
        foreach ($pair in $url.Query.TrimStart('?').Split('&')) {
            $kv = $pair.Split('=', 2)
            if ($kv.Length -eq 2) { $q[$kv[0]] = [System.Uri]::UnescapeDataString($kv[1]) }
        }
    }
    return $q
}

# ------------------------------------------------------------
#  HTTP-Server starten
# ------------------------------------------------------------
function New-Listener([string[]]$prefixes) {
    $l = New-Object System.Net.HttpListener
    foreach ($pf in $prefixes) { $l.Prefixes.Add($pf) }
    $l.Start()
    return $l
}
$listener = $null
try {
    $listener = New-Listener @($prefix, "http://127.0.0.1:$port/")
} catch {
    try { $listener = New-Listener @($prefix) }
    catch {
        Write-Host ""
        Write-Host "  Konnte den Server nicht starten (Port $port evtl. belegt)." -ForegroundColor Red
        Write-Host "  Fehler: $($_.Exception.Message)" -ForegroundColor DarkGray
        Read-Host "  Enter zum Beenden"
        return
    }
}

Write-Host ""
Write-Host "  ===============================================" -ForegroundColor Magenta
Write-Host "   PC BOOST v2.0 laeuft!" -ForegroundColor Magenta
Write-Host "   Dashboard:  $prefix" -ForegroundColor White
Write-Host "   Admin:      $isAdmin  (fuer CPU-Temp noetig)" -ForegroundColor DarkGray
Write-Host "   Fenster offen lassen. Schliessen = Stop." -ForegroundColor DarkGray
Write-Host "  ===============================================" -ForegroundColor Magenta
Write-Host ""

# --- PC Boost als eigenstaendiges App-Fenster oeffnen ---
# Edge/Chrome im --app-Modus: eigenes Fenster, kein Browser-Chrome, eigenes
# Profil + Taskleisten-Icon. Sieht/verhaelt sich wie eine echte App.
$browserExe = $null
foreach ($cand in @(
        (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe'),
        (Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'),
        (Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),
        (Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'))) {
    if ($cand -and (Test-Path $cand)) { $browserExe = $cand; break }
}
$appProc = $null
if ($browserExe) {
    $udd = Join-Path $env:LOCALAPPDATA 'PCBoostApp'
    $edgeArgs = "--app=$prefix --user-data-dir=`"$udd`" --window-size=1360,880 --no-first-run --no-default-browser-check --disable-background-mode"
    try { $appProc = Start-Process -FilePath $browserExe -ArgumentList $edgeArgs -PassThru -ErrorAction Stop } catch { $appProc = $null }
}
if ($appProc) {
    # Wird das App-Fenster geschlossen -> gesamte App (Server) beenden.
    # Robust: das gestartete msedge/chrome kann sich sofort beenden (Uebergabe
    # an bestehende Instanz). Deshalb ZAEHLEN wir alle Fenster mit unserem
    # eigenen Profil (user-data-dir) und beenden erst, wenn keins mehr offen ist.
    $watch = [powershell]::Create()
    [void]$watch.AddScript({
        param($udd)
        $seen = $false; $zero = 0; $noWindow = 0
        while ($true) {
            Start-Sleep -Seconds 2
            $n = @(Get-CimInstance Win32_Process -Filter "Name='msedge.exe' OR Name='chrome.exe'" -ErrorAction SilentlyContinue |
                    Where-Object { $_.CommandLine -and $_.CommandLine.Contains($udd) }).Count
            if ($n -gt 0) { $seen = $true; $zero = 0 }
            elseif ($seen) { $zero++; if ($zero -ge 2) { break } }      # 2x hintereinander 0 -> Fenster zu
            else { $noWindow++; if ($noWindow -ge 20) { break } }        # Fenster kam nie (~40s) -> beenden
        }
        [System.Environment]::Exit(0)
    }).AddArgument($udd)
    $wrs = [runspacefactory]::CreateRunspace([initialsessionstate]::CreateDefault()); $wrs.Open(); $watch.Runspace = $wrs
    [void]$watch.BeginInvoke()
} else {
    # Fallback: Standardbrowser (falls kein Edge/Chrome gefunden).
    try { Start-Process $prefix | Out-Null } catch {}
}

# --- Waechter: Echtzeit-Downloads-Ueberwachung + geplanter Auto-Scan (Hintergrund) ---
$guardianScript = {
    param($shared, $avscanSource)
    $avscanBlock = [scriptblock]::Create($avscanSource)
    $dl = "$env:USERPROFILE\Downloads"
    $exre = '\.(exe|scr|com|pif|bat|cmd|vbs|js|hta|msi|dll)$'
    $seen = @{}
    if (Test-Path $dl) { Get-ChildItem $dl -File -Force -ErrorAction SilentlyContinue | ForEach-Object { $seen[$_.FullName] = $true } }
    $lastAuto = Get-Date; $firstDone = $false
    while ($true) {
        Start-Sleep -Seconds 3
        # Echtzeit-Waechter
        if ($shared.watcherOn -and (Test-Path $dl)) {
            foreach ($fi in (Get-ChildItem $dl -File -Force -ErrorAction SilentlyContinue | Where-Object { $_.Extension -match $exre })) {
                if ($seen.ContainsKey($fi.FullName)) { continue }
                $seen[$fi.FullName] = $true
                $signed = $false; try { $signed = ((Get-AuthenticodeSignature $fi.FullName -ErrorAction Stop).Status -eq 'Valid') } catch {}
                $sev = if ($signed) { 'ok' } else { 'warn' }
                $al = @{ name = $fi.Name; path = $fi.FullName; time = (Get-Date).ToString('HH:mm:ss'); sev = $sev; msg = $(if ($signed) { 'Neue Datei (signiert).' } else { 'Neue UNSIGNIERTE Datei im Download-Ordner!' }) }
                $shared.watcherAlerts = @(@($al) + @($shared.watcherAlerts)) | Select-Object -First 40
            }
        }
        # Geplanter Auto-Scan
        if ($shared.autoScanOn) {
            $iv = [double]$shared.autoScanInterval; if ($iv -le 0) { $iv = 6 }
            if ((-not $firstDone -and ((Get-Date) - $lastAuto).TotalSeconds -ge 25) -or ($firstDone -and ((Get-Date) - $lastAuto).TotalHours -ge $iv)) {
                try {
                    $out = & $avscanBlock
                    $r = $out | ConvertFrom-Json
                    $shared.autoScanResult = @{ time = (Get-Date).ToString('yyyy-MM-dd HH:mm'); score = [int]$r.score; danger = [int]$r.danger; warn = [int]$r.warn }
                    if ([int]$r.danger -gt 0) {
                        $al = @{ name = "Auto-Scan: $([int]$r.danger) kritische(r) Fund(e)"; path = ''; time = (Get-Date).ToString('HH:mm:ss'); sev = 'danger'; msg = 'Der geplante Scan hat etwas Verdaechtiges gefunden - oeffne den Virenscan.' }
                        $shared.watcherAlerts = @(@($al) + @($shared.watcherAlerts)) | Select-Object -First 40
                    }
                } catch {}
                $lastAuto = Get-Date; $firstDone = $true
            }
        }
    }
}
$guardian = [powershell]::Create()
$guardianRs = [runspacefactory]::CreateRunspace([initialsessionstate]::CreateDefault()); $guardianRs.Open()
$guardian.Runspace = $guardianRs
[void]$guardian.AddScript($guardianScript).AddArgument($shared).AddArgument($ACT['avscan'].ToString())
[void]$guardian.BeginInvoke()

while ($listener.IsListening) {
    $res = $null
    try {
        $ctx = $listener.GetContext()
        $req = $ctx.Request
        $res = $ctx.Response
        $res.Headers.Add('Cache-Control','no-store')
        $res.KeepAlive = $false
        $path = $req.Url.AbsolutePath
        $body = $null
        $ctype = 'application/json; charset=utf-8'

        # --- Schutz: nur die eigene App darf die lokale API aufrufen (blockt fremde Webseiten / CSRF) ---
        if ($path -like '/api/*') {
            $reSelf = "^https?://(localhost|127\.0\.0\.1)(:$port)?"
            $og = [string]$req.Headers['Origin']; $rf = [string]$req.Headers['Referer']
            if (($og -and $og -notmatch $reSelf) -or ($rf -and $rf -notmatch $reSelf)) {
                $res.StatusCode = 403
                $eb = [System.Text.Encoding]::UTF8.GetBytes('{"error":"blockiert: fremde Herkunft"}')
                try { $res.OutputStream.Write($eb, 0, $eb.Length); $res.OutputStream.Close() } catch {}
                continue
            }
        }

        switch -Regex ($path) {
            '^/api/stats$'     { $body = [string]$shared.json }
            '^/api/hardware$'  { $body = [string]$shared.hwjson }
            '^/api/network$'   { $body = [string]$shared.netjson }
            '^/api/processes$' { $body = (Get-ProcessList | ConvertTo-Json -Depth 5 -Compress) }
            '^/api/tweakstatus$' { $body = (Get-TweakStatus | ConvertTo-Json -Depth 5 -Compress) }
            '^/api/startup$'     { $body = (Get-StartupList | ConvertTo-Json -Depth 5 -Compress) }
            '^/api/bloat$'       { $body = (Get-BloatList | ConvertTo-Json -Depth 5 -Compress) }
            '^/api/cmdlib$'      { $body = (Get-CmdLib | ConvertTo-Json -Depth 5 -Compress) }
            '^/api/winget$'      { $body = (Get-WingetInfo | ConvertTo-Json -Depth 5 -Compress) }
            '^/api/peripherals$' { $body = (Get-Peripherals | ConvertTo-Json -Depth 5 -Compress) }
            '^/api/bigfiles$'    { $q = Get-Query $req.Url; $body = (Get-BigFiles $q['dir'] | ConvertTo-Json -Depth 5 -Compress) }
            '^/api/auth$'        { $body = (Get-AuthStatus | ConvertTo-Json -Compress) }
            '^/api/authmode$'    { $body = (@{ hasUsers = ((Get-Users).Count -gt 0); emailConfigured = [bool](Get-MailConfig); discord = [bool](Get-DiscordConfig) } | ConvertTo-Json -Compress) }
            '^/api/discord/login$' {
                $cfg = Get-DiscordConfig
                if (-not $cfg) { $body = (@{ ok=$false; msg='Discord ist nicht eingerichtet (pcboost-discord.txt).' } | ConvertTo-Json -Compress) }
                else {
                    $st = [guid]::NewGuid().ToString('N')
                    $shared.dstate[$st] = (Get-Date).AddMinutes(5)
                    $redir = [System.Uri]::EscapeDataString($prefix + 'discord/callback')
                    $url = "https://discord.com/api/oauth2/authorize?client_id=$($cfg['client_id'])&redirect_uri=$redir&response_type=code&scope=identify&state=$st"
                    $body = (@{ ok=$true; url=$url } | ConvertTo-Json -Compress)
                }
            }
            '^/discord/callback$' {
                $q = Get-Query $req.Url
                $ctype = 'text/html; charset=utf-8'
                $ok = $false; $err = 'Ungueltige Anfrage.'
                $cfg = Get-DiscordConfig
                if ($cfg -and $q['code'] -and $q['state'] -and $shared.dstate.ContainsKey($q['state'])) {
                    $shared.dstate.Remove($q['state']) | Out-Null
                    try {
                        $redir = $prefix + 'discord/callback'
                        $tok = Invoke-RestMethod -Method Post -Uri 'https://discord.com/api/oauth2/token' -ContentType 'application/x-www-form-urlencoded' -Body @{
                            client_id=$cfg['client_id']; client_secret=$cfg['client_secret']; grant_type='authorization_code'; code=$q['code']; redirect_uri=$redir
                        }
                        $me = Invoke-RestMethod -Uri 'https://discord.com/api/users/@me' -Headers @{ Authorization = "Bearer $($tok.access_token)" }
                        $mid = "$($me.id)"
                        $acc = Get-Access
                        $allow = $cfg['allowed_ids']
                        $cfgList = @(); if ($allow) { $cfgList = @($allow.Split(',') | ForEach-Object { $_.Trim() } | Where-Object { $_ }) }
                        if ($acc.blocked -contains $mid) { $err = 'Dein Konto wurde vom Admin deaktiviert.' }
                        elseif ($acc.allowed.Count -gt 0 -and ($acc.allowed -notcontains $mid)) { $err = 'Dein Discord-Konto ist nicht freigeschaltet.' }
                        elseif ($cfgList.Count -gt 0 -and ($cfgList -notcontains $mid)) { $err = 'Dein Discord-Konto ist nicht freigeschaltet.' }
                        else {
                            $ok = $true
                            if ((Get-Access).admins.Count -eq 0) { Access-Op 'admin' $mid | Out-Null }  # erster Login = Owner/Admin
                            $shared.currentUser = @{ id = $mid; name = "$($me.username)"; admin = [bool](Test-IsAdmin $mid); loginTime = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss') }
                            Add-LoginLog $mid $me.username 'Discord'; Save-Session
                        }
                    } catch { $err = 'Discord-Verknuepfung fehlgeschlagen. Pruefe Client-ID/Secret und die Redirect-URL.' }
                }
                if ($ok) {
                    $body = "<!doctype html><html><head><meta charset=utf-8><title>PC Boost</title></head><body style='background:#0a0710;color:#e9e3f5;font-family:Segoe UI,sans-serif;text-align:center;padding-top:22vh'><h2>Discord verbunden &#10003;</h2><p>Du wirst angemeldet &hellip;</p><script>localStorage.setItem('pcb_unlocked','1');location.replace('/');</script></body></html>"
                } else {
                    $body = "<!doctype html><html><head><meta charset=utf-8><title>PC Boost</title></head><body style='background:#0a0710;color:#e9e3f5;font-family:Segoe UI,sans-serif;text-align:center;padding-top:22vh'><h2>Anmeldung fehlgeschlagen</h2><p>$err</p><p><a style='color:#c04bff' href='/'>Zurueck</a></p></body></html>"
                }
            }
            '^/api/hoststatus$'  { $body = (Get-HostsStatus | ConvertTo-Json -Compress) }
            '^/api/watcher$' {
                $body = (@{ on = [bool]$shared.watcherOn; autoOn = [bool]$shared.autoScanOn; interval = $shared.autoScanInterval; alerts = @($shared.watcherAlerts); lastAuto = $shared.autoScanResult } | ConvertTo-Json -Depth 5)
            }
            '^/api/admin/status$' {
                $cu = $shared.currentUser; $acc = Get-Access
                $isAdmin = if ($cu) { [bool]$cu.admin } else { ($acc.admins.Count -eq 0) }
                $body = (@{ isAdmin = $isAdmin; user = $cu } | ConvertTo-Json -Compress)
            }
            '^/api/admin/data$' {
                $cu = $shared.currentUser; $acc = Get-Access
                $isAdmin = if ($cu) { [bool]$cu.admin } else { ($acc.admins.Count -eq 0) }
                if ($isAdmin) {
                    $logs = @(Get-LoginLog); $accts = @((Get-Users).Keys)
                    $uniq = @($logs | ForEach-Object { $_.id } | Sort-Object -Unique | Where-Object { $_ }).Count
                    # Anmeldungen der letzten 7 Tage (fuer das Balken-Mini)
                    $proTag = [ordered]@{}
                    for ($d = 6; $d -ge 0; $d--) { $proTag[(Get-Date).AddDays(-$d).ToString('dd.MM.')] = 0 }
                    foreach ($l in $logs) {
                        try { $t = [datetime]::ParseExact($l.time, 'yyyy-MM-dd HH:mm:ss', $null).ToString('dd.MM.'); if ($proTag.Contains($t)) { $proTag[$t]++ } } catch {}
                    }
                    $tage = @($proTag.Keys | ForEach-Object { @{ tag = $_; anzahl = $proTag[$_] } })
                    $summary = @(Get-LoginSummary)
                    $stats = @{ totalLogins = $logs.Count; uniqueUsers = $uniq; accounts = $accts.Count; adminCount = $acc.admins.Count }
                    $wh = Get-Webhook
                    $body = (@{ ok=$true; logins = $logs; access = $acc; me = $cu; accounts = $accts; stats = $stats
                        summary = $summary; proTag = $tage
                        webhook = @{ gesetzt = [bool]$wh; vorschau = $(if ($wh) { ($wh -replace '(webhooks/\d+/).*', '$1…') } else { '' }) }
                        app = @{ version='5.0'; pc="$env:COMPUTERNAME"; ordner=$scriptDir }
                    } | ConvertTo-Json -Depth 6)
                }
                else { $body = (@{ ok=$false; error='Kein Admin.' } | ConvertTo-Json -Compress) }
            }
            # Holt die zentral gesammelten Anmeldungen vom Discord-Bot (Flask auf
            # 127.0.0.1:5000). Serverseitig abgefragt - kein CORS, und wenn der Bot
            # nicht laeuft, gibt es eine klare Rueckmeldung statt einer Fehlerseite.
            '^/api/admin/globallogins$' {
                $cu = $shared.currentUser; $acc = Get-Access
                $isAdmin = if ($cu) { [bool]$cu.admin } else { ($acc.admins.Count -eq 0) }
                if (-not $isAdmin) { $body = (@{ ok=$false; msg='Kein Admin.' } | ConvertTo-Json -Compress) }
                else {
                    try {
                        $r = Invoke-RestMethod -Uri 'http://127.0.0.1:5000/pcboost_logins' -TimeoutSec 3 -ErrorAction Stop
                        $liste = @($r.logins)
                        # Aggregat je Benutzer ueber alle PCs
                        $map = [ordered]@{}
                        foreach ($e in $liste) {
                            $k = "$($e.name)|$($e.winuser)"
                            if (-not $map.Contains($k)) { $map[$k] = [ordered]@{ name="$($e.name)"; winuser="$($e.winuser)"; anzahl=0; zuletzt="$($e.time)"; pcs=@() } }
                            $m = $map[$k]; $m.anzahl++
                            if ("$($e.time)" -gt "$($m.zuletzt)") { $m.zuletzt = "$($e.time)" }
                            if ($e.pc -and ($m.pcs -notcontains "$($e.pc)")) { $m.pcs += "$($e.pc)" }
                        }
                        $body = (@{ ok=$true; connected=$true; logins=$liste; summary=@($map.Values) } | ConvertTo-Json -Depth 6)
                    } catch {
                        $body = (@{ ok=$true; connected=$false; logins=@(); summary=@() } | ConvertTo-Json -Compress)
                    }
                }
            }
            '^/api/admin/webhook$' {
                $cu = $shared.currentUser; $acc = Get-Access
                $isAdmin = if ($cu) { [bool]$cu.admin } else { ($acc.admins.Count -eq 0) }
                if (-not $isAdmin) { $body = (@{ ok=$false; msg='Kein Admin.' } | ConvertTo-Json -Compress) }
                else {
                    $qw = Get-Query $req.Url
                    if ($qw['op'] -eq 'set') {
                        $body = (Set-Webhook $qw['url'] | ConvertTo-Json -Compress)
                    }
                    elseif ($qw['op'] -eq 'test') {
                        if (-not (Get-Webhook)) { $body = (@{ ok=$false; msg='Erst eine Webhook-URL speichern.' } | ConvertTo-Json -Compress) }
                        else {
                            $ok = Send-Webhook 'Testnachricht' @(
                                @{ k='Status'; v='PC Boost ist verbunden'; inline=$false },
                                @{ k='PC'; v="$env:COMPUTERNAME"; inline=$true },
                                @{ k='Zeit'; v=(Get-Date).ToString('dd.MM.yyyy HH:mm:ss'); inline=$true }
                            ) 3447003
                            $body = (@{ ok=$ok; msg=$(if ($ok) { 'Testnachricht gesendet - schau in deinen Discord-Kanal.' } else { 'Senden fehlgeschlagen. Ist die URL noch gueltig?' }) } | ConvertTo-Json -Compress)
                        }
                    }
                    else { $body = (@{ ok=$false; msg='Unbekannte Aktion.' } | ConvertTo-Json -Compress) }
                }
            }
            # Erkennungsmerkmal fuer den Starter: antwortet eine alte Fassung,
            # kommt hier HTML statt JSON zurueck.
            '^/api/version$' {
                $body = '{"backend":"pc-boost","version":"5.0","quit":true}'
            }
            # Selbsttest: prueft die Umgebung, auf die sich die App verlaesst.
            # Die Endpunkte selbst klopft die Oberflaeche einzeln ab.
            '^/api/selftest$' {
                $pr = @()
                $adminJetzt = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
                $pr += [ordered]@{ name='Adminrechte'; ok=$adminJetzt
                    info=$(if ($adminJetzt) { 'vorhanden - alle Schalter nutzbar' } else { 'fehlen - 20 von 42 Schaltern und CPU-Temperatur nicht verfuegbar' }) }

                $lhm = Join-Path $libDir 'LibreHardwareMonitorLib.dll'
                $pr += [ordered]@{ name='Bibliotheken (lib)'; ok=(Test-Path $lhm)
                    info=$(if (Test-Path $lhm) { 'LibreHardwareMonitor gefunden' } else { "fehlt: $lhm" }) }

                $schreibOk = $false; $schreibInfo = ''
                try {
                    $probe = Join-Path $scriptDir '.pcboost-schreibtest'
                    Set-Content -Path $probe -Value 'x' -ErrorAction Stop
                    Remove-Item $probe -Force -ErrorAction SilentlyContinue
                    $schreibOk = $true; $schreibInfo = "Ordner beschreibbar: $scriptDir"
                } catch { $schreibInfo = "nicht beschreibbar: $scriptDir" }
                $pr += [ordered]@{ name='Datenordner'; ok=$schreibOk; info=$schreibInfo }

                $wmiOk = $false; $wmiInfo = ''
                try { $null = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop; $wmiOk = $true; $wmiInfo = 'erreichbar' }
                catch { $wmiInfo = 'nicht erreichbar - ohne WMI keine Systemwerte' }
                $pr += [ordered]@{ name='WMI'; ok=$wmiOk; info=$wmiInfo }

                $samOk = $false; $samInfo = 'liefert keine Daten'
                try {
                    $sj = $shared.json | ConvertFrom-Json
                    if ($sj -and $null -ne $sj.cpuLoad) { $samOk = $true; $samInfo = "laeuft, Stand $($sj.time), CPU $([int]$sj.cpuLoad)%" }
                } catch {}
                $pr += [ordered]@{ name='Messwert-Sammler'; ok=$samOk; info=$samInfo }

                $vz = 0
                if (Test-Path $histFile) { try { $vz = @(Get-Content $histFile -ErrorAction SilentlyContinue).Count } catch {} }
                $pr += [ordered]@{ name='Langzeit-Verlauf'; ok=($vz -gt 0)
                    info=$(if ($vz -gt 0) { "$vz Messpunkte aufgezeichnet (1 je Minute)" } else { 'noch leer - fuellt sich mit der Laufzeit' }) }

                $ct = $null; try { $ct = ($shared.json | ConvertFrom-Json).cpuTemp } catch {}
                $pr += [ordered]@{ name='CPU-Temperatur'; ok=($null -ne $ct)
                    info=$(if ($null -ne $ct) { "$([int]$ct) Grad" } else { 'nicht verfuegbar (Adminrechte und lib noetig, nicht jede CPU wird unterstuetzt)' }) }

                $gn = ''; try { $gn = "$((Get-CimInstance Win32_VideoController -ErrorAction Stop | Select-Object -First 1).Name)" } catch {}
                $pr += [ordered]@{ name='Grafikkarte'; ok=[bool]$gn; info=$(if ($gn) { $gn } else { 'nicht erkannt' }) }

                $planOk = $false; $planInfo = 'nicht lesbar'
                try { $ap = powercfg /getactivescheme; if ($ap -match '\(([^)]+)\)') { $planOk = $true; $planInfo = "aktiv: $($Matches[1])" } } catch {}
                $pr += [ordered]@{ name='Energieplan'; ok=$planOk; info=$planInfo }

                $hostsOk = (Test-Path $script:hostsFile)
                $pr += [ordered]@{ name='hosts-Datei'; ok=$hostsOk
                    info=$(if ($hostsOk) { 'lesbar - Telemetrie-Blockade moeglich' } else { 'nicht gefunden' }) }

                $body = (@{ pruefungen = @($pr) } | ConvertTo-Json -Depth 5 -Compress)
            }
            # Sauber beenden - ohne das bleiben Instanzen haengen, die sich
            # spaeter nur noch mit Adminrechten abschiessen lassen.
            '^/api/quit$' {
                $body = '{"ok":true,"msg":"PC Boost wird beendet."}'
                $script:beenden = $true
            }
            '^/api/tweaklog$' {
                $log = @(Get-TweakLog)
                $mit = @()
                for ($i = 0; $i -lt $log.Count; $i++) {
                    $mit += [ordered]@{ idx = $i; key = $log[$i].key; label = $log[$i].label; alt = $log[$i].alt; neu = $log[$i].neu; zeit = $log[$i].zeit }
                }
                if ($mit.Count -gt 1) { [array]::Reverse($mit) }   # neueste zuerst
                $body = (@{ eintraege = @($mit) } | ConvertTo-Json -Depth 5 -Compress)
            }
            '^/api/profile$' {
                $body = (Export-TweakProfile | ConvertTo-Json -Depth 5)
            }
            '^/api/profile/import$' {
                $roh = ''
                try {
                    $sr = New-Object System.IO.StreamReader($req.InputStream, $req.ContentEncoding)
                    $roh = $sr.ReadToEnd(); $sr.Close()
                } catch {}
                $erg = $null
                try { $erg = Import-TweakProfile ($roh | ConvertFrom-Json) }
                catch { $erg = @{ ok = $false; msg = 'Die Datei konnte nicht gelesen werden - kein gueltiges JSON.' } }
                $body = ($erg | ConvertTo-Json -Compress)
            }
            '^/api/effect$' {
                $q3 = Get-Query $req.Url
                $iE = -1; [void][int]::TryParse($q3['i'], [ref]$iE)
                $wE = 30; [void][int]::TryParse($q3['w'], [ref]$wE)
                $body = (Get-TweakEffect $iE $wE | ConvertTo-Json -Depth 5 -Compress)
            }
            '^/api/findings$' {
                $q4 = Get-Query $req.Url
                $sf = 24; [void][int]::TryParse($q4['h'], [ref]$sf)
                $body = (Get-HistoryFindings $sf | ConvertTo-Json -Depth 5 -Compress)
            }
            '^/api/history$' {
                $q2 = Get-Query $req.Url
                $std = 24; [void][int]::TryParse($q2['h'], [ref]$std)
                if ($std -lt 1) { $std = 24 }; if ($std -gt 168) { $std = 168 }
                $punkte = @()
                if (Test-Path $histFile) {
                    try {
                        $jetzt = [int][math]::Floor(((Get-Date).ToUniversalTime() - [datetime]'1970-01-01').TotalMinutes)
                        $ab = $jetzt - ($std * 60)
                        $roh = @()
                        foreach ($z in @(Get-Content $histFile -ErrorAction SilentlyContinue)) {
                            $s = "$z".Split(',')
                            if ($s.Count -lt 6) { continue }
                            $m = 0; if (-not [int]::TryParse($s[0], [ref]$m)) { continue }
                            if ($m -lt $ab) { continue }
                            $roh += ,@([int]$m, [int]$s[1], [int]$s[2], [int]$s[3], [int]$s[4], [int]$s[5])
                        }
                        # auf hoechstens 240 Punkte eindampfen, sonst wird das Diagramm unlesbar
                        $ziel = 240
                        if ($roh.Count -le $ziel) { $punkte = $roh }
                        else {
                            $gr = [int][math]::Ceiling($roh.Count / $ziel)
                            for ($i = 0; $i -lt $roh.Count; $i += $gr) {
                                $bis = [math]::Min($i + $gr - 1, $roh.Count - 1)
                                $teil = @($roh[$i..$bis])
                                $mw = {
                                    param($idx)
                                    $g = @($teil | ForEach-Object { $_[$idx] } | Where-Object { $_ -ge 0 })
                                    if ($g.Count) { [int](($g | Measure-Object -Average).Average) } else { -1 }
                                }
                                $punkte += ,@($teil[0][0], (& $mw 1), (& $mw 2), (& $mw 3), (& $mw 4), (& $mw 5))
                            }
                        }
                    } catch {}
                }
                $body = (@{ stunden = $std; punkte = @($punkte) } | ConvertTo-Json -Depth 4 -Compress)
            }
            '^/api/run$' {
                $q = Get-Query $req.Url
                $a = $q['a']
                # Hinweis: Der Schutz vor fremden Webseiten (Origin/Referer -> 403)
                # sitzt weiter oben und gilt fuer alle /api/-Pfade. Hier nicht
                # nochmal pruefen - doppelte Sicherheitslogik pflegt niemand.
                if ($a -eq 'tweakundoall') {
                    $r2 = Undo-AllTweaks
                    $msg = if ($r2.leer) { 'Es ist nichts protokolliert - keine Aenderungen zum Zuruecknehmen.' }
                           else { "$($r2.ok) Schalter zurueckgesetzt" + $(if ($r2.fehl) { ", $($r2.fehl) fehlgeschlagen (Adminrechte noetig?)" } else { '' }) + '. Fuer manche Schalter ist ein Neustart noetig.' }
                    $body = (@{ done = $true; ok = $true; output = $msg } | ConvertTo-Json -Compress)
                }
                elseif ($a -eq 'tweakundo') {
                    $log = @(Get-TweakLog)
                    $i2 = -1; [void][int]::TryParse($q['i'], [ref]$i2)
                    if ($i2 -lt 0 -or $i2 -ge $log.Count) {
                        $body = (@{ done = $true; ok = $false; output = 'Eintrag nicht gefunden.' } | ConvertTo-Json -Compress)
                    } else {
                        $e2 = $log[$i2]
                        $okr = Restore-TweakValue $e2.key $e2.alt
                        $txt = if ($okr) { "`"$($e2.label)`" auf den vorherigen Wert zurueckgesetzt." } else { 'Zuruecksetzen fehlgeschlagen - vermutlich fehlen Adminrechte.' }
                        $body = (@{ done = $true; ok = $okr; output = $txt } | ConvertTo-Json -Compress)
                    }
                }
                elseif ($a -eq 'empfohlen') {
                    $r3 = Set-RecommendedTweaks
                    $txt = "$($r3.geaendert) Schalter umgestellt, $($r3.schon) waren bereits richtig"
                    if ($r3.fehl) { $txt += ", $($r3.fehl) fehlgeschlagen (Adminrechte noetig)" }
                    $txt += ".`r`n`r`n" + ($r3.details -join "`r`n")
                    $txt += "`r`n`r`nAlles davon steht im Aenderungsprotokoll und laesst sich dort zuruecknehmen."
                    $body = (@{ done = $true; ok = $true; output = $txt } | ConvertTo-Json -Compress)
                }
                elseif ($a -eq 'tweaklogclear') {
                    try { Remove-Item $tweakLogFile -Force -ErrorAction SilentlyContinue } catch {}
                    $body = (@{ done = $true; ok = $true; output = 'Protokoll geleert. Die Schalter selbst bleiben unveraendert.' } | ConvertTo-Json -Compress)
                }
                elseif ($a -eq 'launch') {
                    $t = $q['t']; $cmd = $LAUNCH[$t]
                    if ($cmd) { try { Start-Process $cmd -ErrorAction Stop; $body = (@{ done=$true; output="Geoeffnet: $t" } | ConvertTo-Json -Compress) }
                                catch { $body = (@{ done=$true; output=("Konnte nicht oeffnen: " + $_.Exception.Message) } | ConvertTo-Json -Compress) } }
                    else { $body = (@{ done=$true; output='Unbekanntes Werkzeug.' } | ConvertTo-Json -Compress) }
                }
                elseif ($a -eq 'hardwareid') {
                    $hid = ''
                    try { $hid = "$((Get-CimInstance Win32_ComputerSystemProduct -ErrorAction Stop).UUID)".Trim() } catch {}
                    if (-not $hid) { $hid = 'Nicht ermittelbar' }
                    $body = (@{ ok=$true; msg=$null; id=$hid } | ConvertTo-Json -Compress)
                }
                elseif ($a -eq 'publicip') {
                    $ip = $null; $ipMsg = $null
                    try { $ip = "$((Invoke-RestMethod -Uri 'https://api.ipify.org?format=json' -TimeoutSec 8 -ErrorAction Stop).ip)".Trim() }
                    catch {
                        try { $ip = "$((Invoke-WebRequest -Uri 'https://ifconfig.me/ip' -UseBasicParsing -TimeoutSec 8 -ErrorAction Stop).Content)".Trim() }
                        catch { $ipMsg = 'Kein IP-Dienst erreichbar.' }
                    }
                    $body = (@{ ok=[bool]$ip; ip=$ip; msg=$ipMsg } | ConvertTo-Json -Compress)
                }
                elseif ($a -eq 'clearcaches') {
                    $cachePfade = @(
                        $env:TEMP,
                        (Join-Path $env:WINDIR 'Temp'),
                        (Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\INetCache'),
                        (Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\Explorer'),
                        (Join-Path $env:LOCALAPPDATA 'CrashDumps'),
                        (Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\WebCache')
                    )
                    $pfadZahl = 0; $datZahl = 0; $bytesFrei = 0
                    foreach ($cp in $cachePfade) {
                        if ($cp -and (Test-Path $cp)) {
                            $pfadZahl++
                            Get-ChildItem $cp -Recurse -Force -File -ErrorAction SilentlyContinue | ForEach-Object {
                                $sz = $_.Length
                                try { Remove-Item $_.FullName -Force -ErrorAction Stop; $datZahl++; $bytesFrei += $sz } catch {}
                            }
                        }
                    }
                    $body = (@{ ok=$true; done=$true; msg="$pfadZahl Cache-Pfade geleert - $datZahl Dateien, $([math]::Round($bytesFrei/1MB,1)) MB frei" } | ConvertTo-Json -Compress)
                }
                elseif ($a -eq 'sethardwareid') {
                    # Die oben angezeigte Kennung stammt aus Win32_ComputerSystemProduct.UUID,
                    # also aus der Firmware (SMBIOS). Windows kann sie nicht ueberschreiben.
                    $body = (@{ ok=$false; done=$true; msg='Nicht verfuegbar. Die angezeigte Hardware-ID liegt in der Firmware des Mainboards (SMBIOS) und laesst sich aus Windows heraus nicht aendern. Fuer die Freischaltung des Admin-Panels trage deine ID stattdessen in die Whitelist ein.' } | ConvertTo-Json -Compress)
                }
                elseif ($a -eq 'macrolist') {
                    $body = (@{ macros = (Get-JsonMap $macrosFile) } | ConvertTo-Json -Depth 6 -Compress)
                }
                elseif ($a -eq 'macrocreate') {
                    $mk = Get-JsonMap $macrosFile
                    $mDelay = 100; [void][int]::TryParse($q['delay'], [ref]$mDelay)
                    $mRep   = 1;   [void][int]::TryParse($q['repeat'], [ref]$mRep)
                    $id = "$(Get-NextId $mk)"
                    $mk[$id] = [ordered]@{
                        id     = $id
                        name   = "$($q['name'])"
                        keys   = @("$($q['keys'])".Split(',') | ForEach-Object { $_.Trim() } | Where-Object { $_ })
                        delay  = $mDelay
                        repeat = $mRep
                        hotkey = "$($q['hotkey'])"
                    }
                    $okSave = Save-JsonMap $macrosFile $mk
                    $body = (@{ ok=$okSave; done=$true; id=$id; msg=$(if($okSave){"Makro gespeichert."}else{"Speichern fehlgeschlagen."}) } | ConvertTo-Json -Compress)
                }
                elseif ($a -eq 'macrodelete') {
                    $mk = Get-JsonMap $macrosFile
                    $id = "$($q['id'])"
                    if ($mk.ContainsKey($id)) { $mk.Remove($id); [void](Save-JsonMap $macrosFile $mk); $body = (@{ ok=$true; done=$true; msg='Makro geloescht.' } | ConvertTo-Json -Compress) }
                    else { $body = (@{ ok=$false; done=$true; msg='Makro nicht gefunden.' } | ConvertTo-Json -Compress) }
                }
                elseif ($a -eq 'macroexec') {
                    $mk = Get-JsonMap $macrosFile
                    $id = "$($q['id'])"
                    if (-not $mk.ContainsKey($id)) { $body = (@{ ok=$false; done=$true; msg='Makro nicht gefunden.' } | ConvertTo-Json -Compress) }
                    else {
                        $m = $mk[$id]
                        $gesendet = 0; $unbekannt = @()
                        $wdh = 1; [void][int]::TryParse("$($m.repeat)", [ref]$wdh); if ($wdh -lt 1) { $wdh = 1 }
                        $wart = 100; [void][int]::TryParse("$($m.delay)", [ref]$wart); if ($wart -lt 0) { $wart = 0 }
                        try {
                            for ($r = 0; $r -lt $wdh; $r++) {
                                foreach ($taste in @($m.keys)) {
                                    $vk = Get-VirtualKey $taste
                                    if ($vk -gt 0) { [PCBoostInput]::KeyPress([byte]$vk); $gesendet++ }
                                    elseif ($unbekannt -notcontains $taste) { $unbekannt += $taste }
                                    Start-Sleep -Milliseconds $wart
                                }
                            }
                            $hinweis = if ($unbekannt.Count) { " Unbekannte Tasten uebersprungen: $($unbekannt -join ', ')." } else { '' }
                            $body = (@{ ok=$true; done=$true; msg="$gesendet Tastendruecke gesendet.$hinweis" } | ConvertTo-Json -Compress)
                        } catch {
                            $body = (@{ ok=$false; done=$true; msg=("Wiedergabe fehlgeschlagen: " + $_.Exception.Message) } | ConvertTo-Json -Compress)
                        }
                    }
                }
                elseif ($a -eq 'traininglist') {
                    $body = (@{ items = (Get-JsonMap $trainingFile) } | ConvertTo-Json -Depth 6 -Compress)
                }
                elseif ($a -eq 'trainingadd') {
                    $tr = Get-JsonMap $trainingFile
                    $tp = "$($q['path'])"
                    if (-not $tp -or -not (Test-Path $tp)) { $body = (@{ ok=$false; done=$true; msg='Pfad nicht gefunden.' } | ConvertTo-Json -Compress) }
                    else {
                        $fi = Get-Item $tp -ErrorAction SilentlyContinue
                        $id = "$(Get-NextId $tr)"
                        $tr[$id] = [ordered]@{
                            id      = $id
                            path    = $fi.FullName
                            name    = $fi.Name
                            sizeMB  = if ($fi.PSIsContainer) { 0 } else { [math]::Round($fi.Length / 1MB, 2) }
                            added   = (Get-Date).ToString('yyyy-MM-dd HH:mm')
                        }
                        $okSave = Save-JsonMap $trainingFile $tr
                        $body = (@{ ok=$okSave; done=$true; id=$id; msg=$(if($okSave){"Eintrag hinzugefuegt."}else{"Speichern fehlgeschlagen."}) } | ConvertTo-Json -Compress)
                    }
                }
                elseif ($a -eq 'trainingdelete') {
                    $tr = Get-JsonMap $trainingFile
                    $ids = @("$($q['ids'])".Split(',') | ForEach-Object { $_.Trim() } | Where-Object { $_ })
                    $weg = 0; $fehl = 0
                    try { Add-Type -AssemblyName Microsoft.VisualBasic -ErrorAction SilentlyContinue } catch {}
                    foreach ($tid in $ids) {
                        if (-not $tr.ContainsKey($tid)) { continue }
                        $tp = "$($tr[$tid].path)"
                        if ($tp -and (Test-Path $tp)) {
                            # In den Papierkorb statt endgueltig loeschen - bleibt umkehrbar
                            try { [Microsoft.VisualBasic.FileIO.FileSystem]::DeleteFile($tp, 'OnlyErrorDialogs', 'SendToRecycleBin') }
                            catch { $fehl++; continue }
                        }
                        $tr.Remove($tid); $weg++
                    }
                    [void](Save-JsonMap $trainingFile $tr)
                    $body = (@{ ok=$true; done=$true; msg="$weg in den Papierkorb verschoben$(if($fehl){", $fehl fehlgeschlagen"})." } | ConvertTo-Json -Compress)
                }
                elseif ($a -eq 'kill') {
                    $pid2 = 0; [void][int]::TryParse($q['pid'], [ref]$pid2)
                    if ($pid2 -gt 0) { try { Stop-Process -Id $pid2 -Force -ErrorAction Stop; $body = (@{ done=$true; output="Beendet: $pid2" } | ConvertTo-Json -Compress) }
                                       catch { $body = (@{ done=$true; output=("Konnte nicht beenden: " + $_.Exception.Message) } | ConvertTo-Json -Compress) } }
                    else { $body = (@{ done=$true; output='Ungueltige PID.' } | ConvertTo-Json -Compress) }
                }
                elseif ($a -eq 'reveal') {
                    $rp = $q['path']
                    if ($rp -and (Test-Path $rp)) { try { Start-Process explorer.exe -ArgumentList "/select,`"$rp`"" | Out-Null; $body = (@{ done=$true; output='Im Explorer geoeffnet.' } | ConvertTo-Json -Compress) } catch { $body = (@{ done=$true; output='Konnte nicht oeffnen.' } | ConvertTo-Json -Compress) } }
                    else { $body = (@{ done=$true; output='Pfad nicht gefunden.' } | ConvertTo-Json -Compress) }
                }
                elseif ($a -eq 'access' -or $a -eq 'clearlog' -or $a -eq 'deluser') {
                    $cu = $shared.currentUser; $acc0 = Get-Access
                    $isAdmin = if ($cu) { [bool]$cu.admin } else { ($acc0.admins.Count -eq 0) }
                    if (-not $isAdmin) { $body = (@{ done=$true; output='Nur Admins duerfen das.' } | ConvertTo-Json -Compress) }
                    elseif ($a -eq 'clearlog') { Remove-Item $loginLogFile -Force -ErrorAction SilentlyContinue; $body = (@{ done=$true; output='Login-Verlauf geleert.' } | ConvertTo-Json -Compress) }
                    elseif ($a -eq 'deluser') { $body = (@{ done=$true; output=(Remove-LocalUser $q['arg']) } | ConvertTo-Json -Compress) }
                    else { $r = Access-Op $q['op'] $q['id']; $body = (@{ done=$true; output=$r } | ConvertTo-Json -Compress) }
                }
                elseif ($a -eq 'powerplan') {
                    $g = $q['guid']
                    if ($g -match '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$') {
                        powercfg /setactive $g | Out-Null
                        $body = (@{ done=$true; output='Energieplan gewechselt.' } | ConvertTo-Json -Compress)
                    } else { $body = (@{ done=$true; output='Ungueltige GUID.' } | ConvertTo-Json -Compress) }
                }
                elseif ($a -eq 'toggle') {
                    $r = Set-TweakByKey $q['key']
                    $body = (@{ done=$true; output=$r } | ConvertTo-Json -Compress)
                }
                elseif ($a -eq 'startuptoggle') {
                    $on = ($q['on'] -eq '1')
                    $r = Set-StartupEntry $q['scope'] $q['name'] $on
                    $body = (@{ done=$true; output=$r } | ConvertTo-Json -Compress)
                }
                elseif ($a -eq 'savenames') {
                    $r = Save-Peripherals $q['arg']
                    $body = (@{ done=$true; output=$r } | ConvertTo-Json -Compress)
                }
                elseif ($a -eq 'login') {
                    $body = (@{ done=$true; ok=(Test-Password $q['h']) } | ConvertTo-Json -Compress)
                }
                elseif ($a -eq 'setpw') {
                    $body = (@{ done=$true; ok=(Set-Password $q['h']) } | ConvertTo-Json -Compress)
                }
                elseif ($a -eq 'userlogin') {
                    $ok = Test-UserLogin $q['email'] $q['h']
                    if ($ok) {
                        $key = "$($q['email'])".Trim(); $lid = "local:$($key.ToLower())"
                        if ((Get-Access).admins.Count -eq 0) { Access-Op 'admin' $lid | Out-Null }
                        $shared.currentUser = @{ id=$lid; name=$key; admin=[bool](Test-IsAdmin $lid); loginTime=(Get-Date).ToString('yyyy-MM-dd HH:mm:ss') }
                        Add-LoginLog $lid $key 'Konto'; Save-Session
                    }
                    $body = (@{ done=$true; ok=$ok } | ConvertTo-Json -Compress)
                }
                elseif ($a -eq 'localregister') {
                    $r = Register-Local $q['email'] $q['h']
                    if ($r.ok) {
                        $key = "$($q['email'])".Trim(); $lid = "local:$($key.ToLower())"
                        if ((Get-Access).admins.Count -eq 0) { Access-Op 'admin' $lid | Out-Null }
                        $shared.currentUser = @{ id=$lid; name=$key; admin=[bool](Test-IsAdmin $lid); loginTime=(Get-Date).ToString('yyyy-MM-dd HH:mm:ss') }
                        Add-LoginLog $lid $key 'Konto (neu)'; Save-Session
                    }
                    $body = (@{ done=$true; ok=$r.ok; msg=$r.msg } | ConvertTo-Json -Compress)
                }
                elseif ($a -eq 'register') {
                    $r = Start-Register $q['email'] $q['h']
                    $body = (@{ done=$true; ok=$r.ok; needsCode=$r.needsCode; msg=$r.msg } | ConvertTo-Json -Compress)
                }
                elseif ($a -eq 'registerverify') {
                    $body = (@{ done=$true; ok=(Verify-Register $q['email'] $q['code']) } | ConvertTo-Json -Compress)
                }
                elseif ($a -eq 'logout') {
                    $shared.currentUser = $null
                    try { Remove-Item $sessionFile -Force -ErrorAction SilentlyContinue } catch {}
                    $body = (@{ done=$true; ok=$true } | ConvertTo-Json -Compress)
                }
                elseif ($a -eq 'watcher') {
                    $shared.watcherOn = ($q['on'] -eq '1'); Save-Settings
                    $body = (@{ done=$true; output=$(if($shared.watcherOn){'Echtzeit-Waechter aktiv - neue Downloads werden geprueft.'}else{'Echtzeit-Waechter aus.'}) } | ConvertTo-Json -Compress)
                }
                elseif ($a -eq 'autoscan') {
                    $shared.autoScanOn = ($q['on'] -eq '1'); Save-Settings
                    $body = (@{ done=$true; output=$(if($shared.autoScanOn){'Geplanter Auto-Scan aktiv.'}else{'Auto-Scan aus.'}) } | ConvertTo-Json -Compress)
                }
                elseif ($a -eq 'clearalerts') {
                    $shared.watcherAlerts = @()
                    $body = (@{ done=$true; output='Meldungen geleert.' } | ConvertTo-Json -Compress)
                }
                elseif ($a -eq 'stopinput') {
                    try { Set-Content -Path "$env:TEMP\pcboost-stopinput" -Value '1' -Force } catch {}
                    try { Remove-Item "$env:TEMP\pcboost-input-active" -Force -ErrorAction SilentlyContinue } catch {}
                    $body = (@{ done=$true; output='Gestoppt.' } | ConvertTo-Json -Compress)
                }
                elseif ($a -eq 'disarmmacro') {
                    try { Set-Content -Path "$env:TEMP\pcboost-macroarm-off" -Value '1' -Force } catch {}
                    try { Remove-Item "$env:TEMP\pcboost-input-active" -Force -ErrorAction SilentlyContinue } catch {}
                    $body = (@{ done=$true; output='Hotkey deaktiviert.' } | ConvertTo-Json -Compress)
                }
                elseif ($a -eq 'recyclefile') {
                    $body = (@{ done=$true; output=(Send-FileToBin $q['arg']) } | ConvertTo-Json -Compress)
                }
                elseif ($a -eq 'blockhosts') {
                    $body = (@{ done=$true; output=(Set-HostsBlock ($q['on'] -eq '1')) } | ConvertTo-Json -Compress)
                }
                elseif ($a -eq 'cmd') {
                    $entry = $script:RUNCMDS | Where-Object { $_.id -eq $q['id'] } | Select-Object -First 1
                    if ($entry) {
                        $id = Start-Action 'runcmd' $entry.cmd
                        $body = (@{ done=$false; id=$id } | ConvertTo-Json -Compress)
                    } else { $body = (@{ done=$true; output='Unbekannter Befehl.' } | ConvertTo-Json -Compress) }
                }
                elseif ($script:INTERN -contains $a) {
                    # 'runcmd' gibt seinen Parameter an cmd /c weiter. Erreichbar
                    # ist es ausschliesslich ueber a=cmd&id=..., wo der Befehl aus
                    # der serverseitigen Whitelist $script:RUNCMDS stammt. Ohne
                    # diese Sperre waere ueber a=runcmd&arg=... jeder beliebige
                    # Befehl ausfuehrbar - und die App laeuft mit Adminrechten.
                    $body = (@{ done=$true; ok=$false; output='Diese Aktion kann nicht direkt aufgerufen werden.' } | ConvertTo-Json -Compress)
                }
                else {
                    $id = Start-Action $a $q['arg']
                    if ($id) { $body = (@{ done=$false; id=$id } | ConvertTo-Json -Compress) }
                    else     { $body = (@{ done=$true; output='Unbekannte Aktion.' } | ConvertTo-Json -Compress) }
                }
            }
            '^/api/result$' {
                $q = Get-Query $req.Url
                $id = $q['id']; $a = $shared.actions[$id]
                if ($a) {
                    if ($a.async.IsCompleted -and -not $a.done) {
                        try { $out = $a.ps.EndInvoke($a.async); $a.output = (($out | Out-String).Trim()) } catch { $a.output = 'Fehler bei der Ausfuehrung.' }
                        $a.done = $true
                        try { $a.ps.Dispose() } catch {}
                    }
                    $body = (@{ done=$a.done; output=$a.output } | ConvertTo-Json -Compress)
                    if ($a.done) { $shared.actions.Remove($id) }
                } else {
                    $body = (@{ done=$true; output='' } | ConvertTo-Json -Compress)
                }
            }
            default {
                $body = $html; $ctype = 'text/html; charset=utf-8'
            }
        }

        $buf = [System.Text.Encoding]::UTF8.GetBytes([string]$body)
        $res.ContentType = $ctype
        $res.ContentLength64 = $buf.Length
        $res.OutputStream.Write($buf, 0, $buf.Length)
        $res.OutputStream.Flush()
        $res.OutputStream.Close()
    } catch {
        # einzelne Anfrage fehlgeschlagen -> weiter
    } finally {
        if ($res) { try { $res.Close() } catch {} }
    }

    # Beenden erst NACH dem Senden der Antwort, damit der Browser sie noch bekommt
    if ($script:beenden) { break }
}

# --- Herunterfahren -------------------------------------------------------
# Zuerst den Port freigeben, darauf wartet der Starter.
try { $listener.Stop() }  catch {}
try { $listener.Close() } catch {}

# Merker des Overlays aufraeumen. Das Overlay selbst laeuft in einem
# Runspace INNERHALB dieses Prozesses und endet gleich mit ihm.
try {
    Remove-Item (Join-Path $env:TEMP 'pcboost-overlay-on')  -Force -ErrorAction SilentlyContinue
    Remove-Item (Join-Path $env:TEMP 'pcboost-overlay-off') -Force -ErrorAction SilentlyContinue
} catch {}

# Sofort und hart beenden.
# Kein Close()/Stop() auf Collector oder Aktions-Pool: beide blockieren,
# bis ihre Schleifen bzw. laufenden Aktionen von selbst enden - der Prozess
# haengt dann noch sekundenlang herum. Genau solche Zombie-Instanzen sind
# der Grund fuer diese Funktion. Die Threads raeumt das Betriebssystem ab.
[System.Environment]::Exit(0)
